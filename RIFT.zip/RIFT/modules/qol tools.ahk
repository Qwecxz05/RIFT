﻿Init_qol()
{
	local
	global vars, settings, json

	If !FileExist("ini" vars.poe_version "\qol tools.ini")
		IniWrite, % "", % "ini" vars.poe_version "\qol tools.ini", settings

	ini := IniBatchRead("ini" vars.poe_version "\qol tools.ini")
	settings.qol := {"alarm": !Blank(check := ini.features.alarm) ? check : 0
		, "notepad": !Blank(check1 := ini.features.notepad) ? check1 : 0
		, "lab": (settings.general.lang_client = "unknown") ? 0 : !Blank(check2 := ini.features.lab) ? check2 : 0
		, "mapevents": !Blank(check3 := ini.features.mapevents) ? check3 : 0
		, "quickpob": !Blank(check4 := ini.features.quickpob) ? check4 : 0}

	settings.alarm := {"fSize": !Blank(check := ini.alarm["font-size"]) ? check : settings.general.fSize}
	LLK_FontDimensions(settings.alarm.fSize, font_height, font_width), settings.alarm.fHeight := font_height, settings.alarm.fWidth := font_width
	settings.alarm.fSize2 := settings.alarm.fSize - 4
	LLK_FontDimensions(settings.alarm.fSize2, font_height, font_width), settings.alarm.fHeight2 := font_height, settings.alarm.fWidth2 := font_width
	settings.alarm.color := !Blank(check := ini.alarm["font-color"]) ? check : "FFFFFF"
	settings.alarm.color1 := !Blank(check := ini.alarm["background color"]) ? check : "000000"
	settings.alarm.xPos := !Blank(check := ini.alarm["x-coordinate"]) ? check : "center"
	settings.alarm.yPos := !Blank(check := ini.alarm["y-coordinate"]) ? check : vars.client.y - vars.monitor.y
	settings.alarm.orientation := !Blank(check := ini.alarm.orientation) ? check : "horizontal"
	vars.alarm := {"timers": {}, "defaults": {}, "single_use": {}}
	vars.mapevents := {}

	For timer, timestamp in ini["alarm - timers"]
	{
		array := ""
		If (SubStr(timestamp, 1, 1) . SubStr(timestamp, 0) = "[]")
			Try array := json.load(timestamp)
		If !Blank(array.1)
			timestamp := array.1, vars.alarm.defaults[timer] := array.2
		If (timestamp > A_Now)
		{
			timestamp .= "|"
			While vars.alarm.timers.HasKey(timestamp)
				timestamp .= "|"
			vars.alarm.timers[timestamp] := timer
		}
		Else vars.alarm.timers["xyz|" timer] := timer
	}

	If InStr(vars.log.areaID, "labyrinth_")
		Lab("init")

	settings.mapevents := {"fSize": !Blank(check := ini.mapevents["font-size"]) ? check : settings.general.fSize * 2}
	settings.mapevents.event_list := ["graftblood", "infamous", "hideout"]
	LLK_FontDimensions(settings.mapevents.fSize, font_height, font_width), settings.mapevents.fHeight := font_height, settings.mapevents.fWidth := font_width
	settings.mapevents.color := !Blank(check := ini.mapevents["font-color"]) ? check : "FF0000"
	settings.mapevents.color1 := !Blank(check := ini.mapevents["background color"]) ? check : "FFFFFF"
	settings.mapevents.duration := !Blank(check := ini.mapevents.duration) ? check : 5
	settings.mapevents.opacity := !Blank(check := ini.mapevents.opacity) ? check : 5
	settings.mapevents.position := !Blank(check := ini.mapevents.position) ? check : 1
	For index, val in settings.mapevents.event_list
		settings.mapevents[val] := !Blank(check := ini.mapevents["enable " val]) ? check : (val = "hideout" ? 0 : 1)
		, settings.mapevents["color_" val] := !Blank(check := ini.mapevents["text-color " val]) ? check : "FF0000", settings.mapevents["color1_" val] := !Blank(check := ini.mapevents["background-color " val]) ? check : "FFFFFF"
	Loop 3
		settings.mapevents["hideout_t" A_Index] := !Blank(check := ini.mapevents["hideout T" A_Index]) ? check : 1

	settings.notepad := {"fSize": !Blank(check := ini.notepad["font-size"]) ? check : settings.general.fSize}
	LLK_FontDimensions(settings.notepad.fSize, font_height, font_width), settings.notepad.fHeight := font_height, settings.notepad.fWidth := font_width
	settings.notepad.color := !Blank(check := ini.notepad["font-color"]) ? check : "FFFFFF"
	settings.notepad.color1 := !Blank(check := ini.notepad["background color"]) ? check : "000000"
	settings.notepad.trans := !Blank(check := ini.notepad["transparency"]) ? check : 5, settings.notepad.trans := (settings.notepad.trans > 5) ? 5 : settings.notepad.trans
	settings.notepad.xQuickNote := !Blank(check := ini.notepad["x-coordinate quicknote"]) ? check : ""
	settings.notepad.yQuickNote := !Blank(check := ini.notepad["y-coordinate quicknote"]) ? check : ""
	vars.notepad := {"toggle": 0}, vars.notepad_widgets := {}, vars.hwnd.notepad_widgets := {}

	settings.quickpob := {"exe": ["", "Path of Building" (vars.poe_version ? "-PoE2" : "") ".exe"]}
	settings.quickpob.exe.1 := (!Blank(check := ini.quickpob["install folder"]) ? check : "")
	If !FileExist(settings.quickpob.exe.1)
		settings.quickpob.exe.1 := ""
    settings.quickpob.hotkey := ""
	settings.quickpob.hotkey_alt := (!Blank(check := ini.quickpob["alt modifier"]) ? check : 0)
	settings.quickpob.hotkey_ctrl := (!Blank(check := ini.quickpob["ctrl modifier"]) ? check : 0)
	settings.quickpob.snip_offset := (!Blank(check := ini.quickpob["snip offset"]) ? check : 0)
	settings.quickpob.mode := (!Blank(check := ini.quickpob.mode) ? check : "full")
	If !Blank(settings.quickpob.hotkey) && Hotkeys_Convert(settings.quickpob.hotkey)
	{
		Hotkey, IfWinActive, % "ahk_group poe_window"
		Hotkey, % Hotkeys_Convert((settings.quickpob.hotkey_alt ? "!" : "") . (settings.quickpob.hotkey_ctrl ? "^" : "") . settings.quickpob.hotkey), QuickPob, On
	}
	Else settings.quickpob.hotkey := ""
}

Alarm(hotkey := 1, cHWND := "", mode := "")
{
	local
	global vars, settings
	static toggle := 0, tick := 0

	mode := (mode = "expired") ? mode : "", tick += 1

	If (A_Gui = "alarm_set" || hotkey = "alarm_set") || (hotkey = 2 && cHWND = vars.hwnd.alarm.new)
	{
		If (hotkey = "alarm_set") && (cHWND = vars.hwnd.alarm.alarm_set.cancel)
		{
			Hotkeys_ESC()
			Return
		}
		time := A_Now, sections := [], units := ["seconds", "minutes", "hours"]
		input := LLK_ControlGet(vars.hwnd.alarm.alarm_set.edit), input := !input ? 0 : input
		If Blank(vars.alarm.override)
		{
			input1 := LLK_ControlGet(vars.hwnd.alarm.alarm_set.edit1)
			Loop, Parse, input1, µ, % " |;,."
				input1 := A_LoopField
			If !Blank(input1) && (LLK_PatternMatch(input1, "", ["[", "]", "="]))
				error := 1
		}
		Else input1 := vars.alarm.override

		WinGetPos, x, y, w, h, % "ahk_id " vars.hwnd.alarm.alarm_set.edit
		Loop, Parse, % (input := StrReplace(input, " ", ":")), % ":"
		{
			If Blank(A_LoopField) || (A_Index > 3) || !IsNumber(A_LoopField)
				error := 1
			sections.InsertAt(1, A_LoopField)
		}
		If !InStr(input, ":") && !IsNumber(input) || error
		{
			LLK_ToolTip(Lang_Trans("global_errorname", 2),, x, y + h,, "red")
			Return
		}
		For index, section in sections
			EnvAdd, time, section, % units[index]
		time .= "|"
		While vars.alarm.timers.HasKey(time)
			time .= "|"
		If !Blank(input1) && (check := LLK_HasVal(vars.alarm.timers, input1))
			vars.alarm.timers.Delete(check)
		vars.alarm.timers[time] := input1, x := y := w := h := ""
		If !Blank(input1)
			IniWrite, % """[" StrReplace(time, "|") ",""" (vars.alarm.defaults[input1] := (!input ? "" : input)) """]""", % "ini" vars.poe_version "\qol tools.ini", alarm - timers, % input1
		Gui, alarm_set: Destroy
		vars.hwnd.alarm.alarm_set := ""
		WinActivate, ahk_group poe_window
		If !(hotkey = 2 && cHWND = vars.hwnd.alarm.new)
			Return
	}
	Else If !Blank(cHWND)
	{
		check := LLK_HasVal(vars.hwnd.alarm, cHWND), control := SubStr(check, InStr(check, "_") + 1)
		If (check = "drag")
		{
			start := A_TickCount, vars.alarm.drag := 1
			WinGetPos,,, w, h, % "ahk_id "vars.hwnd.alarm.main
			While GetKeyState("LButton", "P")
				If (A_TickCount >= start + 500)
				{
					If !transform
					{
						Gui, % Gui_Name(vars.hwnd.alarm.main) ": +E0x20"
						transform := 1
					}
					LLK_Drag(w, h, x, y,, "alarm" toggle, 1)
					Sleep 1
				}
			vars.general.drag := 0
			If WinExist("ahk_id "vars.hwnd.alarm.main)
				Gui, % Gui_Name(vars.hwnd.alarm.main) ": -E0x20"
			If transform
			{
				settings.alarm.xPos := (Blank(x) ? "center" : x), settings.alarm.yPos := (Blank(y) ? "center" : y)
				IniWrite, % settings.alarm.xPos, % "ini" vars.poe_version "\qol tools.ini", alarm, x-coordinate
				IniWrite, % settings.alarm.yPos, % "ini" vars.poe_version "\qol tools.ini", alarm, y-coordinate
			}
			vars.alarm.drag := 0
			Return
		}
		Else If InStr(check, "pauseresume_")
		{
			If !IsObject(vars.alarm.single_use[control])
				vars.alarm.single_use[control] := {"offset": -1, "pause": 0}
			vars.alarm.single_use[control].pause := !vars.alarm.single_use[control].pause
			Return
		}
		Else If (check = "new") || (cHWND = "start")
		{
			KeyWait, LButton
			Gui, alarm_set: New, % "-DPIScale -Caption +LastFound +AlwaysOnTop +ToolWindow HWNDalarm_set", LLK-UI: alarm set
			Gui, alarm_set: Color, Black
			Gui, alarm_set: Margin, 0, 0
			Gui, alarm_set: Font, % "s" Max(6, settings.alarm.fSize * 0.7) " cWhite", % vars.system.font
			vars.hwnd.alarm.alarm_set := {"main": alarm_set}, LLK_PanelDimensions([Lang_Trans("global_name"), Lang_Trans("global_time")], Max(6, settings.alarm.fSize * 0.7), wText, hText)

			Gui, alarm_set: Add, Edit, % "r1 Hidden w" vars.alarm.wTimers
			Gui, alarm_set: Add, Text, % "xp yp hp Section Right Border 0x200 w" wText, % Lang_Trans("global_time") " "
			Gui, alarm_set: Add, Edit, % "ys x+-1 cBlack HWNDhwnd Center r1 w" vars.alarm.wTimers, % vars.alarm.defaults[vars.alarm.override]
			If !(cHWND = "start")
			{
				Gui, alarm_set: Add, Text, % "Section hp xs y+-1 Right Border 0x200 w" wText, % Lang_Trans("global_name") " "
				Gui, alarm_set: Add, Edit, % "ys x+-1 cBlack Center Limit HWNDhwnd1 r1 w" vars.alarm.wTimers
				vars.alarm.override := ""
			}
			vars.hwnd.alarm.alarm_set.edit := vars.hwnd.help_tooltips["alarm_set time"] := hwnd, vars.hwnd.alarm.alarm_set.edit1 := vars.hwnd.help_tooltips["alarm_set name"] := hwnd1
			Gui, alarm_set: Add, Button, % "xp yp hp wp Hidden Default gAlarm cBlack", OK

			If (cHWND = "start")
			{
				WinGetPos, xEdit, yEdit, wEdit, hEdit, % "ahk_id " vars.hwnd.alarm["timer_" vars.alarm.override]
				xPos := xEdit - wText + 1, yPos := yEdit
			}
			Else xPos := vars.alarm.xPanel + vars.alarm.wPanel//2 - wText, yPos := vars.alarm.yPanel

			Gui, alarm_set: Add, Text, % "Section xs y+-1 Center Border HWNDhwnd 0x200 w" Round((wText + vars.alarm.wTimers - 1) / 2), % Lang_Trans("global_start")
			Gui, alarm_set: Add, Text, % "ys Center Border HWNDhwnd1 0x200 w" Round((wText + vars.alarm.wTimers - 1) / 2) " x+" (Mod(wText + vars.alarm.wTimers - 1, 2) ? -1 : 0), % Lang_Trans("global_cancel")
			vars.hwnd.alarm.alarm_set.start := hwnd, vars.hwnd.alarm.alarm_set.cancel := hwnd1
			Gui, alarm_set: Show, % "NA x10000 y10000"

			WinGetPos, xWin, yWin, wWin, hWin, ahk_id %alarm_set%
			xPos := (xPos < vars.monitor.x) ? vars.monitor.x : (xPos + wWin >= vars.monitor.x + vars.monitor.w) ? vars.monitor.x + vars.monitor.w - wWin : xPos
			yPos := (yPos + hWin >= vars.monitor.y + vars.monitor.h) ? vars.monitor.y + vars.monitor.h - hWin : yPos
			Gui, alarm_set: Show, % "NA x" xPos " y" yPos
			ControlFocus,, ahk_id %hwnd%
			Return
		}
		Else If InStr(check, "name_")
		{
			vars.alarm.drag := 1
			If LLK_Progress(cHWND, "RButton")
			{
				pCheck := LLK_HasVal(vars.alarm.timers, control)
				vars.alarm.timers.Delete(pCheck), vars.alarm.defaults.Delete(pCheck)
				IniDelete, % "ini" vars.poe_version "\qol tools.ini", alarm - timers, % control
				KeyWait, RButton
			}
			Else
			{
				vars.alarm.drag := 0
				Return
			}
			mode := vars.alarm.toggle ? "" : "expired"
		}
		Else If InStr(check, "timer_")
		{
			vars.alarm.drag := 1, pCheck := LLK_HasVal(vars.alarm.timers, control)
			If (hotkey = 2)
			{
				KeyWait, RButton
				If (SubStr(control, 0) != "|")
				{
					vars.alarm.timers.Delete(pCheck)
					vars.alarm.timers["xyz|" control] := control
					IniWrite, % """[0,""" (vars.alarm.defaults[control] ? vars.alarm.defaults[control] : "") """]""", % "ini" vars.poe_version "\qol tools.ini", alarm - timers, % control
				}
				Else vars.alarm.timers.Delete(control), vars.alarm.single_use.Delete(control)
			}
			Else If (hotkey = 1)
			{
				KeyWait, LButton
				If !InStr(pCheck, "xyz|")
				{
					If (pCheck > A_Now)
					{
						vars.alarm.drag := 0
						Return
					}
					If (SubStr(control, 0) != "|")
						vars.alarm.timers.Delete(pCheck)
					Else vars.alarm.timers.Delete(control)

					time := A_Now "|"
					While vars.alarm.timers.HasKey(time)
						time .= "|"
					If (SubStr(control, 0) != "|")
					{
						vars.alarm.timers[time] := control
						IniWrite, % "", % "ini" vars.poe_version "\qol tools.ini", alarm - timers, % control
					}
					Else vars.alarm.timers[time] := ""
				}
				Else If InStr(pCheck, "xyz|")
				{
					vars.alarm.override := control
					Alarm("", "start"), vars.alarm.drag := 0
					Return
				}
			}
			vars.alarm.drag := 0
			mode := vars.alarm.toggle ? "" : "expired"
		}
		Else If (check = "orientation")
		{
			settings.alarm.orientation := (settings.alarm.orientation = "horizontal") ? "vertical" : "horizontal"
			IniWrite, % settings.alarm.orientation, % "ini" vars.poe_version "\qol tools.ini", alarm, orientation
			Alarm()
		}
		Else LLK_ToolTip("no action")
	}

	toggle := !toggle, GUI_name := "alarm" toggle, vars.alarm.override := ""
	Gui, %GUI_name%: New, % "-DPIScale -Caption +LastFound +AlwaysOnTop +ToolWindow +E0x02000000 +E0x00080000 HWNDalarm"
	Gui, %GUI_name%: Color, Purple
	WinSet, TransColor, % "Purple"
	Gui, %GUI_name%: Margin, % 0, 0
	Gui, %GUI_name%: Font, % "s" settings.alarm.fSize " c" settings.alarm.color, % vars.system.font
	hwnd_old := vars.hwnd.alarm.main, vars.hwnd.alarm := {"main": alarm, "alarm_set": vars.hwnd.alarm.alarm_set.Clone()}, orientation := settings.alarm.orientation
	LLK_PanelDimensions(["77:77:77"], settings.alarm.fSize, wTimers, hTimers), added := 0, section := (orientation = "horizontal" ? "ys x+" settings.alarm.fWidth//2 : "xs y+" settings.alarm.fWidth//2), section2 := (section = "ys") ? "xs y+" settings.alarm.fWidth//2 : "ys x+" settings.alarm.fWidth//2
	vars.alarm.wTimers := wTimers

	If Blank(mode)
	{
		Gui, %GUI_name%: Add, Text, % "Border BackgroundTrans w" settings.alarm.fHeight//3 " h" settings.alarm.fHeight//3, % ""
		Gui, %GUI_name%: Add, Progress, % "xp yp wp hp Disabled HWNDhwnd0 BackgroundWhite", 0
		Gui, %GUI_name%: Add, Text, % "Section xp yp Border BackgroundTrans Center w" (orientation = "horizontal" ? settings.alarm.fHeight : wTimers//2), % "+"
		Gui, %GUI_name%: Add, Progress, % "xp yp wp hp Disabled HWNDhwnd Background" settings.alarm.color1, 0
		vars.hwnd.alarm.drag := vars.hwnd.help_tooltips["alarm_drag"] := hwnd0, vars.hwnd.alarm.new := vars.hwnd.help_tooltips["alarm_add"] := hwnd

		If (orientation = "vertical")
		{
			Gui, %GUI_name%: Add, Text, % "ys x+0 Border BackgroundTrans Center w" (orientation = "horizontal" ? settings.alarm.fHeight : wTimers//2), % ">"
			Gui, %GUI_name%: Add, Progress, % "xp yp wp hp Disabled HWNDhwnd Background" settings.alarm.color1, 0
			vars.hwnd.alarm.orientation := vars.hwnd.help_tooltips["alarm_orientation"] := hwnd
		}
	}

	For timestamp, description in vars.alarm.timers
	{
		offset := vars.alarm.single_use[timestamp].offset, offset := (!offset ? 0 : offset), pause := vars.alarm.single_use[timestamp].pause
		timestamp0 := timestamp, timestamp := StrReplace(timestamp, "|")
		If (mode = "expired") && (timestamp > A_Now)
			Continue
		timer := timestamp
		EnvAdd, timer, offset, seconds
		EnvSub, timer, A_Now, seconds
		color := " c" settings.alarm["color" (timestamp < A_Now ? "1" : "")], color1 := settings.alarm["color" (timestamp < A_Now ? "" : "1")]
		If (mode = "expired") && (Mod(tick, 2) || pause)
			buffer := SubStr(color, 3), color := " c" color1, color1 := buffer
		Gui, %GUI_name%: Add, Text, % ((A_Index != 1 || Blank(mode)) && (Blank(mode) || mode = "expired") ? section : "") " Section Border BackgroundTrans Center w" wTimers . color, % FormatSeconds(Abs(timer), 0)
		Gui, %GUI_name%: Add, Progress, % "xp yp wp hp Disabled HWNDhwnd0 Background" color1, 0

		Gui, %GUI_name%: Font, % "s" Max(6, settings.alarm.fSize * 0.7)
		Gui, %GUI_name%: Add, Text, % "xs y+-1 Border BackgroundTrans Center wp", % (!Blank(description) ? description : Lang_Trans("global_" (pause ? "resume" : "pause")))
		Gui, %GUI_name%: Add, Progress, % "xp yp wp hp Disabled HWNDhwnd Vertical Range0-500 Background" settings.alarm.color1 " c" settings.alarm.color, 0
		Gui, %GUI_name%: Font, % "s" settings.alarm.fSize
		If !Blank(description)
		{
			vars.hwnd.alarm["name_" description] := hwnd
			If vars.alarm.toggle
				vars.hwnd.help_tooltips["alarm_name" handle] := hwnd
		}
		Else
		{
			description := timestamp0
			vars.hwnd.alarm["pauseresume_" description] := hwnd
		}

		If vars.alarm.toggle
			vars.hwnd.help_tooltips["alarm_timer" (Blank(timer) ? " idle" : "") handle] := hwnd0
		vars.hwnd.alarm["timer_" description] := hwnd0, handle .= "|"
	}

	If Blank(mode) && (orientation = "horizontal")
	{
		Gui, %GUI_name%: Font, % "s" settings.alarm.fSize * 0.7
		Gui, %GUI_name%: Add, Text, % section " Section Border BackgroundTrans Center 0x200 w" settings.alarm.fHeight " h" settings.alarm.fHeight, % "v"
		Gui, %GUI_name%: Add, Progress, % "xp yp wp hp Disabled HWNDhwnd Background" settings.alarm.color1, 0
		Gui, %GUI_name%: Font, % "s" settings.alarm.fSize
		vars.hwnd.alarm.orientation := vars.hwnd.help_tooltips["alarm_orientation"] := hwnd
	}

	Gui, %GUI_name%: Show, % "NA x10000 y10000"
	WinGetPos,,, w, h, ahk_id %alarm%
	If (w < 25)
		Gui, %GUI_name%: Destroy
	Else
	{
		xPos := (settings.alarm.xPos = "center") ? vars.client.xc - w / 2 + 1 : settings.alarm.xPos, xPos := (xPos >= vars.monitor.w / 2) ? xPos - w + 1 : xPos
		xPos := (xPos >= vars.monitor.w) ? vars.monitor.w - w : xPos
		yPos := (settings.alarm.yPos = "center") ? vars.client.yc - h / 2 + 1 : settings.alarm.yPos, yPos := (yPos >= vars.monitor.h / 2) ? yPos - h + 1 : yPos
		yPos := (yPos >= vars.monitor.h) ? vars.monitor.h - h : yPos
		Gui, %GUI_name%: Show, % "NA x" vars.monitor.x + xPos " y" vars.monitor.y + yPos
		WinGetPos, x, y, w, h, ahk_id %alarm%
		vars.alarm.xPanel := x, vars.alarm.yPanel := y, vars.alarm.wPanel := w, vars.alarm.hPanel := h
		LLK_Overlay(alarm, "show",, GUI_name)
	}
	LLK_Overlay(hwnd_old, "destroy"), vars.alarm.drag := 0
}

Alarm_Close()
{
	local
	global vars, settings

	If WinExist("ahk_id " vars.hwnd.alarm.main)
		LLK_Overlay(vars.hwnd.alarm.main, "destroy")
	Else SetTimer, Alarm_Close, Delete
}

Distilled_Emotions()
{
	local
	global vars, settings
	static emotions := ["isolation", "suffering", "fear", "despair", "disgust", "envy", "paranoia", "greed", "guilt", "ire"]

	GUI_name := "distilled_emotions", LLK_PanelDimensions(emotions, settings.general.fSize, width, height)
	Gui, %GUI_name%: New, -Caption -DPIScale +LastFound +AlwaysOnTop +ToolWindow +Border +E0x02000000 +E0x00080000 HWNDhwnd_emotions
	Gui, %GUI_name%: Color, Black
	Gui, %GUI_name%: Margin, 0, 0
	Gui, %GUI_name%: Font, % "s" settings.general.fSize " cWhite", % vars.system.font

	For index, val in emotions
		Gui, %GUI_name%: Add, Text, % "xs Center w" width . (InStr(vars.omnikey.item.name, val) ? " cLime" : ""), % val

	Gui, %GUI_name%: Show, NA x10000 y10000
	WinGetPos, xWin, yWin, wWin, hWin, ahk_id %hwnd_emotions%
	xPos := vars.general.xMouse - wWin//2, yPos := vars.general.yMouse - hWin, Gui_CheckBounds(xPos, yPos, wWin, hWin)
	Gui, %GUI_name%: Show, % "NA x" xPos " y" yPos
	LLK_Overlay(hwnd_emotions, "show",, "distilled_emotions")
	KeyWait, % vars.omnikey.hotkey
	KeyWait, % vars.omnikey.hotkey2
	LLK_Overlay(hwnd_emotions, "destroy")
}

EssenceTooltip(cHWND)
{
	local
	global vars, settings, db
	static control, widths := {}, toggle := 0

	check := LLK_HasVal(vars.hwnd.essences, cHWND)
	If WinExist("ahk_id "vars.hwnd.essences.main) && (control = check)
		Return
	control := check

	If !IsObject(db.essences)
		DB_Load("essences")

	name := vars.omnikey.item.name, tier := SubStr(name, 1, InStr(name, " ") - 1), tier := LLK_HasVal(db.essences._tiers, tier), left_column := [], right_column := [], columns := {}
	For type0 in db.essences
		If InStr(vars.omnikey.item.name, type0)
			type := type0
	If !type
		Return
	For index, val in db.essences[type][tier].1
		left_column.Push(val)
	For index, val in db.essences[type][tier + 1].1
		left_column.Push(val)
	For index, val in db.essences[type][tier].2
		right_column.Push(val)
	For index, val in db.essences[type][tier + 1].2
		right_column.Push(val)
	If !widths.HasKey(type "_"tier)
		LLK_PanelDimensions(left_column, settings.general.fSize, wColumn1, height), LLK_PanelDimensions(right_column, settings.general.fSize, wColumn2, height), widths[type "_"tier] := [wColumn1, wColumn2]

	toggle := !toggle, GUI_name := "essences" toggle
	Gui, %GUI_name%: New, -Caption -DPIScale +LastFound +AlwaysOnTop +ToolWindow +Border +E0x02000000 +E0x00080000 HWNDessences
	Gui, %GUI_name%: Color, Black
	Gui, %GUI_name%: Margin, 0, 0
	Gui, %GUI_name%: Font, % "s"settings.general.fSize " cWhite", % vars.system.font
	hwnd_old := vars.hwnd.essences.main, vars.hwnd.essences := {"main": essences}

	For index, val in db.essences[type][tier].1
	{
		Gui, %GUI_name%: Add, Text, % "Center Border 0x200 HWNDhwnd w"widths[type "_"tier].1 (A_Index = 1 ? " Section" : " xs Section"), % LLK_HasVal(db.essences[type][tier + 1].1, val) && (check = val) ? val "`n" : val
		columns[val] := 1
		If !Blank(LLK_HasVal(db.essences[type][tier + 1].1, val))
			vars.hwnd.essences[val] := hwnd
		Gui, %GUI_name%: Add, Text, % "Border BackgroundTrans ys w"widths[type "_"tier].2, % " " db.essences[type][tier].2[index] (LLK_HasVal(db.essences[type][tier + 1].1, val) && (check = val) ? "`n " : "")
		If !Blank(LLK_HasVal(db.essences[type][tier + 1].1, val)) && (check = val)
			Gui, %GUI_name%: Add, Text, % "Border xp wp wp hp cLime", % " `n " db.essences[type][tier + 1].2[LLK_HasVal(db.essences[type][tier + 1].1, val)]
	}
	For index, val in db.essences[type][tier + 1].1
	{
		If columns[val]
			Continue
		Gui, %GUI_name%: Add, Text, % "xs Section Center Border 0x200 cLime w"widths[type "_"tier].1, % val
		Gui, %GUI_name%: Add, Text, % "Border BackgroundTrans ys cLime w"widths[type "_"tier].2, % " " db.essences[type][tier + 1].2[index]
	}
	If WinExist("ahk_id "hwnd_old)
		WinGetPos, xPos, yPos,,, ahk_id %hwnd_old%
	Else
	{
		Gui, %GUI_name%: Show, NA x10000 y10000
		WinGetPos,,, w, h, ahk_id %essences%
		xPos := (vars.general.xMouse + vars.monitor.w/100 + w - 1 > vars.monitor.x + vars.monitor.w - 1) ? vars.monitor.x + vars.monitor.w - w + 1 : vars.general.xMouse + vars.monitor.w/100
		yPos := (vars.general.yMouse - h/2 > vars.monitor.y + vars.monitor.h - 1) ? vars.monitor.y + vars.monitor.h - h + 1 : vars.general.yMouse - h/2
	}
	Gui, %GUI_name%: Show, % "NA x"xPos " y"yPos
	LLK_Overlay(essences, "show",, GUI_name), LLK_Overlay(hwnd_old, "destroy")
}

Lab(mode := "", override := 0)
{
	local
	global vars, settings, Json
	static toggle := 0

	start := A_TickCount, check := LLK_HasVal(vars.hwnd.lab, vars.general.cMouse), control := SubStr(check, InStr(check, "_") + 1)
	While (mode = "override") && GetKeyState("LButton", "P") && (vars.lab.compass.rooms[control].name = vars.log.areaname)
		If (A_TickCount >= start + 250)
			vars.lab.rooms[vars.lab.room.1] := "", mode := "progress", override := control

	If (mode = "override")
		Return

	If !IsObject(vars.lab) || (mode = "init")
		vars.lab := {"rooms": []}

	If (mode = "link")
	{
		If GetKeyState(vars.hotkeys.tab, "P")
			LLK_ToolTip(Lang_Trans("global_releasekey") " " vars.hotkeys.tab, 0,,, "poelab"), vars.alarm.toggle := 0, LLK_Overlay(vars.hwnd.alarm.main, "destroy")
		KeyWait, % vars.hotkeys.tab
		LLK_Overlay(vars.hwnd.tooltip_poelab, "destroy"), LLK_Overlay(vars.hwnd.lab.main, "destroy"), LLK_Overlay(vars.hwnd.lab.button, "destroy"), vars.lab.toggle := 0
		Run, % "https://www.poelab.com/"
		WinWaitActive, ahk_group snipping_tools,, 0.5
		ToolTip_Mouse("lab", 1)
	}

	If (mode = "import" || mode = "link")
	{
		WinWaitNotActive, ahk_group poe_window,, 2
		Clipboard := ""
		LLK_ToolTip("to support poelab, please consider disabling ad-block and leaving the site open in the background while running lab", 0, vars.client.x + vars.client.w/2, vars.client.y, "poelab_support", "Yellow",,,, 1,, 1, vars.client.w/4)
		While !WinActive("ahk_group poe_window")
		{
			If !step
				pBitmap := Gdip_CreateBitmapFromClipboard()
			If !step && (pBitmap > 0)
			{
				LLK_ToolTip(Lang_Trans("global_success"), 1.5,,,, "lime")
				Clipboard := "", vars.lab := {"rooms": []}
				FileDelete, img\lab compass.json
				step := 1
			}
			If (step = 1) && InStr(Clipboard, "www.poelab.com") && InStr(Clipboard, ".json")
			{
				step := 2
				Try lab_compass_json := Json.Load(HTTPtoVar(Clipboard))
				If lab_compass_json.Count()
				{
					LLK_ToolTip(Lang_Trans("global_success"), 1.5,,,, "lime")
					Loop, % lab_compass_json.rooms.Count()
						roomname := lab_compass_json.rooms[A_Index].name, lab_compass_json.rooms[A_Index].name := Lang_Trans("lab_" roomname) ? Lang_Trans("lab_" roomname) : roomname
					FileAppend, % Json.Dump(lab_compass_json), img\lab compass.json
					vars.tooltip_mouse := ""
					Break
				}
				Run, % Clipboard
				Sleep, 500
				Clipboard := ""
			}
			If (step = 2) && InStr(Clipboard, """difficulty"":")
			{
				Try lab_compass_json := Json.Load(Clipboard)
				If lab_compass_json.Count()
				{
					LLK_ToolTip(Lang_Trans("global_success"), 1.5,,,, "lime")
					Loop, % lab_compass_json.rooms.Count()
						roomname := lab_compass_json.rooms[A_Index].name, lab_compass_json.rooms[A_Index].name := Lang_Trans("lab_" roomname) ? Lang_Trans("lab_" roomname) : roomname
					FileAppend, % Json.Dump(lab_compass_json), img\lab compass.json
					vars.tooltip_mouse := ""
					Break
				}
				Else LLK_ToolTip(Lang_Trans("global_fail"), 1.5,,,, "red")
				Clipboard := ""
			}
			Sleep 250
		}
		WinWaitActive, ahk_group poe_window
		vars.tooltip[vars.hwnd.tooltip_poelab_support] := A_TickCount + 1000

		If !step
		{
			LLK_ToolTip(Lang_Trans("global_abort"), 1.5, vars.monitor.x + vars.client.xc, vars.monitor.y + vars.client.yc,, "red", settings.general.fSize + 8,,, 1), Gdip_DisposeImage(pBitmap)
			Return
		}
		pBitmap_copy := Gdip_CloneBitmapArea(pBitmap, 257, 42, 1175, 556,, 1), Gdip_DisposeImage(pBitmap)
		pBitmap := Gdip_ResizeBitmap(pBitmap_copy, vars.client.w * 53/128, 10000, 1, 7, 1)
		Gdip_SaveBitmapToFile(pBitmap, "img\lab.jpg", 100), Gdip_DisposeImage(pBitmap_copy), Gdip_DisposeImage(pBitmap)
		If vars.pics.lab.lab
			Gdip_DisposeImage(vars.pics.lab.lab), vars.pics.lab.lab := ""
		Return
	}

	If !FileExist("img\lab.jpg")
		FileDelete, img\lab compass.json

	If !IsObject(vars.lab.compass) && FileExist("img\lab compass.json")
		vars.lab.compass := LLK_FileRead("img\lab compass.json"), vars.lab.compass := Json.Load(vars.lab.compass)
	If !vars.lab.scale
		pBitmap := Gdip_LoadImageFromFile("img\lab.jpg"), Gdip_GetImageDimensions(pBitmap, w, h), vars.lab.width := !w ? vars.client.w * 53/128 : w, vars.lab.height := !h ? (vars.client.w * 53/128)/2.112 : h, vars.lab.scale := vars.lab.width/1175, Gdip_DisposeImage(pBitmap)

	scale := vars.lab.scale, dim := 50 * scale, difficulties := {33: "normal", 55: "cruel", 68: "merciless", 75: "uber", 83: "uber"}, text_height := dim/2
	If !vars.lab.custom_font
		vars.lab.custom_font := LLK_FontSizeGet(text_height, width)

	If !vars.lab.rooms.Count()
	{
		If InStr(vars.log.areaID, "labyrinth_") && !InStr(vars.log.areaID, "airlock")
		{
			For index, room in vars.lab.compass.rooms
				If (room.name = vars.log.areaname)
				{
					vars.lab.room := [index, room.name], vars.lab.rooms[index] := {"name": room.name, "seed": ""}
					Break
				}
		}
		Else vars.lab.room := [1, vars.lab.compass.rooms.1.name], vars.lab.rooms.1 := {"name": vars.lab.compass.rooms.1.name, "seed": ""}
		started := 1, vars.lab.outdated := !Blank(vars.lab.compass.date) && (StrReplace(vars.lab.compass.date, "-") != SubStr(A_NowUTC, 1, 8)) ? 1 : 0
	}

	If (mode = "progress") && !started
	{
		vars.lab.room := [override ? override : vars.lab.exits.numbers[LLK_HasVal(vars.lab.exits.names, vars.log.areaname)], override ? vars.lab.compass.rooms[override].name : vars.lab.exits.names[LLK_HasVal(vars.lab.exits.names, vars.log.areaname)], vars.log.areaID]
		vars.lab.rooms[vars.lab.room.1] := {"name": vars.log.areaname, "seed": vars.log.areaseed}
	}
	Else If (mode = "backtrack")
		vars.lab.room := [override, vars.lab.rooms[override].name]

	If (vars.lab.room.2 = "aspirant's trial")
		Loop, % vars.lab.compass.rooms.Count()
		{
			If (A_Index = vars.lab.room.1)
				Continue
			Else If (A_Index < vars.lab.room.1)
				vars.lab.rooms[A_Index] := {"name": vars.lab.rooms[A_Index].name ? 1 : 0, "seed": vars.lab.rooms[A_Index].seed ? 1 : 0}
			Else vars.lab.rooms[A_Index] := ""
		}

	vars.lab.exits := {"numbers": [], "names": []}
	For dir, number in vars.lab.compass.rooms[vars.lab.room.1].exits
		vars.lab.exits.numbers.Push(number), vars.lab.exits.names.Push(vars.lab.compass.rooms[number].name)
	If mode && InStr("progress,init,backtrack", mode) && !GetKeyState(vars.hotkeys.tab, "P")
		Return

	toggle := !toggle, GUI_name := "lab_overlay" toggle
	Gui, %GUI_name%: New, % "-DPIScale -Caption +LastFound +AlwaysOnTop +ToolWindow +Border +E0x02000000 +E0x00080000 HWNDlab"
	Gui, %GUI_name%: Color, Black
	Gui, %GUI_name%: Margin, 0, 0
	Gui, %GUI_name%: Font, % "s"vars.lab.custom_font " cWhite", % vars.system.font
	hwnd_old := vars.hwnd.lab.main, hwnd_old2 := vars.hwnd.lab.button, vars.hwnd.lab := {"main": lab}

	If !IsObject(vars.pics.lab)
	{
		vars.pics.lab := {}
		For index, val in ["square_red_trans", "square_purple_trans", "square_green_trans", "square_trans", "lab1", "lab2", "lab3"]
			vars.pics.lab[val] := LLK_ImageCache("img\GUI\" val ".png")
	}

	If vars.lab.outdated
	{
		Gui, %GUI_name%: Font, % "s"LLK_FontSizeGet(vars.lab.height/8, width)
		Gui, %GUI_name%: Add, Text, % "BackgroundTrans Center w"vars.lab.width " h"vars.lab.height, % "`n`n" Lang_Trans("lab_outdated") "`n`n" Lang_Trans("lab_outdated", 2) " " vars.lab.compass.date "`n" Lang_Trans("lab_outdated", 3) " " SubStr(A_NowUTC, 1, 4) "-" SubStr(A_NowUTC, 5, 2) "-" SubStr(A_NowUTC, 7, 2)
		Gui, %GUI_name%: Font, % "s"vars.lab.custom_font
		Gui, %GUI_name%: Add, Pic, % "x0 y0 BackgroundTrans w"vars.lab.width " h"vars.lab.height, % "HBitmap:*" vars.pics.lab.square_red_trans
	}
	Else If !InStr(vars.log.areaID, "airlock") && !Blank(vars.lab.compass.difficulty) && (difficulties[vars.log.arealevel] != vars.lab.compass.difficulty)
	{
		Gui, %GUI_name%: Font, % "s"LLK_FontSizeGet(vars.lab.height/8, width)
		Gui, %GUI_name%: Add, Text, % "BackgroundTrans Center w"vars.lab.width " h"vars.lab.height, % "`n`n" Lang_Trans("lab_mismatch") "`n`n" Lang_Trans("lab_outdated", 2) " " vars.lab.compass.difficulty "`n" Lang_Trans("lab_mismatch", 2) " " difficulties[vars.log.arealevel]
		Gui, %GUI_name%: Font, % "s"vars.lab.custom_font
		Gui, %GUI_name%: Add, Pic, % "x0 y0 BackgroundTrans w"vars.lab.width " h"vars.lab.height, % "HBitmap:*" vars.pics.lab.square_red_trans
		vars.lab.mismatch := 1
	}

	For index, room in vars.lab.compass.rooms
	{
		If InStr(vars.log.areaID, "airlock") || vars.lab.mismatch || vars.lab.outdated
			Continue
		If !Blank(LLK_HasVal(vars.lab.exits.numbers, index)) && (vars.lab.exits.numbers.Count() > 1) && !(vars.lab.room.2 = "aspirant's trial" && index > vars.lab.room.1) ;&& !(vars.lab.room.1 > index)
			Gui, %GUI_name%: Add, Text, % "BackgroundTrans Center x"(room.x + 12) * scale - dim/2 " w"dim*2 " y"(room.y + 48) * scale - text_height, % SubStr(room.name, 1, 2) " " SubStr(room.name, InStr(room.name, " ") + 1, 2)
		If (vars.lab.room.1 = index)
			Gui, %GUI_name%: Add, Pic, % "BackgroundTrans HWNDhwnd x"(room.x + 12) * scale " w"dim " h"dim " y"(room.y + 48) * scale, % "HBitmap:*" vars.pics.lab.square_purple_trans
		Else If vars.lab.rooms[index].Count() && vars.lab.rooms[index].name
			Gui, %GUI_name%: Add, Pic, % "BackgroundTrans HWNDhwnd x"(room.x + 12) * scale " w"dim " h"dim " y"(room.y + 48) * scale, % "HBitmap:*" vars.pics.lab.square_green_trans
		Else Gui, %GUI_name%: Add, Pic, % "BackgroundTrans HWNDhwnd x"(room.x + 12) * scale " w"dim " h"dim " y"(room.y + 48) * scale, % "HBitmap:*" vars.pics.lab.square_trans
		vars.hwnd.lab["square_"index] := vars.hwnd.help_tooltips["lab_square"room.id] := hwnd
	}
	If FileExist("img\lab.jpg")
	{
		If !vars.pics.lab.lab
			vars.pics.lab.lab := LLK_ImageCache("img\lab.jpg")
		Gui, %GUI_name%: Add, Pic, % "x0 y0", % "HBitmap:*" vars.pics.lab.lab
	}
	Else
	{
		Gui, %GUI_name%: Font, % "s"LLK_FontSizeGet(vars.lab.height/8, width)
		Gui, %GUI_name%: Add, Text, % "x0 y0 Center 0x200 w"vars.client.w * 53/128 " h"(vars.client.w * 53/128)/2.112, % Lang_Trans("cheat_loaderror") " img\lab.jpg"
		Gui, %GUI_name%: Font, % "s"vars.lab.custom_font
		file_missing := 1
	}

	Gui, %GUI_name%: Show, % "NA x10000 y10000"
	WinGetPos,,, w, h, ahk_id %lab%
	Gui, %GUI_name%: Show, % "NA x" vars.monitor.x + vars.client.xc - w/2 " y"vars.monitor.y + vars.monitor.h - h
	WinGetPos, x, y,,, ahk_id %lab%

	GUI_name2 := "lab_button" toggle
	Gui, %GUI_name2%: New, % "-DPIScale -Caption +LastFound +AlwaysOnTop +ToolWindow +Border +E0x02000000 +E0x00080000 HWNDlab2"
	Gui, %GUI_name2%: Color, Black
	Gui, %GUI_name2%: Margin, 0, 0
	Gui, %GUI_name2%: Font, % "s"vars.lab.custom_font " cWhite", % vars.system.font

	Gui, %GUI_name2%: Add, Pic, % "h"dim*0.95 " w-1 HWNDhwnd", % "HBitmap:*" vars.pics.lab["lab" (file_missing || vars.lab.outdated || vars.lab.mismatch ? "3" : Blank(vars.lab.compass.difficulty) ? "2" : "1")]
	vars.hwnd.lab.button := lab2, vars.hwnd.help_tooltips["lab_button"] := hwnd
	Gui, %GUI_name2%: Show, % "NA x"x " y"y
	LLK_Overlay(lab, "show",, GUI_name), LLK_Overlay(lab2, "show",, GUI_name2)
	LLK_Overlay(hwnd_old, "destroy"), LLK_Overlay(hwnd_old2, "destroy")
}

MapEvent(type := "")
{
	local
	global vars, settings

	If !type
	{
		type := "hideout", tier := vars.mapevents.hideout.tier
		If (vars.log.areaID != vars.mapevents.hideout.ID || vars.log.areaseed != vars.mapevents.hideout.seed)
		{
			vars.mapevents.hideout := {}
			Return
		}
	}
	text := Lang_Trans("mechanic_" type), color := settings.mapevents["color_" type], background := settings.mapevents["color1_" type]
	If (type = "lootfilter")
		text := Lang_Trans("lootfilter_notification"), color := "Red", background := "White"
	position := settings.mapevents.position, text := (position > 2) ? StrReplace(text, " ", "`n") : text

	If (type = "hideout")
		text .= " (" Lang_Trans("global_tiers", tier) ")"
	LLK_ToolTip(text, settings.mapevents.duration, 10000, 10000, "mapevents_" type, color, settings.mapevents.fSize, (position = 4 ? "Right" : ""), settings.mapevents.opacity * 51,, background)
	WinGetPos,,, Width, Height, % "ahk_id" vars.hwnd["tooltip_mapevents_" type]
	Switch position
	{
		case 1:
		xPos := vars.monitor.x + vars.client.xc - Width/2, yPos := vars.client.y
		case 2:
		xPos := vars.monitor.x + vars.client.xc - Width/2, yPos := vars.client.y + vars.client.h - Height
		case 3:
		xPos := vars.client.x, yPos := vars.monitor.y + vars.client.yc - Height/2
		case 4:
		xPos := vars.client.x + vars.client.w - Width, yPos := vars.monitor.y + vars.client.yc - Height/2
	}
	Gui, % "tooltipmapevents_" type ": Show", % "NA x" xPos " y" yPos
}

MapEvent_Hideout(ID, seed)
{
	local
	global vars, settings
	static hideouts := {"mapworldsterrace": 1, "mapworldshauntedmansion": 1, "mapworldsmoontemple": 1, "mapworldstorturechamber": 1, "mapworldsdig": 1, "mapworldscrimsontemple": 1, "mapworldssunkencity": 1
	, "mapworldssummit": 2, "mapworldstower": 2, "mapworldsiceberg": 2, "mapworldsorchard": 2
	, "mapworldsarcade": 3, "mapworldspromenade": 3, "mapworldsatoll": 3, "mapworldsmoontempleunique": 3, "mapworldsacademy": 3, "mapworldsivorytemple": 3, "mapworldsgraveyard": 3}

	If !((tier := hideouts[ID]) && settings.mapevents["hideout_t" tier])
		Return
	vars.mapevents.hideout := {"ID": ID, "seed": seed, "tier": tier}
	SetTimer, MapEvent, -10000
}

MapEvent_InfamousMerc(clientTXT_line)
{
	local
	global vars, settings, json
	static FirstApproach

	If !IsObject(FirstApproach)
	{
		lang := FileExist("data\" settings.general.lang_client "\mercenaries.json") ? settings.general.lang_client : "english"
		file := LLK_FileRead("data\" lang "\mercenaries.json"), FirstApproach := json.load(file)
	}

	For index, line in FirstApproach
		If InStr(clientTXT_line, line)
			Return 1
}

Notepad(cHWND := "", hotkey := "", color := 0)
{
	local
	global vars, settings
	static toggle := 0, hwnd_reminder, hwnd_reminder_edit

	If (cHWND = "save") ;save any changes made to a note
	{
		If Blank(vars.notepad.selected_entry)
			Return
		check_text := StrReplace(LLK_ControlGet(vars.hwnd.notepad.note), "&&", "&")
		While !Blank(check_text) && InStr(" `n", SubStr(check_text, 1, 1))
			check_text := SubStr(check_text, 2)
		While !Blank(check_text) && InStr(" `n", SubStr(check_text, 0))
			check_text := SubStr(check_text, 1, -1)
		check_text := StrReplace(check_text, "`n", "(n)")
		If (check_text != LLK_IniRead("ini" vars.poe_version "\qol tools.ini", "notepad", vars.notepad.selected_entry))
		{
			IniWrite, % """" check_text """", % "ini" vars.poe_version "\qol tools.ini", notepad, % vars.notepad.selected_entry
			vars.notepad.entries[vars.notepad.selected_entry] := StrReplace(check_text, "(n)", "`n")
			If vars.hwnd.notepad_widgets.HasKey(vars.notepad.selected_entry)
				Notepad_Widget(vars.notepad.selected_entry, 5, color)
		}
		Return
	}
	Else If (cHWND = "color")
	{
		Clipboard := ""
		SendInput, ^{c}
		ClipWait, 0.1
		If !Blank(Clipboard)
		{
			check := LLK_InStrCount(Clipboard, "§")
			If check && ((check != 2) || SubStr(Clipboard, 1, 1) != "§")
			{
				LLK_ToolTip(Lang_Trans("global_error") ": §",,,,, "red"), Clipboard := ""
				Return
			}
			prev_color := InStr(Clipboard, "§") && InStr(Clipboard, ": ") ? SubStr(Clipboard, InStr(Clipboard, "§") + 1, 6): "", color := LLK_StringCase(RGB_Picker(prev_color))
			If !Blank(color)
			{
				Sleep, 100
				parse := Clipboard
				While (SubStr(parse, 1, 1) = " ")
					parse := SubStr(parse, 2)
				While (SubStr(parse, 0) = " ")
					parse := SubStr(parse, 1, -1)
				If (SubStr(parse, 1, 1) = "§")
					Clipboard := StrReplace(Clipboard, SubStr(parse, 1, 9)), Clipboard := StrReplace(Clipboard, "§"), parse := SubStr(parse, 10, -1)
				If (color != prev_color)
					Clipboard := StrReplace(Clipboard, parse, "§" color ": " StrReplace(parse, "`r`n", "§`r`n§" color ": ") "§")
				SendInput, ^{v}
				Sleep 100
				Notepad("save",, 1)
			}
		}
		Return
	}

	start := A_TickCount, check := LLK_HasVal(vars.hwnd.notepad, cHWND), control := SubStr(check, InStr(check, "_") + 1), sum_height := 0, max_width := vars.monitor.w*0.9, max_height := vars.monitor.h*0.9

	If (check = "winbar")
	{
		start := A_TickCount
		WinGetPos, xWin, yWin, wWin, hWin, % "ahk_id " vars.hwnd.notepad.main
		MouseGetPos, xMouse, yMouse
		While GetKeyState("LButton", "P")
		{
			LLK_Drag(wWin, hWin, xPos, yPos, 1,,, xMouse - xWin, yMouse - yWin, 1)
			Sleep 1
		}
		vars.general.drag := 0
		If !Blank(yPos)
			vars.notepad.x := xPos, vars.notepad.y := yPos
		Return
	}
	Else If InStr(check, "color_")
	{
		index := InStr(check, "textcolor_") ? 1 : 2
		If (vars.system.click = 1)
			rgb_picked := RGB_Picker(vars.notepad.settings[control][index])
		If (vars.system.click = 1) && Blank(rgb_picked)
			Return
		Else vars.notepad.settings[control][index] := (vars.system.click = 1) ? rgb_picked : ""
		IniWrite, % (vars.notepad.settings[control].1 = settings.notepad.color ? "" : vars.notepad.settings[control].1) "|" (vars.notepad.settings[control].2 = settings.notepad.color1 ? "" : vars.notepad.settings[control].2), % "ini" vars.poe_version "\qol tools.ini", notepad tab settings, % control
		Notepad("save"), refresh_widget := vars.hwnd.notepad_widgets.HasKey(control) ? 1 : 0
	}
	Else If (A_Gui = "notepad_reminder")
	{
		Notepad_Widget(LLK_ControlGet(hwnd_reminder_edit), -1)
		Gui, notepad_reminder: Destroy
		WinActivate, ahk_group poe_window
		Return
	}
	Else If (cHWND = "quick")
	{
		If !WinExist("ahk_id " vars.hwnd.notepad_widgets.notepad_reminder_feature)
		{
			Gui, notepad_reminder: New, % "-DPIScale -Caption +LastFound +AlwaysOnTop +ToolWindow +Border HWNDhwnd_reminder", LLK-UI: notepad reminder
			Gui, notepad_reminder: Color, Black
			Gui, notepad_reminder: Margin, % settings.general.fWidth/2, % settings.general.fWidth/2
			Gui, notepad_reminder: Font, % "s" settings.general.fSize - 2 " cWhite", % vars.system.font

			Gui, notepad_reminder: Add, Text, Section, quick-note:
			Gui, notepad_reminder: Add, Edit, % "xs cBlack r1 HWNDhwnd_reminder_edit w"settings.general.fWidth*25
			Gui, notepad_reminder: Add, Button, % "Default Hidden xp yp wp hp gNotepad"
			Gui, notepad_reminder: Show, % "NA x10000 y10000"
			WinGetPos,,, width, height, ahk_id %hwnd_reminder%
			Gui, notepad_reminder: Show, % "x" vars.monitor.x + vars.client.xc - width/2 " y" vars.monitor.y + vars.client.yc - height/2
			vars.system.click := 1
			While WinActive("ahk_id " hwnd_reminder)
				Sleep 10
			If WinExist("ahk_id " hwnd_reminder)
				Gui, notepad_reminder: Destroy
		}
		Else LLK_Overlay(vars.hwnd.notepad_widgets.notepad_reminder_feature, "destroy"), vars.hwnd.notepad_widgets.Delete("notepad_reminder_feature")
		WinActivate, ahk_group poe_window
		Return
	}
	Else If (check = "winx") || (cHWND = "open") && WinExist("ahk_id " vars.hwnd.notepad.main)
	{
		KeyWait, LButton
		Notepad("save"), LLK_Overlay(vars.hwnd.notepad.main, "destroy"), vars.hwnd.notepad.main := ""
		Return
	}
	Else If (check = "add")
	{
		name := LLK_ControlGet(vars.hwnd.notepad.name), ini := LLK_IniRead("ini" vars.poe_version "\qol tools.ini", "notepad")
		While (SubStr(name, 1, 1) = " ")
			name := SubStr(name, 2)
		While (SubStr(name, 0) = " ")
			name := SubStr(name, 1, -1)
		Loop, Parse, name
			error := InStr("[=]", A_LoopField) ? Lang_Trans("global_errorname", 5) . "[=]" : error
		If InStr(ini, "`n" name "=")
			error := Lang_Trans("global_errorname", 4)
		If Blank(name) || error
		{
			WinGetPos, x, y, w, h, % "ahk_id "vars.hwnd.notepad.name
			LLK_ToolTip(Lang_Trans("global_errorname", 2) . (error ? ":`n" error : ""), error ? 2 : 1, x, y + h,, "red")
			Return
		}
		Notepad("save"), vars.notepad.selected_entry := name
		IniWrite, % "", % "ini" vars.poe_version "\qol tools.ini", notepad, % name
	}
	Else If InStr(check, "select_")
	{
		start := A_TickCount
		While GetKeyState("LButton", "P")
			If (A_TickCount >= start + 200)
			{
				Notepad("save"), Notepad_Widget(control)
				KeyWait, LButton
				WinActivate, ahk_group poe_window
				Return
			}
		If (hotkey = 2 || vars.system.click = 2)
		{
			If LLK_Progress(vars.hwnd.notepad["delbar_"control], "RButton")
			{
				IniDelete, % "ini" vars.poe_version "\qol tools.ini", notepad, % control
				IniDelete, % "ini" vars.poe_version "\qol tools.ini", notepad tab settings, % control
				vars.notepad.selected_entry := (control = vars.notepad.selected_entry) ? "" : vars.notepad.selected_entry
				If vars.hwnd.notepad_widgets.HasKey(control)
					LLK_Overlay(vars.hwnd.notepad_widgets[control], "destroy"), vars.hwnd.notepad_widgets.Delete(control)
				KeyWait, RButton
			}
			Else Return
		}
		If !Blank(vars.notepad.selected_entry)
			Notepad("save")
		vars.notepad.selected_entry := (hotkey = 1 || vars.system.click = 1) ? control : vars.notepad.selected_entry
	}
	Else If (check = "drag")
	{
		WinGetPos, x0, y0, w0, h0, % "ahk_id " vars.hwnd.notepad.note
		Notepad("save")
		While GetKeyState("LButton", "P")
		{
			MouseGetPos, xMouse, yMouse
			wBox := (xMouse - x0 < settings.general.fWidth*20) ? settings.general.fWidth*20 : (xMouse - x0 > max_width) ? max_width : xMouse - x0
			hBox := (yMouse - y0 < settings.general.fWidth*30) ? settings.general.fWidth*30 : (yMouse - y0 > max_height) ? max_height : yMouse - y0
			Sleep 10
		}
	}
	wBox := !wBox ? settings.notepad.fWidth*20 : wBox, hBox := !hBox ? settings.notepad.fWidth*30 : hBox
	toggle := !toggle, GUI_name := "notepad" toggle
	Gui, %GUI_name%: New, % "-DPIScale -Caption +LastFound +AlwaysOnTop +ToolWindow +Border +E0x02000000 +E0x00080000 HWNDnotepad"
	Gui, %GUI_name%: Color, Black
	Gui, %GUI_name%: Margin, % settings.general.fWidth/2, % settings.general.fWidth/2
	Gui, %GUI_name%: Font, % "s" settings.general.fSize - 2 " cWhite", % vars.system.font
	hwnd_old := vars.hwnd.notepad.main, vars.hwnd.notepad := {"main": notepad}

	Gui, %GUI_name%: Add, Text, % "x-1 y-1 Section HWNDhwnd Center Border gNotepad", RIFT: notepad
	vars.hwnd.notepad.winbar := hwnd
	Gui, %GUI_name%: Add, Text, % "ys x+-1 HWNDhwnd Center Border gNotepad w"settings.general.fWidth*2, x
	vars.hwnd.notepad.winx := hwnd

	Gui, %GUI_name%: Font, % "s" settings.general.fSize
	Gui, %GUI_name%: Add, Text, % "xs Section Hidden Border cBlack x"settings.general.fWidth/2, % "  "
	Gui, %GUI_name%: Add, Text, % "ys x+-1 Hidden Border HWNDhwnd cBlack", % "  "
	ControlGetPos,,, w2,,, ahk_id %hwnd%
	Gui, %GUI_name%: Add, Text, % "ys x+-1 BackgroundTrans HWNDhwnd", % Lang_Trans("notepad_add") " "
	Gui, %GUI_name%: Font, % "s" settings.general.fSize - 4
	ControlGetPos,,, w,,, ahk_id %hwnd%
	Gui, %GUI_name%: Add, Edit, % "ys x+-1 r1 cBlack HWNDhwnd w"wBox
	vars.hwnd.notepad.name := hwnd
	Gui, %GUI_name%: Add, Button, % "xp yp wp hp Hidden Default gNotepad HWNDhwnd", OK
	vars.hwnd.notepad.add := hwnd
	Gui, %GUI_name%: Font, % "s" settings.general.fSize

	Notepad_Reload(), check := 0, entry_count := 0
	For entry, text in vars.notepad.entries
	{
		If (entry = "notepad_reminder_feature")
			Continue
		entry_count += 1, vars.notepad.selected_entry .= (entry_count = 1 && Blank(vars.notepad.selected_entry)) ? entry : ""
		If (vars.notepad.selected_entry = entry)
			Gui, %GUI_name%: Font, underline
		Gui, %GUI_name%: Add, Text, % "xs w" w . (entry_count = 1 ? " Section" : " y+-1") " BackgroundTrans Border Center HWNDhwnd gNotepad c" vars.notepad.settings[entry].1, % StrReplace(entry, "&", "&&")
		ControlGetPos,,,, h,, ahk_id %hwnd%
		If (vars.notepad.selected_entry = entry)
			Gui, %GUI_name%: Font, norm
		Gui, %GUI_name%: Add, Progress, % "xp yp wp hp Disabled HWNDhwndbar Range0-500 Background" vars.notepad.settings[entry].2 " c" vars.notepad.settings[entry].1, 0
		vars.hwnd.notepad["select_"entry] := hwnd, sum_height += h - 1, vars.hwnd.notepad["delbar_"entry] := vars.hwnd.help_tooltips["notepad_widget"handle] := hwndbar
		Gui, %GUI_name%: Add, Text, % "x+-1 hp Border BackgroundTrans HWNDhwnd0 gNotepad", % "  "
		Gui, %GUI_name%: Add, Progress, % "xp yp wp hp Border Disabled BackgroundBlack HWNDhwnd01 c" vars.notepad.settings[entry].1, 100
		Gui, %GUI_name%: Add, Text, % "x+-1 hp Border BackgroundTrans HWNDhwnd1 gNotepad", % "  "
		Gui, %GUI_name%: Add, Progress, % "xp yp wp hp Border Disabled BackgroundBlack HWNDhwnd11 c" vars.notepad.settings[entry].2, 100
		vars.hwnd.notepad["textcolor_" entry] := hwnd0, vars.hwnd.notepad["textcolor_" entry "_bar"] := vars.hwnd.help_tooltips["notepad_colors" handle] := hwnd01, check += !Blank(text) ? 1 : 0
		vars.hwnd.notepad["backcolor_" entry] := hwnd1, vars.hwnd.notepad["backcolor_" entry "_bar"] := vars.hwnd.help_tooltips["notepad_colors1" handle] := hwnd11, handle1 := handle "|", handle .= "|"
	}
	If (sum_height)
	{
		Gui, %GUI_name%: Add, Text, % "xs Center BackgroundTrans HWNDhwnd0 w" w + 2 * w2 - 2, % Lang_Trans("notepad_howto")
		ControlGetPos,,,, h0,, ahk_id %hwnd0%
		Gui, %GUI_name%: Font, % "s" settings.notepad.fSize
		Gui, %GUI_name%: Add, Edit, % "ys x+-1 cBlack -Wrap Multi Hidden HWNDhwnd"(Blank(vars.notepad.entries[vars.notepad.selected_entry]) ? " w"wBox : ""), % vars.notepad.entries[vars.notepad.selected_entry]
		ControlGetPos,,, w, h,, ahk_id %hwnd%
		w := (w < wBox) ? wBox : (w > max_width) ? max_width : w, sum_height += h0 - 1
		h := (h < hBox) ? hBox : (h > max_height) ? max_height : h
		ControlMove,,,, w,, % "ahk_id "vars.hwnd.notepad.name
		Gui, %GUI_name%: Add, Edit, % "xp yp cBlack -Wrap Multi HWNDhwnd w"w " h"h, % vars.notepad.entries[vars.notepad.selected_entry]
		vars.hwnd.help_tooltips["notepad_widget help"] := hwnd0, vars.hwnd.notepad.note := hwnd, size := settings.general.fWidth/2
		ControlGetPos, x, y, w, h,, ahk_id %hwnd%
		Gui, %GUI_name%: Add, Text, % "x"x + w - 1 " y"y + h - 1 " w"size " h"size " BackgroundWhite HWNDhwnd gNotepad BackgroundTrans", % ""
		vars.hwnd.notepad.drag := hwnd
		Gui, %GUI_name%: Add, Progress, % "x"x + w - 1 " y"y + h - 1 " w"size " h"size " BackgroundWhite", 0
		Gui, %GUI_name%: Margin, 0, 0
	}

	Gui, %GUI_name%: Show, NA x10000 y10000 AutoSize
	ControlFocus,, % "ahk_id "vars.hwnd.notepad.winbar
	WinGetPos, x, y, w, h, ahk_id %notepad%
	vars.notepad.w := w, vars.notepad.h := h
	ControlMove,,,, w - settings.general.fWidth*2 + 1,, % "ahk_id "vars.hwnd.notepad.winbar
	ControlMove,, w - settings.general.fWidth*2,,,, % "ahk_id "vars.hwnd.notepad.winx
	Sleep 50
	xPos := Blank(vars.notepad.x) ? vars.monitor.x + vars.client.xc - w/2 : (vars.notepad.x + w > vars.monitor.x + vars.monitor.w) ? vars.monitor.x + vars.monitor.w - w : vars.notepad.x
	yPos := Blank(vars.notepad.y) ? vars.monitor.y + vars.client.yc - h/2 : (vars.notepad.y + h > vars.monitor.y + vars.monitor.h) ? vars.monitor.y + vars.monitor.h - h : vars.notepad.y
	Gui_CheckBounds(xPos, yPos, w, h)
	Gui, %GUI_name%: Show, % "NA x" xPos " y" yPos
	LLK_Overlay(notepad, "show", 0, GUI_name), LLK_Overlay(hwnd_old, "destroy")
	If refresh_widget
		Notepad_Widget(control)
}

Notepad_Reload()
{
	local
	global vars, settings
	static skip := ["font-color", "font-size", "button-offset", "x-coordinate button", "y-coordinate button", "transparency", "x-coordinate quicknote", "y-coordinate quicknote", "background color"]

	vars.notepad.entries := {"notepad_reminder_feature": vars.notepad.entries.notepad_reminder_feature}, vars.notepad.settings := {}
	ini := IniBatchRead("ini" vars.poe_version "\qol tools.ini", "notepad"), ini1 := IniBatchRead("ini" vars.poe_version "\qol tools.ini", "notepad tab settings")
	For key, val in ini.notepad
	{
		val := StrReplace(val, "(n)", "`n")
		If LLK_HasVal(skip, key)
			Continue
		vars.notepad.entries[key] := val, vars.notepad.settings[key] := StrSplit(!Blank(check := ini1["notepad tab settings"][key]) ? check : settings.notepad.color "|" settings.notepad.color1, "|")
		Loop 2
			If Blank(vars.notepad.settings[key][A_Index])
				vars.notepad.settings[key][A_Index] := settings.notepad["color" (A_Index = 1 ? "" : "1")]
	}
}

Notepad_Widget(tab, mode := 0, color := 0)
{
	local
	global vars, settings
	static toggle := 0, reminder_text

	If (mode = -1)
	{
		If Blank(tab)
			Return
		reminder_text := tab, tab := "notepad_reminder_feature"
		If !IsObject(vars.notepad.entries)
			vars.notepad.entries := {}
		LLK_PanelDimensions([reminder_text], settings.notepad.fSize, width, height)
		vars.notepad.entries[tab] := reminder_text, vars.notepad_widgets[tab] := {"x": Blank(settings.notepad.xQuickNote) ? vars.client.xc - width/2 + 1 : settings.notepad.xQuickNote, "y": Blank(settings.notepad.yQuickNote) ? vars.client.y - vars.monitor.y : settings.notepad.yQuickNote}
	}
	Else
	{
		If Blank(vars.notepad.entries[tab]) && A_Gui
		{
			LLK_ToolTip(Lang_Trans("cheat_entrynotext", 1, [StrReplace(tab, "&", "&&")]), 2,,,, "Red")
			Return
		}
		If (mode = 2) && GetKeyState("LButton", "P") ;prevent widget destruction while dragging
			Return
		start := A_TickCount
		If (mode = 2)
		{
			KeyWait, RButton
			LLK_Overlay(vars.hwnd.notepad_widgets[tab], "destroy"), vars.hwnd.notepad_widgets.Delete(tab)
			Return
		}

		If (mode != 5) ;mode 5 is used to refresh a widget whenever the text in the corresponding tab is changed
		{
			longpress := InStr(A_Gui, "notepad") ? 1 : 0
			While GetKeyState("LButton", "P") && !longpress
				If (A_TickCount >= start + 200)
					longpress := 1
		}

		If InStr(vars.notepad.entries[tab], "`n#`n") && (mode = 4)
			vars.notepad_widgets[tab].page += (vars.notepad_widgets[tab].page != vars.notepad_widgets[tab].text.Count()) ? 1 : 0, mode := 0
		Else If InStr(vars.notepad.entries[tab], "`n#`n") && (mode = 3)
			vars.notepad_widgets[tab].page -= (vars.notepad_widgets[tab].page > 1) ? 1 : 0, mode := 0
		Else If !A_Gui && !longpress && !color
			Return

		If InStr(vars.notepad.entries[tab], "`n#`n") && (InStr(A_Gui, "notepad") || color)
		{
			vars.notepad_widgets[tab] := {"text": [], "page": (vars.notepad_widgets[tab].page ? vars.notepad_widgets[tab].page : "1"), "x": vars.notepad_widgets[tab].x, "y": vars.notepad_widgets[tab].y}
			Loop, Parse, % StrReplace(vars.notepad.entries[tab], "`n#`n", "¢"), % "¢", % "`r`n"
				vars.notepad_widgets[tab].text.Push(A_LoopField)
			vars.notepad_widgets[tab].page := (vars.notepad_widgets[tab].page > vars.notepad_widgets[tab].text.Count()) ? vars.notepad_widgets[tab].text.Count() : vars.notepad_widgets[tab].page
		}
		Else If !InStr(vars.notepad.entries[tab], "`n#`n") && InStr(A_Gui, "notepad")
			vars.notepad_widgets[tab].Delete("text") ;simply delete this key in case a scrollable widget turns into a regular one
	}

	Loop, Parse, tab
		parse_name .= LLK_IsType(A_LoopField, "alnum") ? A_LoopField : "_"
	toggle := !toggle, GUI_name := "widget_" StrReplace(parse_name, " ", "_") . toggle
	Gui, %GUI_name%: New, % "-DPIScale -Caption +LastFound +AlwaysOnTop +ToolWindow +Border +E0x02000000 +E0x00080000 HWNDwidget"(vars.notepad.toggle ? "" : " +E0x20")
	Gui, %GUI_name%: Color, % (tab = "notepad_reminder_feature") ? "White" : vars.notepad.settings[tab].2
	Gui, %GUI_name%: Margin, % settings.notepad.fWidth/2, 0
	Gui, %GUI_name%: Font, % "s" settings.notepad.fSize " c" (tab = "notepad_reminder_feature" ? "Red" : vars.notepad.settings[tab].1), % vars.system.font
	hwnd_old := vars.hwnd.notepad_widgets[tab], vars.hwnd.notepad_widgets[tab] := widget
	If (InStr(A_Gui, "notepad") || mode = 1)
		LLK_Overlay(hwnd_old, "destroy")

	If IsObject(vars.notepad_widgets[tab].text)
	{
		page := vars.notepad_widgets[tab].page, pages := vars.notepad_widgets[tab].text.Count(), multi := 1
		Gui, %GUI_name%: Add, Text, % "Section", % StrReplace(tab, "&", "&&") " (" page "/" pages "):" ;StrReplace(vars.notepad_widgets[tab].text[page], "&", "&&")
	}

	If (tab = "notepad_reminder_feature")
		Gui, %GUI_name%: Add, Text, % "Section cRed", % StrReplace(vars.notepad.entries[tab], "&", "&&")
	Else
	{
		Loop, Parse, % multi ? StrReplace(vars.notepad_widgets[tab].text[page], "&", "&&") : StrReplace(vars.notepad.entries[tab], "&", "&&"), `n
		{
			style := "xs Section y+0", segment := color := colon := rgb := ""
			If InStr(A_LoopField, "§",, 2) && (SubStr(A_LoopField, InStr(A_LoopField, "§") + 7, 2) = ": ")
			{
				Loop, Parse, A_LoopField
				{
					continue := 0
					If (A_LoopField = "§") && Blank(color)
					{
						If !Blank(segment)
						{
							Gui, %GUI_name%: Add, Text, % style, % segment
							style := "ys x+0"
						}
						color := "start", segment := "", continue := rgb := 1
					}
					Else If (A_LoopField = "§")
					{
						Gui, %GUI_name%: Add, Text, % style " c" color, % segment
						style := "ys x+0", color := segment := colon := rgb := "", continue := 1
					}
					Else If (color = "start") || !Blank(color) && (StrLen(color) < 6)
						color := (color = "start") ? A_LoopField : color . A_LoopField, continue := 1
					Else If !colon && rgb && (A_LoopField = ":")
						colon := A_Index
					If continue || colon && LLK_IsBetween(A_Index, colon, colon + 1)
						Continue
					segment .= A_LoopField
				}
			}
			Else segment := A_LoopField
			If !Blank(segment)
				Gui, %GUI_name%: Add, Text, % style, % segment
		}
	}

	Gui, %GUI_name%: Show, NA x10000 y10000
	WinGetPos,,, w, h, ahk_id %widget%
	While longpress && (InStr(A_Gui, "notepad") || mode = 1) && GetKeyState("LButton", "P")
	{
		LLK_Drag(w, h, x, y,, GUI_name, 1)
		Sleep 1
	}
	vars.general.drag := 0
	If longpress && (tab = "notepad_reminder_feature") && !Blank(y)
	{
		settings.notepad.xQuickNote := x, settings.notepad.yQuickNote := y
		IniWrite, % x, % "ini" vars.poe_version "\qol tools.ini", notepad, x-coordinate quicknote
		IniWrite, % y, % "ini" vars.poe_version "\qol tools.ini", notepad, y-coordinate quicknote
	}

	If !vars.notepad.toggle && (tab != "notepad_reminder_feature")
		WinSet, Transparent, % 50 * settings.notepad.trans, % "ahk_id "widget
	If !IsObject(vars.notepad_widgets[tab])
		vars.notepad_widgets[tab] := {}
	If !Blank(y)
		vars.notepad_widgets[tab].x := x, vars.notepad_widgets[tab].y := y

	xPos := Blank(vars.notepad_widgets[tab].x) ? vars.client.xc - w/2 + 1 : vars.notepad_widgets[tab].x, xPos := (xPos >= vars.monitor.w / 2) ? xPos - w + 1 : xPos
	yPos := vars.notepad_widgets[tab].y, yPos := (yPos >= vars.monitor.h / 2) ? yPos - h + 1 : yPos
	Gui, %GUI_name%: Show, % "NA x"vars.monitor.x + xPos " y"vars.monitor.y + yPos
	LLK_Overlay(widget, "show",, GUI_name), LLK_Overlay(hwnd_old, "destroy")
}

QuickPoB(cHWND := "")
{
	local
	global vars, settings

	check := LLK_HasVal(vars.hwnd.quickpob, cHWND,,,, 1), control := LLK_HasVal(vars.hwnd.quickpob[check], cHWND)
	If check
	{
		KeyWait, RButton
		If (vars.system.click = 2)
		{
			For iHBM, HBM in vars.hwnd.quickpob[check].data.HBMs
				DeleteObject(HBM)
			LLK_Overlay(vars.hwnd.quickpob[check].main, "destroy"), vars.hwnd.quickpob.Delete(check)
		}
		Else If (control != "header")
		{
			WinGetPos, xWin, yWin, wWin, hWin, % "ahk_id " Gui_HWND(A_GUI)
			MouseGetPos, xMouse, yMouse
			While GetKeyState("LButton", "P")
			{
				LLK_Drag(wWin, hWin, xPos, yPos, 1, A_Gui,, xMouse - xWin, yMouse - yWin)
				Sleep 15
			}
			vars.general.drag := 0
			WinActivate, % "ahk_id " vars.hwnd.poe_client
		}
		Else QuickPob_Gui("toggle", Gui_HWND(A_Gui))
		Return
	}

	If !IsObject(vars.quickpob)
		vars.quickpob := {}

	hotkey := settings.quickpob.hotkey
	WinGet, pob_windows, List, % "ahk_exe " settings.quickpob.exe.2
	If (pob_windows > 1)
		LLK_ToolTip(Lang_Trans("quickpob_multi"), 2,,,, "Red")
	Else If !pob_windows && (!settings.quickpob.exe.1 || !FileExist(settings.quickpob.exe.1))
		LLK_ToolTip(Lang_Trans("m_qol_quickpob") . Lang_Trans("global_colon") "`n" Lang_Trans("global_setup", 2), 1.5,,,, "Red")
	Else
	{
		Clipboard := ""
		If (trade := Screenchecks_ImageSearch("tradesearch"))
			Click
		Else SendInput, % "^{c}"

		ClipWait, 0.1
		If !Clipboard
		{
			LLK_ToolTip(Lang_Trans("m_qol_quickpob") . Lang_Trans("global_colon") "`n" Lang_Trans("omnikey_copyfail"), 1.5,,,, "FF8000")
			KeyWait, % hotkey
			Return
		}

		KeyWait, % hotkey, T0.2
		If (long_press := ErrorLevel)
		{
			LLK_ToolTip(Lang_Trans("global_ok"),,,,, "Lime")
			KeyWait, % hotkey
		}
		Else If !settings.quickpob.snip_offset
		{
			LLK_ToolTip(Lang_Trans("m_qol_quickpob") . Lang_Trans("global_colon") "`n" Lang_Trans("global_setup", 2), 1.5,,,, "Red")
			KeyWait, % hotkey
			Return
		}
		Else If RegexMatch(Clipboard, "i)" Lang_Trans("items_rarity") ".*" Lang_Trans("items_normal"))
		{
			LLK_ToolTip(LLK_StringCase(Lang_Trans("m_qol_quickpob") . Lang_Trans("global_colon") "`n" Lang_Trans("iteminfo_unsupported") " " Lang_Trans("system_parenthesis") . Lang_Trans("items_normal") . Lang_Trans("system_parenthesis", 2)), 2,,,, "FF8000")
			KeyWait, % hotkey
			Return
		}

		If !WinExist("ahk_exe " settings.quickpob.exe.2)
		{
			Run, % settings.quickpob.exe.1
			WinWait, % "ahk_exe " settings.quickpob.exe.2,, 2
			vars.quickpob.error := ErrorLevel
			WinActivate, % "ahk_id " vars.hwnd.poe_client

			If !vars.quickpob.error
			{
				WinGetTitle, win_title, % "ahk_exe " settings.quickpob.exe.2
				While RegExMatch(win_title, "i)^path.of.building" (vars.poe_version ? ".\(poe2\)" : "") "$")
				{
					If (A_Index = 1)
						LLK_ToolTip(Lang_Trans("quickpob_loading") "`n" Lang_Trans("omnikey_escape"), 0,,, "quickpobwait", "Yellow"), vars.quickpob.pending := 1
					If vars.quickpob.error && !tooltip
						LLK_Overlay(vars.hwnd.tooltip_quickpobwait, "destroy"), tooltip := 1
					If (A_Index = 100)
					{
						vars.quickpob.error := 3
						Break
					}
					Sleep 100
					WinGetTitle, win_title, % "ahk_exe " settings.quickpob.exe.2
				}
				LLK_Overlay(vars.hwnd.tooltip_quickpobwait, "destroy")
			}
		}

		If !vars.quickpob.error && WinExist("ahk_exe " settings.quickpob.exe.2)
		{
			vars.quickpob.hwnd_pob := hwnd_pob := WinExist("ahk_exe " settings.quickpob.exe.2)
			WinGet, style, ExStyle, % "ahk_id " hwnd_pob
			If !long_press
			{
				vars.quickpob.in_progress := vars.quickpob.style := 1
				If !(style & 0x80)
					WinSet, ExStyle, +0x80, % "ahk_id " hwnd_pob
				WinSet, Trans, 1, % "ahk_id " hwnd_pob
			}
			Else
			{
				vars.quickpob.style := 0
				WinSet, ExStyle, -0x80, % "ahk_id " hwnd_pob	;redundant in some cases but also serves as a "ready-check" for instances where PoB is still booting up
			}

			WinActivate, % "ahk_id " hwnd_pob
			WinWaitActive, % "ahk_id " hwnd_pob
			SendEvent, {Control down}
			SendEvent, {Blind}{3}{v}
			SendEvent, {Control up}

			If !long_press
			{
				MouseGetPos, xMouse, yMouse
				MouseMove, % vars.monitor.x + vars.monitor.w, vars.monitor.y + 1.1*vars.system.caption, 0
				SendEvent, {Blind}{PgDn}{PgDn}{PgDn}{PgDn}
				bmp := Gdip_BitmapFromHWND(hwnd_pob, 1)
				MouseMove, xMouse, yMouse, 0
				QuickPoB_Gui(bmp)
				WinActivate, % "ahk_id " vars.hwnd.poe_client
				WinSet, Bottom,, % "ahk_id " hwnd_pob
				WinSet, Trans, Off, % "ahk_id " hwnd_pob
			}
		}
		Else
		{
			If WinExist("ahk_exe " settings.quickpob.exe.2)
				WinClose, % "ahk_exe " settings.quickpob.exe.2
			LLK_ToolTip(Lang_Trans("quickpob_fail", vars.quickpob.error), 2,,,, "Red")
		}
	}
	vars.quickpob.pending := vars.quickpob.error := 0
	KeyWait, % hotkey
	vars.quickpob.in_progress := 0
}

QuickPoB_Gui(mode := "", gui_hwnd := "")
{
	local
	global vars, settings
	static bg_colors := {}, bg_colors2 := {}

	If (mode = "flush")
	{
		bg_colors := {}, bg_colors2 := {}
		Return
	}
	Else If (mode != "toggle")
		bmp := mode

	If !IsObject(vars.hwnd.quickpob)
		vars.hwnd.quickpob := [], vars.hwnd.quickpob.0 := ""

	If (mode != "toggle")
	{
		hwnd_pob := vars.quickpob.hwnd_pob
		If (vars.hwnd.quickpob.Count() = 1)
			compact := (settings.quickpob.mode = "compact")
		Else Loop, % (count := Max(vars.hwnd.quickpob.MaxIndex(), vars.hwnd.quickpob.Count()))
			If IsObject(vars.hwnd.quickpob[count - A_Index].data)
			{
				compact := vars.hwnd.quickpob[count - A_Index].data.compact
				Break
			}
		If RegexMatch(Clipboard, "i)" Lang_Trans("items_class") ".*" Lang_Trans("items_class_rings"))
			compact := 0

		Gdip_GetImageDimensions(bmp, width, height), offset := settings.quickpob.snip_offset
		bmp_crop := Gdip_CloneBitmapArea(bmp, offset - 1, height//20, (width := width - offset + 1), (height := height - height//20),, 1), Gdip_DisposeBitmap(bmp), bmp := bmp_crop
		pEffect := Gdip_CreateEffect(5, 0, 10), Gdip_BitmapApplyEffect(bmp, pEffect), Gdip_DisposeEffect(pEffect)

		If !bg_colors.Count()
			Loop, % height
				color := Gdip_GetPixelColor(bmp, 0, A_Index - 1, 4), bg_colors[color] := 1

		Loop, % height
		{
			row := height - A_Index, color := Gdip_GetPixelColor(bmp, 1, row, 4)
			If bg_colors[color]
				If !target_color
					Continue
				Else
				{
					yMin := row + 1
					Break
				}

			If !target_color
				target_color := color, yMax := row

			If !xMax
				Loop, % width
				{
					prev := color2, color2 := Gdip_GetPixelColor(bmp, A_Index + 1, row, 4)
					If (bottom_edge = "frame") && (color2 != target_color) || (bottom_edge = "cropped") && (color2 != target_color) && (prev = target_color)
						xMax := A_Index - 1
					If xMax
						Break
					Else If !bottom_edge
						bottom_edge := (Gdip_GetPixelColor(bmp, 20, row, 4) = target_color ? "frame" : "cropped")
				}
		}

		width := (xMax ? xMax + 1 : width), height := (yMin && yMax ? yMax - yMin + 1 : height), yCalcs_check := {}
		bmp_crop := Gdip_CloneBitmapArea(bmp, 1, yMin, width, height,, 1), Gdip_DisposeBitmap(bmp), bmp := bmp_crop
		Loop, % height
		{
			outer := A_Index, pixel_check := 0
			If !bg_colors2.Count() && (Gdip_GetPixelColor(bmp, width//2, height - A_Index, 4) != target_color)
			{
				Loop, % width
					bg_colors2[Gdip_GetPixelColor(bmp, A_Index - 1, height - outer, 4)] := 1
				bg_colors2.Delete(target_color)
			}
			If !hHeader && bg_colors2.Count()
			{
				Loop, % width
				{
					If !bg_colors2[(color := Gdip_GetPixelColor(bmp, A_Index - 1, outer - 1, 4))] && (color != target_color)
						Break
					Else pixel_check += 1
				}
				If (pixel_check = width)
					hHeader := outer - 1
			}
			If !yCalcs
				Loop, % width//2
					If yCalcs
						Break
					Else If !bg_colors2[(color := Gdip_GetPixelColor(bmp, A_Index - 1, height - outer, 4))] && InStr(color, SubStr(color, 1, 2),,, 3)
						yCalcs := height - outer + 1
					Else If (color != target_color)
						yCalcs_check[color] := 1
		}
		If (yCalcs_check.Count() = 1)
			yCalcs := 0

		HBMs := []
		If hHeader
		{
			crop := Gdip_CloneBitmapArea(bmp, 0, 0, width, hHeader), HBMs.1 := Gdip_CreateHBITMAPFromBitmap(crop), Gdip_DisposeBitmap(crop)
			crop := Gdip_CloneBitmapArea(bmp, 0, hHeader, width, (yCalcs ? yCalcs : height) - hHeader), HBMs.2 := Gdip_CreateHBITMAPFromBitmap(crop), Gdip_DisposeBitmap(crop)
		}
		Else crop := Gdip_CloneBitmapArea(bmp, 0, 0, width, (yCalcs ? yCalcs : height)), HBMs.1 := Gdip_CreateHBITMAPFromBitmap(crop), Gdip_DisposeBitmap(crop)

		If yCalcs
			crop := Gdip_CloneBitmapArea(bmp, 0, yCalcs, width, height - yCalcs), HBMs.Push(Gdip_CreateHBITMAPFromBitmap(crop)), Gdip_DisposeBitmap(crop)

		Gdip_DisposeBitmap(bmp), gui_name := "QuickPob_" (gui_index := vars.quickpob.max_index := vars.hwnd.quickpob.MaxIndex() + 1) "_0"
	}
	Else gui_index := LLK_HasVal(vars.hwnd.quickpob, gui_hwnd,,,, 1), gui_toggle := vars.hwnd.quickpob[gui_index].data.gui := !vars.hwnd.quickpob[gui_index].data.gui
		, gui_name := "QuickPob_" gui_index "_" gui_toggle, guiPos := LLK_WinGetPos(vars.hwnd.quickpob[gui_index].main)

	Gui, %gui_name%: New, % "-DPIScale +LastFound -Caption +AlwaysOnTop +ToolWindow +E0x02000000 +E0x00080000 HWNDhwnd_quickpob"
	Gui, %gui_name%: Color, Purple
	Gui, %gui_name%: Font, % "s" settings.general.fSize - 2 " cWhite", % vars.system.font
	WinSet, TransColor, Purple
	Gui, %gui_name%: Margin, 0, 0

	If (mode = "toggle")
		hwnd_old := vars.hwnd.quickpob[gui_index].main, vars.hwnd.quickpob[gui_index] := {"main": hwnd_quickpob, "data": vars.hwnd.quickpob[gui_index].data.Clone()}, HBMs := vars.hwnd.quickpob[gui_index].data.HBMs
		, vars.hwnd.quickpob[gui_index].data.compact := !vars.hwnd.quickpob[gui_index].data.compact
	Else vars.hwnd.quickpob[gui_index] := {"main": hwnd_quickpob, "data": {"compact": compact, "gui": 0, "HBMs": HBMs.Clone(), "target_color": target_color}}

	data := vars.hwnd.quickpob[gui_index].data
	For index, hbm in HBMs
	{
		If data.compact && (HBMs.Count() > 2) && (index = 2)
			Continue
		Gui, %gui_name%: Add, Pic, % (index = 1 ? "Section" : "xs") " gQuickPob HWNDhwnd", % "HBitmap:*" hbm
		vars.hwnd.quickpob[gui_index][(index = 1 && HBMs.Count() > 2 ? "header" : "pic" index)] := hwnd
	}

	If data.price || (mode != "toggle") && InStr(Clipboard, "note: ~b/o")
	{
		If !data.price
			data.price := Trim(SubStr(Clipboard, InStr(Clipboard, "note: ~b/o ") + 11), " `r`n")
		Gui, %gui_name%: Add, Text, % "xp y+-1 wp Center BackgroundTrans", % data.price
		Gui, %gui_name%: Add, Progress, % "Disabled xp yp wp hp Background" data.target_color " cBlack", 100
	}
	Gui, %gui_name%: Show, NA x10000 y10000

	WinGetPos, xWin, yWin, wWin, hWin, % "ahk_id " hwnd_quickpob
	If (mode != "toggle")
		xPos := vars.general.xMouse - wWin//2, yPos := vars.general.yMouse - (compact || vars.general.yMouse >= vars.client.y + vars.client.h//2 ? hWin : 0)
	Else xPos := guiPos.x, yPos := guiPos.y
	Gui_CheckBounds(xPos, yPos, wWin, hWin)

	Gui, %gui_name%: Show, % "NA x" xPos " y" yPos
	If (wWin + hWin < 100)
	{
		LLK_ToolTip(Lang_Trans("global_error"),,,,, "Red")
		Gui, %gui_name%: Destroy
		For index, hbm in vars.hwnd.quickpob[gui_index].data.HBMs
			DeleteObject(hbm)
		vars.hwnd.quickpob.Delete(gui_index)
	}
	Else LLK_Overlay(hwnd_quickpob, "show",, gui_name)
	LLK_Overlay(hwnd_old, "destroy")
}
