﻿param(
    [Parameter(Mandatory)][ValidateSet('Export','Import')][string]$Mode,
    [Parameter(Mandatory)][string]$File,
    [string]$ErrorFile
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$format = 'RIFT-CFG/1'
$allowed = '^(?:ini/[\w ().-]+\.ini|ini/rift/(?:my-notes\.txt|notes/[1-9]\d*\.(?:txt|title))|img/GUI/skill-tree[2-9]?/\[(?:lab)?\d+\]\.(?:png|bmp|jpe?g)|img/Recognition \(\d+p\)/(?:[\w ()-]+/)*[\w ().-]+\.bmp)$'
$localKeys = @{'ini/config.ini' = @('settings','PoE config-file'); 'ini/rift.ini' = @('client','log path')}
$utf8 = New-Object Text.UTF8Encoding($false)

function Test-Managed($name) {
    $name -match $allowed -and $name -notmatch '(?:^|/)(?:\.{1,2}(?:/|$)|(?:con|prn|aux|nul|com\d|lpt\d)(?:\.|/|$))'
}

function Get-Files($dir) {
    foreach ($item in [IO.DirectoryInfo]::new($dir).EnumerateFileSystemInfos()) {
        if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
        if ($item -is [IO.DirectoryInfo]) { Get-Files $item.FullName; continue }
        $name = $item.FullName.Substring($root.Length + 1).Replace('\','/')
        if (Test-Managed $name) { $name }
    }
}

function Get-Managed {
    foreach ($dir in @(Get-Item -LiteralPath (Join-Path $root 'ini')) + @(Get-ChildItem -LiteralPath (Join-Path $root 'img') -Directory -Filter 'Recognition (*)') + @(Get-ChildItem -LiteralPath (Join-Path $root 'img/GUI') -Directory -Filter 'skill-tree*')) {
        if (!($dir.Attributes -band [IO.FileAttributes]::ReparsePoint)) { Get-Files $dir.FullName }
    }
}

# Keep the receiving PC's game/log paths and preserve every other INI section.
function Set-LocalKey($name, $path, $localPath) {
    $section,$key = $localKeys[$name]
    $sectionPattern = '(?im)^\[' + [regex]::Escape($section) + '\][^\r\n]*(?:\r?\n|$)(?:[^\[\r\n][^\r\n]*(?:\r?\n|$)|\r?\n)*'
    $keyPattern = '(?im)^\s*' + [regex]::Escape($key) + '[ \t]*=[^\r\n]*(?:\r?\n|$)'
    $text = [IO.File]::ReadAllText($path)
    $line = ''
    if ($localPath -and [IO.File]::Exists($localPath)) {
        $localSection = [regex]::Match([IO.File]::ReadAllText($localPath), $sectionPattern).Value
        $line = [regex]::Match($localSection,$keyPattern).Value.Trim()
    }
    $block = [regex]::Match($text,$sectionPattern)
    if ($block.Success) {
        $replacement = [regex]::Replace($block.Value,$keyPattern,'')
        if ($line) { $replacement = $replacement.TrimEnd() + "`r`n$line`r`n" }
        $text = $text.Remove($block.Index,$block.Length).Insert($block.Index,$replacement)
    } elseif ($line) { $text += "`r`n[$section]`r`n$line`r`n" }
    [IO.File]::WriteAllText($path,$text,[Text.Encoding]::Unicode)
}

try {
    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $stage = Join-Path $root ('.cfg-' + [guid]::NewGuid().ToString('N'))
    [void][IO.Directory]::CreateDirectory($stage)
    $existing = @(Get-Managed)
    if ($Mode -eq 'Export') {
        $temp = Join-Path $stage 'export.zip'
        $zip = [IO.Compression.ZipFile]::Open($temp,'Create')
        try {
            $marker = $zip.CreateEntry($format.Replace('/','-'))
            foreach ($name in $existing) {
                $src = Join-Path $root $name
                if ($localKeys.ContainsKey($name)) {
                    $copy = Join-Path $stage ([IO.Path]::GetFileName($src))
                    [IO.File]::Copy($src,$copy)
                    Set-LocalKey $name $copy $null
                    $src = $copy
                }
                [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$src,$name)
            }
        } finally { $zip.Dispose() }
        if ([IO.File]::Exists($File)) { [IO.File]::Replace($temp,$File,(Join-Path $stage 'previous.cfg')) }
        else { [IO.File]::Move($temp,$File) }
    } else {
        $incoming = @{}
        $zip = [IO.Compression.ZipFile]::OpenRead($File)
        try {
            if (!$zip.GetEntry('RIFT-CFG-1')) { throw 'Invalid RIFT CFG format.' }
            $total = 0L
            foreach ($entry in $zip.Entries) {
                $name = $entry.FullName
                if ($name -ceq 'RIFT-CFG-1') { continue }
                $total += $entry.Length
                if (!(Test-Managed $name) -or $incoming.ContainsKey($name) -or $total -gt 1GB -or $incoming.Count -ge 20000) { throw 'Invalid CFG entry.' }
                $target = Join-Path $root $name
                for ($part = $target; $part -ne $root; $part = Split-Path -Parent $part) {
                    if ((Test-Path -LiteralPath $part) -and ((Get-Item -Force -LiteralPath $part).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Linked destination.' }
                }
                $copy = Join-Path $stage ('new-' + $incoming.Count)
                [IO.Compression.ZipFileExtensions]::ExtractToFile($entry,$copy)
                if ($localKeys.ContainsKey($name)) { Set-LocalKey $name $copy $target }
                $incoming[$name] = $copy
            }
            foreach ($required in @('ini/config.ini','ini/rift.ini')) {
                if (!$incoming.ContainsKey($required)) { throw "Missing $required" }
            }
        } finally { $zip.Dispose() }
        $undo = [Collections.Stack]::new()
        try {
            foreach ($name in @(@($incoming.Keys) + $existing | Sort-Object -Unique)) {
                $target = Join-Path $root $name
                $backup = Join-Path $stage ('old-' + $undo.Count)
                if ($incoming.ContainsKey($name)) {
                    [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))
                    if ([IO.File]::Exists($target)) { [IO.File]::Replace($incoming[$name],$target,$backup) }
                    else { [IO.File]::Move($incoming[$name],$target) }
                } else { [IO.File]::Move($target,$backup) }
                $undo.Push(@($target,$backup))
            }
        } catch {
            $keepStage = $true
            while ($undo.Count) {
                $target,$backup = $undo.Pop()
                if ([IO.File]::Exists($target)) { [IO.File]::Delete($target) }
                if ([IO.File]::Exists($backup)) { [IO.File]::Move($backup,$target) }
            }
            $keepStage = $false
            throw
        }
    }
} catch {
    if ($ErrorFile) { [IO.File]::WriteAllText($ErrorFile,$_.Exception.Message,$utf8) }
    else { [Console]::Error.WriteLine($_.Exception.Message) }
    exit 1
} finally {
    if ($stage -and !$keepStage -and [IO.Directory]::Exists($stage) -and [IO.Path]::GetDirectoryName([IO.Path]::GetFullPath($stage)) -eq $root -and [IO.Path]::GetFileName($stage) -match '^\.cfg-[a-f0-9]{32}$') {
        Remove-Item -LiteralPath $stage -Force -Recurse
    }
}
