﻿Init_log(mode := "")
{
	local
	global vars, settings

	If mode
	{
		vars.log.level := 0, vars.log.character_last := !settings.general.character ? "" : vars.log.character_last
		If !settings.general.character
			Return
	}
	Else start := A_TickCount

	FileGetSize, filesize, % vars.log.file_location, M

	If !mode
		settings.general.character := LLK_IniRead("ini" vars.poe_version "\config.ini", "settings", "active character")
		, log_file := vars.log.file := FileOpen(vars.log.file_location, "a", "UTF-8"), vars.log.file_size := filesize
	Else log_file := FileOpen(vars.log.file_location, "a", "UTF-8")

	max_pointer := log_file.Tell()
	Loop
	{
		move := Min(max_pointer, 3 * A_Index * 1024000), log_file.Seek(-move, 2), log_read := log_file.Read(3*1024000)
		If !mode && !IsObject(log_content) && (check := InStr(log_read, " Generating level ", 1, 0, 3))
			log_content := StrSplit(SubStr(log_read, check), "`n", "`r" vars.lang.system_fullstop.1)

		If settings.general.character && Blank(log_character.1) && InStr(log_read, settings.general.character)
		{
			log_array := StrSplit(log_read, "`n", "`r" vars.lang.system_fullstop.1)
			Loop, % log_array.Count()
			{
				line := log_array[log_array.Count() - (A_Index - 1)]
				If InStr(line, settings.general.character) && IsObject(Log_CharacterInfo(line))
				{
					log_character := [line]
					Break
				}
			}
		}

		If (max_pointer = move) || (IsObject(log_content) || mode) && (!settings.general.character || !Blank(log_character.1))
			Break
	}
	log_file.Seek(0, 2)

	If !mode
	{
		vars.log.parsing := "areaID, areaname, areaseed, arealevel, areatier, act, level, date_time, character_class"
		Loop, Parse, % vars.log.parsing, `,, %A_Space%
			vars.log[A_LoopField] := ""
	}
	If settings.general.character && !Blank(log_character.1)
		Log_Parse(log_character, bla, bla, bla, bla, bla, bla, level, bla, character_class, bla)

	If mode
	{
		vars.log.level := level ? level : 0, vars.log.character_class := character_class, log_file.Close()
		Return
	}

	Log_Parse(log_content, areaID, areaname, areaseed, arealevel, areatier, act, bla, date_time, bla, bla)

	Loop, Parse, % vars.log.parsing, `,, %A_Space%
		If Blank(vars.log[A_LoopField]) && !Blank(%A_LoopField%)
			vars.log[A_LoopField] := %A_LoopField%

	If vars.general.MultiThreading
		StringSend("areaID=" vars.log.areaID)

	vars.log.level := !vars.log.level ? 0 : vars.log.level
	If !mode
	{
		vars.log.access_time := A_TickCount - start
		If vars.log.latest_location
			vars.log.file.Close(), vars.log.file := FileOpen(vars.log.latest_location, "a", "UTF-8")
	}
}

Log_Backup()
{
	local
	global vars, settings

	WinClose, % "ahk_id " vars.hwnd.poe_client
	WinWaitClose, % "ahk_id " vars.hwnd.poe_client,, 3
	If WinExist("ahk_id " vars.hwnd.poe_client)
	{
		MsgBox,, RIFT, % "Backup failed:`nCannot close the game-client."
		Return
	}
	file := StrReplace(vars.log.file_location, "client.txt", "Client (old).txt")
	For index, loop in ["Loop", "Log_Loop", "Loop_main"]
		SetTimer, % loop, Delete
	LLK_Overlay(vars.hwnd.help_tooltips.main, "destroy"), LLK_Overlay(vars.hwnd.ClientFiller, "destroy")
	Sleep 1000
	LLK_Overlay("hide"), vars.log.file.Close()
	LLK_ToolTip("copying...", 0, vars.monitor.x + vars.client.xc, vars.monitor.y + vars.client.yc,, "Yellow",,,, 1)

	If !FileExist(file)
	{
		FileMove, % vars.log.file_location, % file, 1
		If ErrorLevel
		{
			LLK_Overlay(vars.hwnd.tooltip1, "destroy")
			MsgBox,, RIFT, % "Backup failed:`nCannot move the old file.`nThe tool will restart."
			LLK_Restart()
			Return
		}
		source_file := FileOpen(file, "r", "UTF-8"), source_file.Seek(-Min(512000, source_file.Length), 2), dest_file := FileOpen(vars.log.file_location, "w", "UTF-8")
		If !IsObject(dest_file)
		{
			LLK_Overlay(vars.hwnd.tooltip1, "destroy")
			MsgBox,, RIFT, % "Backup failed:`nCannot create the new file.`n`nRestart the game to let it create the new file.`nYou'll have to waypoint-travel around a few times before relaunching the tool."
			ExitApp
		}
		append := source_file.Read(), append := SubStr(append, InStr(append, "`n") + 1) . (vars.log.character_last ? vars.log.character_last "`r`n" : "")
		dest_file.Write(append), source_file.Close(), dest_file.Close()

		If !FileExist(vars.log.file_location) || !FileExist(file)
		{
			LLK_Overlay(vars.hwnd.tooltip1, "destroy")
			MsgBox,, RIFT, % "Backup failed:`nSomething went wrong while copying the file. The game's log folder will open after closing this message."
			Run, % "explore " SubStr(vars.log.file_location, 1, InStr(vars.log.file_location, "\",, 0) - 1)
			MsgBox,, RIFT, % "Trouble-shooting steps:`n- If ""Client (old).txt"" doesn't exist, nothing happened and the original log-file wasn't changed.`n`n- If only ""Client (old).txt"" exists, the old file was moved but a new one wasn't created. Launching the game will create a new one, but you have to waypoint-travel around a bit before relaunching the tool."
			ExitApp
		}
	}
	Else
	{
		source_file := FileOpen(vars.log.file_location, "r", "UTF-8"), dest_file := FileOpen(file, "r", "UTF-8"), dest_file.Seek(-1 * Min(512000, dest_file.Length), 2)
		dest_overlap := dest_file.Read(), dest_overlap := SubStr(dest_overlap, InStr(dest_overlap, "`n") + 1), dest_file.Seek(0, 2)
		If !IsObject(source_file) || !IsObject(dest_file)
		{
			LLK_Overlay(vars.hwnd.tooltip1, "destroy")
			MsgBox,, RIFT, % "Backup failed:`nCannot access the current or backup file.`nThe tool will restart."
			LLK_Restart()
		}
		Loop
		{
			log_read := source_file.Read(10 * 1024000)
			Loop, Parse, log_read, `n, `r
			{
				If (A_Index = 1)
					log_read := ""
				date := SubStr(A_LoopField, 1, InStr(A_LoopField, " ",,, 2) - 1), date := StrReplace(StrReplace(StrReplace(date, " "), "/"), ":")
				If (date < prev_date)
					Continue
				prev_date := date
				If !InStr(dest_overlap, A_LoopField)
					log_read .= A_LoopField "`r`n"
			}
			dest_file.Write(log_read)
			If source_file.AtEOF
				Break
		}

		source_file.Close()
		FileDelete, % vars.log.file_location
		If FileExist(vars.log.file_location)
		{
			LLK_Overlay(vars.hwnd.tooltip1, "destroy")
			MsgBox,, RIFT, % "Backup failed:`nCannot delete the ""Client.txt"" log-file.`n. You'll have to delete it manually (the folder will open once you close this message).`n`nAfter deleting, restart the game, waypoint-travel around a few times, then restart the tool."
			Run, % "explore " SubStr(vars.log.file_location, 1, InStr(vars.log.file_location, "\",, 0) - 1)
			ExitApp
		}
		source_file := "", source_file := FileOpen(vars.log.file_location, "w", "UTF-8")
		If !IsObject(source_file)
		{
			LLK_Overlay(vars.hwnd.tooltip1, "destroy")
			MsgBox,, RIFT, % "Backup failed:`nCannot create the new file.`n`nRestart the game to let it create the new file.`nYou'll have to waypoint-travel around a few times before relaunching the tool."
			ExitApp
		}

		dest_file.Seek(-512000, 2), append := dest_file.Read(), append := SubStr(append, InStr(append, "`n") + 1) . (vars.log.character_last ? vars.log.character_last "`r`n" : ""), source_file.Write(append)
		source_file.Close(), dest_file.Close()
	}

	If FileExist(vars.log.file_location) && FileExist(file)
	{
		LLK_ToolTip("backup successful:`nyou can launch the game again,`nthe tool will restart automatically.", 0, vars.monitor.x + vars.client.xc, vars.monitor.y + vars.client.yc,, "Lime",,,, 1)
		WinWait, ahk_group poe_window,, 60
		LLK_Overlay(vars.hwnd.tooltip1, "destroy")
		Sleep 4000
		LLK_Restart()
	}
}

Log_CharacterInfo(line, any_character := 0)
{
	local
	global vars, settings

	If Lang_Match(line, vars.lang.log_level)
	{
		parse := SubStr(line, InStr(line, ":",, 0) + 1)
		Loop, Parse, parse
			level .= (IsNumber(A_LoopField) ? A_LoopField : "")
		If any_character || InStr(line, settings.general.character " " Lang_Trans("system_parenthesis")) || InStr(line, settings.general.character . Lang_Trans("system_parenthesis"))
			class := SubStr(line, InStr(line, Lang_Trans("system_parenthesis")) + 1), class := LLK_StringCase(SubStr(class, 1, InStr(class, Lang_Trans("system_parenthesis", 2)) - 1))
			, character := SubStr(parse, 1, InStr(parse, Lang_Trans("system_parenthesis")) - 1), character := Trim(character, " ")
	}
	Else If Lang_Match(line, vars.lang.log_whois)
	{
		parse := SubStr(line, InStr(line, ":",, 0) + 1)
		Loop, Parse, parse
			If IsNumber(A_LoopField)
				level .= A_LoopField
			Else If level
				Break
		If (check := InStr(parse, vars.lang.log_whois_class.1))
		{
			class0 := SubStr(parse, check), class0 := SubStr(class0, 1, InStr(class0, vars.lang.log_whois_class.2) - 1)
			class0 := StrReplace(class0, vars.lang.log_whois_class.1)
			Loop, Parse, class0
				class .= (A_LoopField = " " || !IsNumber(A_LoopField) ? A_LoopField : "")
			While InStr(class, "  ")
				class := StrReplace(class, "  ", " ")
			class := LLK_StringCase(Trim(class, " "))
		}
	}
	If level && class
		Return [level, class, character]
}

Log_Get(log_text, data)
{
	local
	global vars, settings, db
	static unique_maps := {"merchant": "seer", "vault": "vaults"}

	If (data = "areaname")
		If !LLK_StringCompare(log_text, ["map", "breach", "ritual", "expedition"])
			%data% := log_text
		Else
		{
			If InStr(log_text, "expedition")
			{
				If !IsObject(db.maps)
					DB_Load("maps")
				If (map_name := db.maps.maps[log_text].name)
					%data% := map_name, boss := db.maps.maps[log_text].boss
				Else %data% := SubStr(log_text, InStr(log_text, "_") + 1)

				If boss && settings.maptracker.rename
					Return Lang_Trans("maps_boss") . Lang_Trans("global_colon") " " Lang_Trans("maps_" boss)
				Else If boss
					Return LLK_StringCase(%data%) " (" Lang_Trans("maps_boss") ")"
				Else Return LLK_StringCase(%data%)
			}
			Else If RegExMatch(log_text, "Hideout.*_Claimable")
			{
				hideout := LLK_StringCase(StrReplace(StrReplace(log_text, "_claimable"), "maphideout"))
				Return LLK_StringCase(Lang_Trans("maps_" hideout "_hideout") ? Lang_Trans("maps_" hideout "_hideout") : hideout " " Lang_Trans("maps_hideout"))
			}

			If !IsObject(db.maps)
				DB_Load("maps")

			%data% := (RegexMatch(log_text, "i)^map") ? StrReplace(SubStr(log_text, 4), "_noboss") : log_text), map_name := db.maps.maps[%data%].name, boss := db.maps.maps[%data%].boss, boss := Lang_Trans("maps_" boss)
			rename := settings.maptracker.rename
			If InStr(%data%, "uberboss_") || RegexMatch(%data%, "i)ritualleagueboss|breachdomain")
				%data% := (rename ? Lang_Trans("maps_boss") . Lang_Trans("global_colon") " " : "") . (boss && rename ? boss : (map_name ? map_name : StrReplace(%data%, "uberboss_"))) . (settings.maptracker.rename ? "" : " (" Lang_Trans("maps_boss") ")")
			Else If LLK_StringCompare(%data%, ["unique"])
			{
				For key, val in unique_maps
					If !override && InStr(%data%, key)
						%data% := Lang_Trans("items_unique") . Lang_Trans("global_colon") " " Lang_Trans("maps_" (val ? val : key)), override := 1
				If !override
					%data% := Lang_Trans("items_unique") . Lang_Trans("global_colon") " " (map_name ? map_name : SubStr(%data%, 7))
			}
			Else If LLK_PatternMatch(log_text, "", ["losttowers", "swamptower", "mesa", "bluff", "alpineridge"],,, 0)
			{
				%data% := (map_name ? map_name : %data%)
				%data% .= !InStr(log_text, "losttowers") ? " (" Lang_Trans("maps_tower") ")" : ""
			}
			Else If (%data% = "voidreliquary")
				%data% := Lang_Trans("maps_" %data%)
			Else If map_name
				%data% := map_name
			Else Loop, Parse, % %data%
				%data% := (A_Index = 1) ? "" : %data%, %data% .= (A_Index != 1 && (SubStr(%data%, 0) != " ") && RegExMatch(A_LoopField, "[A-Z]") ? " " : "") . A_LoopField
		}
	Return LLK_StringCase(%data%)
}

Log_Loop(mode := 0)
{
	local
	global vars, settings, db
	static news_check

	Critical
	If settings.qol.alarm && !vars.alarm.drag
	{
		For timestamp, timer in vars.alarm.timers
		{
			If IsNumber(StrReplace(timestamp, "|")) && (timestamp <= A_Now)
				expired := "expired"
			If vars.alarm.single_use[timestamp].pause
				vars.alarm.single_use[timestamp].offset += 1
		}
		If (expired || vars.alarm.toggle) && !WinExist("ahk_id " vars.hwnd.alarm.alarm_set.main)
			Alarm("", "", vars.alarm.toggle ? "" : expired)
		Else If !(expired || vars.alarm.toggle) && (WinExist("ahk_id " vars.hwnd.alarm.alarm_set.main) || WinExist("ahk_id " vars.hwnd.alarm.main))
			LLK_Overlay(vars.hwnd.alarm.main, "destroy")
	}

	If !vars.log.file_wait && vars.log.file_location ;for the unlikely event where the user manually deletes the client.txt while the tool is still running
		If IsObject(vars.log.file) && !FileExist(vars.log.file_location)
			vars.log.file.Close(), vars.log.file := ""
		Else If !IsObject(vars.log.file) && FileExist(vars.log.file_location)
			vars.log.file := FileOpen(vars.log.file_location, "a", "UTF-8")

	guide := vars.leveltracker.guide ;short-cut variable
	If !vars.news.wait && (!news_check || (A_TickCount >= news_check + 1800000))
	{
		news_check := A_TickCount
		SetTimer, News, -100
	}

	If vars.log.file_wait || !WinActive("ahk_group poe_ahk_window") || !vars.log.file_location || !WinExist("ahk_group poe_window") || !FileExist(vars.log.file_location)
	{
		If WinExist("ahk_id " vars.hwnd.maptracker.main)
			LLK_Overlay(vars.hwnd.maptracker.main, "destroy")
		Return
	}

	If vars.lootfilter.update_pending.1 && (A_TickCount >= vars.lootfilter.update_pending.2 + 5000)
		vars.lootfilter.update_pending := "", LLK_ToolTip(Lang_Trans("global_fail"),,,,, "Red")

	If (vars.lootfilter.update_applied || vars.lootfilter.modifications_pending.Count() > 1) && WinExist("ahk_id " vars.hwnd.lootfilter.main)
	{
		tick := SubStr(Floor(A_TickCount/1000), 0)
		GuiControl, % "+c" (Mod(tick, 2) ? settings.lootfilter.color_accent : "White"), % vars.hwnd.lootfilter.filter_apply
		GuiControl, % "+c" (Mod(tick, 2) ? "White" : settings.lootfilter.color_accent) " +BackgroundFF8000", % vars.hwnd.lootfilter.filter_apply_bar
	}

	If vars.lootfilter.tester_applied && WinExist("ahk_id " vars.hwnd.settings.main)
	{
		tick := SubStr(Floor(A_TickCount/1000), 0)
		GuiControl, % "+c" (Mod(tick, 2) ? "Red" : "White"), % vars.hwnd.settings.tester_restore
		GuiControl, % "movedraw", % vars.hwnd.settings.tester_restore
	}

	If IsObject(vars.maptracker)
		vars.maptracker.hideout := Maptracker_Towncheck() ? 1 : 0 ;flag to determine if the player is using a portal to re-enter the map (as opposed to re-entering from side-content)

	log_content := vars.log.file.Read(), level0 := vars.log.level, log_content := StrSplit(log_content, "`n", "`r" vars.lang.system_fullstop.1)

	If log_content.Count()
	{
		auto_track := "a"
		Log_Parse(log_content, areaID, areaname, areaseed, arealevel, areatier, act, level, date_time, character_class, auto_track)
		Loop, Parse, % vars.log.parsing, `,, %A_Space%
		{
			If Blank(%A_LoopField%)
				Continue
			Else If (A_LoopField = "areaID") && vars.general.MultiThreading
				StringSend("areaID=" %A_LoopField%)
			vars.log[A_LoopField] := %A_LoopField%
			If (A_LoopField = "areaID")
				If !vars.poe_version
					vars.log.areaname := "" ;make it blank because there sometimes is a desync between it and areaID, i.e. they are parsed in two separate loop-ticks
				Else vars.log.areaname := Log_Get(areaID, "areaname")
		}
		If (auto_track = 1)
			level0 := 0

		If settings.features.lootfilter && settings.lootfilter.notify && (settings.lootfilter.ingame_filter = "filterspoon.filter") && settings.lootfilter.last_sync
		&& (LLK_TimeElapsed(settings.lootfilter.last_sync,, 0) >= settings.lootfilter.notify * 60) && RegExMatch(areaID, "i)^hideout")
		{
			If !vars.lootfilter.last_notification
			{
				vars.lootfilter.last_notification := A_TickCount
				game_ini := IniBatchRead(vars.system.config_folder "\" (vars.poe_version ? "poe2_" : "") "production_Config.ini",, "blank")
				If (game_ini.ui.item_filter != "filterspoon.filter")
				{
					settings.lootfilter.ingame_filter := game_ini.ui.item_filter
					Return
				}
			}
			MapEvent("lootfilter")
		}

		If (settings.features.leveltracker * settings.leveltracker.geartracker) && IsNumber(level) && (level0 != level)
			Geartracker_GUI(WinExist("ahk_id " vars.hwnd.geartracker.main) ? "" : "refresh")

		; RIFT v13.7: avoid rebuilding the four Act-Tracker windows for every
		; repeated Client.txt event when the character is still in the same zone.
		; Manual page changes and settings updates call Leveltracker_Progress()
		; separately and remain unaffected.
		If settings.features.leveltracker && (WinExist("ahk_id " vars.hwnd.leveltracker.main) && (IsNumber(level) && (level0 != level) || !Blank(areaID) && areaID != vars.leveltracker.guide.target_area)
		|| LLK_Overlay(vars.hwnd.leveltracker.main, "check") && (RegexMatch(areaID, "i)^hideout") || db.leveltracker.areaIDs[areaID] && areaID != vars.leveltracker.guide.target_area)
		&& !RegexMatch(vars.log.areaID, "i)labyrinth_|g3_10$|sanctum_") && !LLK_HasVal(vars.leveltracker.guide.group1, Lang_Trans("ms_leveling tracker"), 1))
		{
			signature := areaID "|" vars.log.level "|" vars.log.act
			if (signature != vars.leveltracker.last_log_redraw)
			{
				vars.leveltracker.last_log_redraw := signature
				Leveltracker_Progress()
			}
		}

		If !Blank(areaID) && settings.features.leveltracker && WinActive("ahk_id " vars.hwnd.poe_client) && RegExMatch(areaID, "i)labyrinth_|sanctum_|g3_10$") && WinExist("ahk_id " vars.hwnd.leveltracker.main)
			Leveltracker_Toggle("hide")

		If settings.features.actdecoder && vars.actdecoder.layouts_lock && !Blank(areaID) && (areaID != vars.actdecoder.current_zone)
			Actdecoder_ZoneLayouts(2)

		If !vars.poe_version && settings.qol.alarm && (areaID = "1_1_1") && IsNumber(StrReplace((check := LLK_HasVal(vars.alarm.timers, "oni", 1)), "|")) ;for oni-goroshi farming: re-entering Twilight Strand resets timer to 0:00
			vars.alarm.timers.Delete(check), vars.alarm.timers[A_Now "|"] := "oni"

		If settings.qol.lab && InStr(areaID, "labyrinth_airlock") ;entering Aspirants' Plaza: reset previous lab-progress (if there is any)
			Lab("init")
		Else If settings.qol.lab && areaname && (InStr(vars.log.areaID, "labyrinth_") && !LLK_PatternMatch(vars.log.areaID, "", ["Airlock", "_trials_"]) || InStr(areaID, "labyrinth_") && !LLK_PatternMatch(areaID, "", ["Airlock", "_trials_"])) ;entering a new room
		{
			For index, room in vars.lab.rooms ;go through previously-entered rooms to check if player is backtracking or not
				If (room.name = areaname && room.seed = vars.log.areaseed)
				{
					check := index
					Break
				}
			If check
				Lab("backtrack", check)
			Else If !Blank(LLK_HasVal(vars.lab.exits.names, areaname)) ;check which adjacent room has been entered
				For index, room in vars.lab.exits.names
					If (room = areaname) && Blank(vars.lab.rooms[vars.lab.exits.numbers[index]].seed)
					{
						Lab("progress", vars.lab.exits.numbers[index])
						Break
					}
		}

		If (auto_track = 2)
		{
			timer := vars.leveltracker.timer
			If IsNumber(timer.current_split) && (timer.current_split != timer.current_split0)
				IniWrite, % (timer.current_split0 := timer.current_split), % "ini" vars.poe_version "\leveling tracker.ini", % "current run" settings.leveltracker.profile, time
			vars.leveltracker.timer.pause := -1

			If vars.leveltracker.skilltree_schematics.GUI
				Leveltracker_PobSkilltree("close")
			Init_log("refresh"), Init_leveltracker(), Leveltracker_Load()
			If LLK_Overlay(vars.hwnd.leveltracker.main, "check") && vars.leveltracker.guide.import.Count()
				Leveltracker_Progress(1)
			Else Leveltracker_Toggle("destroy"), vars.hwnd.leveltracker.main := ""
		}
		If IsNumber(auto_track)
			LLK_ToolTip(Lang_Trans("lvltracker_autotrack") "`n" LLK_StringCase(settings.general.character) " (" vars.log.level ")", 3, vars.monitor.x + vars.monitor.w/2, vars.monitor.y,, "Lime", settings.general.fSize * 2,, 150, 1,, 1)
		If (character_class || IsNumber(auto_track)) && WinExist("ahk_id " vars.hwnd.settings.main) && RegExMatch(vars.settings.active, "i)general|leveling.tracker")
			Settings_menu(vars.settings.active,, 0)
	}

	If mode
		Return

	If settings.qol.lab && InStr(vars.log.areaID, "labyrinth_") && !InStr(vars.log.areaID, "Airlock") && vars.log.areaseed && vars.lab.rooms.Count() && !vars.lab.rooms[vars.lab.room.1].seed
		vars.lab.rooms[vars.lab.room.1].seed := vars.log.areaseed, vars.lab.room.3 := vars.log.areaseed

	If settings.features.leveltracker && (A_TickCount >= vars.leveltracker.last_manual + 2000) && vars.hwnd.leveltracker.main && (vars.log.areaID = vars.leveltracker.guide.target_area) && !vars.leveltracker.fast ;advance the guide when entering target-location
		vars.leveltracker.guide.target_area := "", Leveltracker("+")

	If !vars.poe_version && settings.features.mapinfo && vars.mapinfo.expedition_areas && vars.log.areaname && !Blank(LLK_HasVal(vars.mapinfo.expedition_areas, vars.log.areaname)) && !vars.mapinfo.active_map.expedition_filter
	{
		Loop, % vars.mapinfo.categories.Count()
		{
			parse := InStr(vars.mapinfo.categories[A_Index], "(") ? SubStr(vars.mapinfo.categories[A_Index], 1, InStr(vars.mapinfo.categories[A_Index], "(") - 2) : vars.mapinfo.categories[A_Index]
			If !Blank(LLK_HasVal(vars.mapinfo.expedition_areas, parse)) && (parse != vars.log.areaname)
				vars.mapinfo.categories[A_Index] := ""
		}
		vars.mapinfo.active_map.name := Lang_Trans("maps_logbook") ": " vars.log.areaname, vars.mapinfo.active_map.expedition_filter := 1
	}

	Maptracker_Timer()
	Leveltracker_Timer()
}

Log_Parse(content, ByRef areaID, ByRef areaname, ByRef areaseed, ByRef arealevel, ByRef areatier, ByRef act, ByRef level, ByRef date_time, ByRef character_class, ByRef auto_track)
{
	local
	global vars, settings, db

	For index, loopfield in content
	{
		If Blank(loopfield)
			Continue
		If InStr(loopfield, "Generating level ", 1)
		{
			parse := SubStr(loopfield, InStr(loopfield, "area """) + 6), areaID := SubStr(parse, 1, InStr(parse, """") -1) ;store PoE-internal location name in var
			areaseed := SubStr(loopfield, InStr(loopfield, "with seed ") + 10), areaname := ""
			If (areaID = "c_g2_9_2_" || areaID = "c_g3_16_") ;bugged PoE2 areaIDs
				areaID := SubStr(areaID, 1, -1)
			date_time := SubStr(loopfield, 1, InStr(loopfield, " ",,, 2) - 1)
			act := LLK_HasVal(db.leveltracker.areas, areaID,,,, 1)
			If vars.poe_version && !act && IsNumber(SubStr(areaID, 2, 1))
				act := SubStr(areaID, 2, 1)
			arealevel := parse := SubStr(loopfield, InStr(loopfield, "level ") + 6, InStr(loopfield, " area """) - InStr(loopfield, "level ") - 6)
			If !vars.poe_version && (parse - 67 > 0)
				areatier := (parse - 67 < 10 ? "0" : "") parse - 67
			Else If vars.poe_version && (parse - 64 > 0)
				areatier := (parse - 64 < 10 ? "0" : "") parse - 64
			Else areatier := arealevel
		}
		Else If InStr(loopfield, " connected to ") && InStr(loopfield, ".login.") || InStr(loopfield, "*****")
			areaID := "login"

		/* this log-msg was removed at some point from PoE2 but is still present in PoE1
		Else If InStr(loopfield, "current input mode = ")
		{
			timestamp := SubStr(loopfield, 1, InStr(loopfield, " ",,, 2) - 1)
			Loop, Parse, timestamp
				timestamp := (A_Index = 1) ? "" : timestamp, timestamp .= IsNumber(A_LoopField) ? A_LoopField : ""
			method := SubStr(loopfield, InStr(loopfield, " ",, 0) + 1), method := Trim(method, "'")
			If (timestamp > vars.general.input_method.2)
			{
				vars.general.input_method := [method, timestamp]
				If (vars.settings.active = "general")
					Settings_menu("general")
			}
		}
		*/

		If (filter_tag := vars.lootfilter.update_pending.1)
			If InStr(loopfield, "Finished reloading online filter " filter_tag)
			{
				vars.lootfilter.update_pending := "", vars.lootfilter.update_applied := (vars.lootfilter.modifications["profile" settings.lootfilter.profile].Count() > 1 ? 1 : 0), filter := settings.lootfilter.active_filter
				vars.lootfilter.modifications_pending := [], vars.lootfilter.modifications_pending.0 := ""
				Lootfilter_Load("init_" filter)
				Lootfilter_Editor(), LLK_ToolTip(Lang_Trans("global_success"),,,,, "Lime")
			}

		If (auto_track = "a") && (settings.leveltracker.autotrack * settings.features.leveltracker) && InStr(loopfield, "[info")
		{
			char_name := "", parse := SubStr(loopfield, InStr(loopfield, "]",, 0))
			If InStr(parse, ":")
				parse := SubStr(parse, 1, InStr(parse, ":") - 1), char_name := SubStr(parse, InStr(parse, " ",, 0) + 1), char_name := LLK_StringCase(char_name)

			If char_name && (char_name != settings.general.character) && !RegexMatch(char_name, "i)\.|\s") && !RegExMatch(char_name, "@|#|%|&|\$")
				For iChars, oChars in vars.leveltracker.characters
					If oChars.character && (oChars.character = char_name)
					{
						auto_track := 2
						IniWrite, % (settings.general.character := char_name), % "ini" vars.poe_version "\config.ini", Settings, active character
						IniWrite, % """" (settings.general.build := oChars.build) """", % "ini" vars.poe_version "\config.ini", Settings, active build
						IniWrite, % (iChars = 1 ? "" : iChars), % "ini" vars.poe_version "\leveling tracker.ini", Settings, profile
						Break
					}
		}
		If !vars.poe_version && RegExMatch(loopfield, "i)set.source.\[(?!\(|" Lang_Trans("log_act") ".\d)")
			parse := SubStr(loopfield, InStr(loopfield, "[",, 0)), areaname := LLK_StringCase(Trim(parse, " []`r`n"))

		If !Blank(settings.general.character) && InStr(loopfield, settings.general.character) && IsObject((character_info := Log_CharacterInfo(loopfield)))
			level := character_info.1, character_class := character_info.2
		Else If (settings.leveltracker.autotrack * settings.features.leveltracker) && (vars.log.areaID = "1_1_1" || vars.log.areaID = "g1_1") && vars.hwnd.leveltracker.main && InStr(loopfield, Lang_Trans("log_level"))
		{
			parse := SubStr(loopfield, InStr(loopfield, ":",, 0) + 1), character_info := Log_CharacterInfo(loopfield, 1), profile := settings.leveltracker.profile
			IniWrite, % (settings.general.character := character_info.3), % "ini" vars.poe_version "\config.ini", Settings, active character
			IniWrite, % """" (settings.general.build := settings.leveltracker["guide" profile].info.name) """", % "ini" vars.poe_version "\config.ini", Settings, active build
			IniWrite, % """" (settings.leveltracker["guide" profile].info.character := character_info.3) """", % "ini" vars.poe_version "\leveling guide" profile ".ini", Info, character
			level := character_info.1, character_class := character_info.2, auto_track := 1
		}

		If settings.features.maptracker && (vars.log.areaID = vars.maptracker.map.id) && (Lang_Match(loopfield, vars.lang.log_slain) || Lang_Match(loopfield, vars.lang.log_suicide))
			vars.maptracker.map.deaths += 1, vars.maptracker.map.died := 1

		If settings.features.maptracker && settings.maptracker.kills && vars.maptracker.refresh_kills && Lang_Match(loopfield, vars.lang.log_killed)
		{
			parse := SubStr(loopfield, InStr(loopfield, vars.lang.log_killed.1)), parse := Lang_Trim(parse, vars.lang.log_killed)
			Loop, Parse, parse
				parse := (A_Index = 1) ? "" : parse, parse .= IsNumber(A_LoopField) ? A_LoopField : ""

			If (vars.maptracker.refresh_kills = 1)
			{
				If IsNumber(vars.maptracker.map_prev.kills.1)
				{
					IniWrite, % (backlog_kills := parse - vars.maptracker.map_prev.kills.1), % "ini" vars.poe_version "\map tracker log.ini", % vars.maptracker.map_prev.date_time, kills
					If IsObject(vars.maptracker.entries)
						vars.maptracker.entries[SubStr(vars.maptracker.map_prev.date_time, 1, InStr(vars.maptracker.map_prev.date_time, " ") - 1)].1.kills := backlog_kills, LLK_Overlay(vars.hwnd.maptracker_logs.main, "destroy")
				}
				vars.maptracker.map.kills := [parse], LLK_ToolTip(Lang_Trans("maptracker_kills", 2),,,,, "Lime"), vars.tooltip_mouse := "", vars.maptracker.refresh_kills := 2
			}
			Else If (vars.maptracker.refresh_kills > 1) && Maptracker_Towncheck()
				vars.maptracker.map.kills.2 := parse, LLK_ToolTip(Lang_Trans("maptracker_kills", 2),,,,, "Lime"), vars.maptracker.refresh_kills := 3, vars.maptracker.last_kills := parse
		}

		If settings.features.maptracker && settings.maptracker.mechanics && vars.maptracker.map.id && (vars.log.areaID = vars.maptracker.map.id)
			Maptracker_ParseDialogue(loopfield)

		If settings.qol.mapevents
			For index0, type in settings.mapevents.event_list
				If (type = "hideout") && settings.mapevents.hideout && InStr(loopfield, "] Spawning discoverable Hideout")
				{
					map_ID := (areaID ? areaID : vars.log.areaID), map_seed := (areaseed ? areaseed : vars.log.areaseed)
					If (map_ID != vars.mapevents.hideout.ID || map_seed != vars.mapevents.hideout.seed)
						MapEvent_Hideout(map_ID, map_seed)
					Break
				}
				Else If settings.mapevents[type]
					For index1, line in vars.lang["log_" type]
						If InStr(loopfield, line, 1) && (type != "infamous" || type = "infamous" && MapEvent_InfamousMerc(loopfield "."))
						{
							MapEvent(type)
							Break
						}

		For key, val in vars.addons.list
			vars.addons.list[key].func.LogRead(loopfield)
	}
}
