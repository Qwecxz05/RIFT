﻿; RIFT minimal compatibility layer. The old hub and its Item Info UI are removed.
; Notes and language switching remain available in the in-game overlay.
RIFT_UI_CommitNotes()
{
    ; Legacy dashboard editor was removed; active RIFT12 editor saves itself.
    return
}

RIFT_ChangeLanguage(language)
{
    global settings, vars
    if (language != "english" && language != "russian")
        return
    if (settings.general.lang = language)
        return
    RIFT_SavePages()
    IniWrite, % language, % "ini" vars.poe_version "\config.ini", settings, language
    settings.general.lang := language
    Init_Lang()
    if (settings.features.leveltracker && vars.leveltracker.guide.import.Count())
    {
        Leveltracker_Load()
        if vars.leveltracker.toggle
            Leveltracker_Progress()
    }
    if IsObject(vars.settings) && IsObject(vars.settings.sections)
    {
        vars.settings.sections2 := []
        for index, section in vars.settings.sections
            vars.settings.sections2.Push(Lang_Trans("ms_" section))
    }
}
