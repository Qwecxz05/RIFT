﻿Omnikey()
{
    local
    global vars, settings
    if vars.omnikey.last
        return
    vars.omnikey.last := A_TickCount
    if vars.client.stream
    {
        Omnikey2()
        return
    }
    if (vars.general.wMouse = vars.hwnd.poe_client) && !WinActive("ahk_id " vars.hwnd.poe_client)
    {
        WinActivate, % "ahk_id " vars.hwnd.poe_client
        WinWaitActive, % "ahk_id " vars.hwnd.poe_client
    }
    Clipboard := ""
    SendInput, ^{c}
    ClipWait, 0.1
    if Clipboard
    {
        if (settings.general.lang_client = "unknown")
            LLK_ToolTip(Lang_Trans("omnikey_language"), 3,,,, "red")
        else
        {
            vars.omnikey.start := A_TickCount, vars.omnikey.item := {}
            Omni_ItemInfo()
            Switch Omni_Context()
            {
                Case "iteminfo":
                    If settings.features.iteminfo
                        Iteminfo()
                Case "gemnotes":
                    MouseGetPos, xMouse, yMouse
                    vars.leveltracker.gemlinks.drag := 0, Leveltracker_PobGemLinks(vars.omnikey.item.name,, xMouse, yMouse + 10)
                    Omni_Release()
                    If !settings.leveltracker.gemlinksToggle
                        LLK_Overlay(vars.hwnd.leveltracker_gemlinks.main, "destroy"), vars.hwnd.leveltracker_gemlinks.main := ""
                    Return
                Case "gemregex":
                    Leveltracker_PobGemCutting()
                    SendInput, {RButton}
                Case "geartracker":
                    Geartracker_Add()
            }
        }
    }
    else
        Omnikey2()
    Omni_Release()
}
Omnikey2()
{
	local
	global vars, settings

	If vars.omnikey.last2
		Return
	vars.omnikey.last2 := A_TickCount
	String_Scroll("ESC") ;close searchstring-scrolling
	If !IsObject(vars.omnikey)
		vars.omnikey := {}

	guide := vars.leveltracker.guide
	If settings.features.cheatsheets && GetKeyState(settings.cheatsheets.modifier, "P")
	{
		vars.cheatsheets.pHaystack := Gdip_BitmapFromHWND(vars.hwnd.poe_client, 1)
		For cheatsheet in vars.cheatsheets.list
		{
			If !vars.cheatsheets.list[cheatsheet].enable
				continue
			If Cheatsheet_Search(cheatsheet)
			{
				Cheatsheet_Activate(cheatsheet), cheatsheet_on := 1
				Break
			}
		}
		Gdip_DisposeImage(vars.cheatsheets.pHaystack)
		If cheatsheet_on
		{
			Omni_Release()
			Return
		}
	}

	Screenchecks_ImageSearch()
	If settings.features.betrayal && vars.imagesearch.betrayal.check
		Betrayal(), active := 1
	Else If settings.features.leveltracker && vars.imagesearch.skilltree.check
	{
		If settings.leveltracker.pobmanual
			Leveltracker_Skilltree()
		Else
			If !vars.leveltracker.skilltree_schematics.GUI
				Leveltracker_PobSkilltree()
			Else Leveltracker_PobSkilltree("close")
		active := 1
	}
	Else If settings.features.sanctum && InStr(vars.log.areaID, "sanctum") && !InStr(vars.log.areaID, "fellshrine") && vars.imagesearch.sanctum.check
		vars.sanctum.lock := 0, Sanctum(), active := 1
	Else If settings.features.exchange && vars.imagesearch.exchange.check
	{
		If !vars.hwnd.exchange.main
			Exchange()
		Else Exchange("close")
		active := 1
	}
	Else If settings.features.async && (vars.imagesearch.async1.check || vars.imagesearch.async2.check)
	{
		If !vars.hwnd.async.main
			AsyncTrade(vars.imagesearch.async1.check ? "sell" : "buy")
		Else AsyncTrade("close")
		active := 1
	}
	Else If settings.features.statlas && vars.imagesearch.atlas.check
	{
		If !WinExist("OCR debug") && Statlas()
			Statlas_GUI()

		Omni_Release(), active := 1
		Gui, ocr_comms: Destroy
		LLK_Overlay(vars.hwnd.statlas.main, "destroy"), vars.hwnd.statlas.main := ""
		If (settings.statlas.tier0 != settings.statlas.tier)
			IniWrite, % (settings.statlas.tier0 := settings.statlas.tier), % "ini" vars.poe_version "\statlas.ini", settings, filter tier
		If (settings.statlas.zoom0 != settings.statlas.zoom)
			IniWrite, % (settings.statlas.zoom0 := settings.statlas.zoom), % "ini" vars.poe_version "\statlas.ini", settings, zoom
	}
	Else If settings.features.runeshaping && vars.imagesearch["runeshaping" (settings.general.input_method = 2 ? "2" : "")].check
	{
		If !WinExist("OCR debug")
			Runeshape_OCR()

		If settings.runeshaping.hold_ctrl
			SendInput, {LControl down}
		Omni_Release(), active := 1
		If settings.runeshaping.hold_ctrl
			SendInput, {LControl up}
		LLK_Overlay(vars.hwnd.runeshaping.main, "destroy"), vars.hwnd.runeshaping := ""
		Gui, ocr_comms: Destroy
	}
	Else If (InStr(vars.log.areaID, "_town") || LLK_StringCompare(vars.log.areaID, ["hideout"]) || (vars.log.areaID = "1_3_17_1") || vars.client.stream) && vars.leveltracker.toggle && (guide.gemList.Count() || guide.itemList.Count())
	{
		start := A_TickCount
		While GetKeyState(vars.omnikey.hotkey, "P") || !Blank(vars.omnikey.hotkey2) && GetKeyState(vars.omnikey.hotkey2, "P")
		{
			If (A_TickCount >= start + 200)
			{
				String_ContextMenu("exile-leveling"), active := 1
				Break
			}
		}
	}

	If active
	{
		Omni_Release()
		Return
	}

	If !stash && vars.searchstrings.enabled
	{
		If WinExist("ahk_id "vars.hwnd.searchstrings_menu.main)
			String_MenuSave()
		vars.searchstrings.pHaystack := Gdip_BitmapFromHWND(vars.hwnd.poe_client, 1)
		For string, val in vars.searchstrings.list
		{
			If !val.enable || InStr(string, "_")
				Continue
			If String_Search(string)
			{
				String_ContextMenu(string)
				Break
			}
		}
		Gdip_DisposeImage(vars.searchstrings.pHaystack)
	}
	Omni_Release()
}

Omni_Release()
{
	local
	global vars, settings

	KeyWait, % vars.omnikey.hotkey
	KeyWait, % vars.omnikey.hotkey2
	If IsObject(vars.omnikey)
		vars.omnikey.last := "", vars.omnikey.last2 := ""
	If (vars.omnikey.hotkey = "capslock")
		SetCapsLockState, Off
	Else SendInput, % "{" settings.hotkeys.omnikey " UP}"

	If (settings.iteminfo.activation = "hold") && WinExist("ahk_id " vars.hwnd.iteminfo.main)
		LLK_Overlay(vars.hwnd.iteminfo.main, "destroy")
	If (settings.mapinfo.activation = "hold") && WinExist("ahk_id " vars.hwnd.mapinfo.main)
		LLK_Overlay(vars.hwnd.mapinfo.main, "destroy")
	If (settings.features.sanctum) && !vars.sanctum.lock && !vars.sanctum.scanning && WinExist("ahk_id " vars.hwnd.sanctum.main)
		Sanctum("close")
	Sleep 200 ;to prevent another omni-key trigger when releasing the key after a long-press
}

Omni_Context(mode := 0)
{
	local
	global vars, settings

	If mode
		Iteminfo(2)
	clip := !mode ? vars.omnikey.clipboard : Clipboard, item := vars.omnikey.item

	If !vars.poe_version
		While (!settings.features.stash || GetKeyState("ALT", "P")) && (GetKeyState(vars.omnikey.hotkey, "P") || !Blank(vars.omnikey.hotkey2) && GetKeyState(vars.omnikey.hotkey2, "P")) && InStr(item.name, "Essence of ", 1) || (item.name = "remnant of corruption")
			If (A_TickCount >= vars.omnikey.start + 200)
				Return "essences"

	If vars.hwnd.anoints.main && RegExMatch(vars.omnikey.item.name, "^(Potent\s){0,1}(Diluted|Liquid|Concentrated)\s.*|.*\sOil$")
		Return "anoints_stock"

	If settings.features.lootfilter && (item.name || item.itembase) && (vars.hwnd.lootfilter.main && WinExist("ahk_id " vars.hwnd.lootfilter.main) || GetKeyState(settings.lootfilter.modifier_key, "P"))
		Return "lootfilter"
	If WinExist("ahk_id " vars.hwnd.recombination.main) && LLK_PatternMatch(item.class, "", vars.recombination.classes,,, 0)
		Return "recombination"
	If WinExist("ahk_id "vars.hwnd.legion.main) && (item.itembase = "Timeless Jewel")
		Return "legion"
	If WinExist("ahk_id " vars.hwnd.notepad.main) && (vars.notepad.selected_entry = "gems") && (item.rarity = Lang_Trans("items_gem"))
		Return "gemnotepad"

	While settings.features.leveltracker && (GetKeyState(vars.omnikey.hotkey, "P") || !Blank(vars.omnikey.hotkey2) && GetKeyState(vars.omnikey.hotkey2, "P")) && (item.rarity = Lang_Trans("items_gem") || LLK_PatternMatch(item.name, "", [Lang_Trans("items_uncut_gem", 1), Lang_Trans("items_uncut_gem", 2), Lang_Trans("items_uncut_gem", 3)],,, 0))
		If (A_TickCount >= vars.omnikey.start + 200)
			Return "gemnotes"
	If settings.features.leveltracker && LLK_PatternMatch(item.name, "", [Lang_Trans("items_uncut_gem", 1), Lang_Trans("items_uncut_gem", 2), Lang_Trans("items_uncut_gem", 3)],,, 0)
		Return "gemregex"

	If settings.features.sanctum && settings.sanctum.relics && (item.class = Lang_Trans("items_relics")) && RegExMatch(vars.log.areaID, "i)sanctumfoyer_fellshrine|g2_13")
		While GetKeyState(vars.omnikey.hotkey, "P") || !Blank(vars.omnikey.hotkey2) && GetKeyState(vars.omnikey.hotkey2, "P")
			If (A_TickCount >= vars.omnikey.start + 200)
				Return "relics"

	If (!vars.poe_version && !LLK_PatternMatch(item.name "`n" item.itembase, "", ["Doryani", "Maple"]) && LLK_PatternMatch(item.name "`n" item.itembase, "", ["Map", "Chart", "Invitation", "Blueprint:", "Contract:", "Expedition Logbook"])
	|| vars.poe_version && LLK_PatternMatch(item.name "`n" item.itembase, "", [Lang_Trans("items_waystone")]))
	&& (item.rarity != Lang_Trans("items_unique"))
	{
		If InStr(clip, Lang_Trans("items_mapreward"))
			Return "context_menu"

		If settings.features.mapinfo
			Return "mapinfo"
	}
	If settings.features.stash
	{
		check := LLK_HasKey(vars.stash, item.name,,,, 1), start := A_TickCount
		While check && (Blank(item.itembase) || item.name = item.itembase) && (GetKeyState(vars.omnikey.hotkey, "P") || !Blank(vars.omnikey.hotkey2) && GetKeyState(vars.omnikey.hotkey2, "P"))
			If (A_TickCount >= start + 150)
			{
				Stash(check)
				Return
			}
	}

	If settings.features.iteminfo
	{
		If WinExist("ahk_id " vars.hwnd.iteminfo.main)
			Return "iteminfo"
		While GetKeyState(vars.omnikey.hotkey, "P") || !Blank(vars.omnikey.hotkey2) && GetKeyState(vars.omnikey.hotkey2, "P")
			If (A_TickCount >= vars.omnikey.start + 200)
				Return "iteminfo"
	}

	If WinExist("ahk_id " vars.hwnd.geartracker.main)
		Return "geartracker"
	If !LLK_PatternMatch(item.name "`n" item.itembase, "", ["Map", "Waystone", "Invitation", "Blueprint:", "Contract:", "Expedition Logbook"]) || LLK_PatternMatch(item.name "`n" item.itembase, "", ["Doryani", "Maple"])
	|| (item.rarity = Lang_Trans("items_unique"))
		Return "context_menu"
}

Omni_ContextMenu()
{
	local
	global vars, settings, db

	If !IsObject(db.item_bases)
		DB_Load("item_bases")

	Loop 2
	{
		Gui, omni_context: New, -Caption +LastFound +AlwaysOnTop +ToolWindow +Border HWNDhwnd0
		Gui, omni_context: Margin, % settings.general.fWidth, % settings.general.fWidth//2
		Gui, omni_context: Color, Black
		Gui, omni_context: Font, % "s"settings.general.fSize " cWhite", % vars.system.font
		vars.hwnd.omni_context := {"main": hwnd0}, vars.omni_context := {}, item := vars.omnikey.item, style := (A_Index = 2) ? " w" width : "", hwnd := ""
		clip := vars.omnikey.clipboard

		If !LLK_PatternMatch(item.name "`n" item.itembase, "", ["Doryani", "Maple"]) && LLK_PatternMatch(item.name "`n" item.itembase, "", ["Map", "Invitation", "Blueprint:", "Contract:", "Expedition Logbook"])
		&& (check := InStr(clip, Lang_Trans("items_mapreward")))
		{
			reward := SubStr(clip, check + StrLen(Lang_Trans("items_mapreward")) + 1), reward := StrReplace(SubStr(reward, 1, InStr(reward, "`r") - 1), Lang_Trans("items_mapreward_foil"))
			Gui, omni_context: Add, Text, % "Section gOmni_ContextMenuPick HWNDhwnd" style, % "wiki: " LLK_StringCase(reward)
			ControlGetPos,,, w1,,, % "ahk_id " hwnd
			vars.hwnd.omni_context.wiki_exact := hwnd, vars.omni_context[hwnd] := reward
		}
		Else If (settings.general.lang_client = "english") && InStr(item.name "`n" item.itembase, "inscribed ultimatum") && (check := InStr(clip, "requires sacrifice: "))
		{
			sacrifice := SubStr(clip, check + StrLen("requires sacrifice: ")), sacrifice := Trim(SubStr(sacrifice, 1, (check := RegExMatch(sacrifice, "i)\sx\d")) ? check - 1 : InStr(sacrifice, "`n") - 1), " `r`n")
			reward := SubStr(clip, InStr(clip, "reward: ") + 8), reward := Trim(SubStr(reward, 1, (check := RegExMatch(reward, "i)\sx\d")) ? check - 1 : InStr(reward, "`n") - 1), " `r`n")

			Gui, omni_context: Add, Text, % "Section gOmni_ContextMenuPick HWNDhwnd" style, % "wiki: inscribed ultimatum"
			ControlGetPos,,, w1,,, % "ahk_id " hwnd
			vars.hwnd.omni_context.wiki_exact := hwnd, vars.omni_context[hwnd] := "Inscribed Ultimatum"

			If !InStr(clip, "sacrificed currency")
			{
				Gui, omni_context: Add, Text, % "Section gOmni_ContextMenuPick HWNDhwnd" style, % "wiki: " LLK_StringCase(sacrifice . (InStr(reward, "sacrificed") ? "" : " && " reward))
				ControlGetPos,,, w2,,, % "ahk_id " hwnd
				vars.hwnd.omni_context.wiki_exact := hwnd, vars.omni_context[hwnd] := sacrifice . (InStr(reward, "sacrificed") ? "" : "|" reward)
				Clipboard := "^(" StrReplace(sacrifice . (InStr(reward, "sacrificed") ? "" : "|" reward), " ", ".") ")$"
			}
		}
		Else
		{
			If !(item.unid && item.rarity = Lang_Trans("items_unique")) && (LLK_PatternMatch(item.name, "", ["Splinter"]) || item.itembase || !LLK_PatternMatch(item.rarity, "", [Lang_Trans("items_magic"), Lang_Trans("items_rare"), Lang_Trans("items_currency")]))
			&& (settings.general.lang_client = "english")
			{
				Gui, omni_context: Add, Text, % "Section gOmni_ContextMenuPick HWNDhwnd" style, % "wiki: " LLK_StringCase(StrReplace(item[item.itembase && item.rarity != Lang_Trans("items_unique") ? "itembase" : "name"], "foulborn "))
				ControlGetPos,,, w1,,, % "ahk_id " hwnd
				vars.hwnd.omni_context.wiki_exact := hwnd, vars.omni_context[hwnd] := StrReplace(item[item.itembase && item.rarity != Lang_Trans("items_unique") ? "itembase" : "name"], "foulborn ")
			}

			If (item.rarity != Lang_Trans("items_unique")) && !Blank(item.class)
			&& (settings.general.lang_client = "english" && !InStr(item.class, "currency") || (LLK_HasVal(db.item_bases._classes, item.class) || vars.poe_version && (vars.omnikey.poedb[item.class] || item.class = "augment")) || LLK_PatternMatch(item.name, "", ["Essence of", "Scarab", "Catalyst", " Oil", "Memory of "])) || RegExMatch(item.name, "^(Potent\s){0,1}(Diluted|Liquid|Concentrated)\s")
			{
				If !Blank(LLK_HasVal(db.item_bases._classes, item.class))
					class := db.item_bases._classes[LLK_HasVal(db.item_bases._classes, item.class)]
				Else If RegExMatch(item.name, "^(Potent\s){0,1}(Diluted|Liquid|Concentrated)\s")
					class := "Liquid emotion"
				Else If LLK_PatternMatch(item.name, "", ["Essence of", "Scarab", "Catalyst", " Oil", "Memory of "])
					class := LLK_PatternMatch(item.name, "", ["Essence of", "Scarab", "Catalyst", " Oil", "Memory of "])
				Else If (settings.general.lang_client = "english") || vars.poe_version
					class := item.class

				Gui, omni_context: Add, Text, % "Section" (hwnd ? " xs " : " ") "gOmni_ContextMenuPick HWNDhwnd" style, % "wiki: "
				. (class = "augment" ? (InStr(item.name, Lang_Trans("items_soul_core")) ? "soul cores" : (InStr(item.name, Lang_Trans("items_idol")) ? "idols" : "runes")) : LLK_StringCase((InStr(item.itembase, "Runic ") ? "runic " : "") . class))
				ControlGetPos,,, w2,,, % "ahk_id " hwnd
				If (class != "cluster jewels") && (!Blank(LLK_HasVal(db.item_bases._classes, item.class)) || vars.poe_version && vars.omnikey.poedb[item.class] || InStr(item.class, "heist") && item.itembase)
				{
					Gui, omni_context: Add, Text, % "Section xs gOmni_ContextMenuPick HWNDhwnd1" style, % "poe.db: " Lang_Trans("system_poedb_lang", 2)
					ControlGetPos,,, w3,,, % "ahk_id " hwnd1
				}
				If !item.unid && (settings.general.lang_client = "english") && !LLK_PatternMatch(item.name, "", ["Essence of", "Scarab", "Catalyst", " Oil"])
				&& (vars.poe_version && db.item_bases[item.class] || !vars.poe_version && !Blank(LLK_HasVal(db.item_bases._classes, item.class)))
				{
					Gui, omni_context: Add, Text, % "Section xs gOmni_ContextMenuPick HWNDhwnd2" style, % "craft of exile"
					ControlGetPos,,, w4,,, % "ahk_id " hwnd2
				}
				If !vars.poe_version && LLK_PatternMatch(item.class, "", vars.recombination.classes,,, 0)
					Gui, omni_context: Add, Text, % "Section xs gOmni_ContextMenuPick HWNDhwnd3 " style, % "recombination"
				If settings.features.anoints && RegExMatch(item.name, "^(Potent\s){0,1}(Diluted|Liquid|Concentrated)\s|\sOil$")
					Gui, omni_context: Add, Text, % "Section xs gOmni_ContextMenuPick HWNDhwnd4 " style, % Lang_Trans("ms_anoints")

				vars.hwnd.omni_context.wiki_class := hwnd, vars.omni_context[hwnd] := (class = "augment") ? (InStr(item.name, Lang_Trans("items_soul_core")) ? "soul core" : (InStr(item.name, Lang_Trans("items_idol")) ? "idol" : "rune")) : class, vars.hwnd.omni_context.poedb := hwnd1
				vars.hwnd.omni_context.craftofexile := hwnd2, vars.hwnd.omni_context.recombination := hwnd3, vars.hwnd.omni_context.anoints := hwnd4
				width := (Max(w, w1, w2) > width) ? Max(w, w1, w2) : width
			}
			Else If (item.rarity = Lang_Trans("items_unique")) && !Blank(item.class) && !Blank(item.attributes)
			{
				Gui, omni_context: Add, Text, % "Section xs gOmni_ContextMenuPick HWNDhwnd1" style, % "poe.db: " Lang_Trans("system_poedb_lang", 3)
				ControlGetPos,,, w3,,, % "ahk_id " hwnd1
				vars.hwnd.omni_context.poedb := hwnd1
			}

			If InStr(item.name, "to the goddess")
			{
				Gui, omni_context: Add, Text, % "Section" (hwnd ? " xs " : " ") "gOmni_ContextMenuPick HWNDhwnd", % "poelab.com"
				ControlGetPos,,, w5,,, % "ahk_id " hwnd
				vars.hwnd.omni_context.poelab := hwnd
			}

			If (class = "oil")
			{
				Gui, omni_context: Add, Text, % "Section" (hwnd ? " xs " : " ") "gOmni_ContextMenuPick HWNDhwnd", % "raelys' blight-helper"
				ControlGetPos,,, w6,,, % "ahk_id " hwnd
				vars.hwnd.omni_context.oiltable := hwnd
			}

			If (class = "Cluster jewels")
			{
				cluster_type := InStr(item.itembase, "small") ? "small" : InStr(item.itembase, "medium") ? "medium" : "large"
				Gui, omni_context: Add, Text, % "Section" (hwnd ? " xs " : " ") "gOmni_ContextMenuPick HWNDhwnd" style, % "poe.db: all clusters"
				Gui, omni_context: Add, Text, % "Section xs gOmni_ContextMenuPick HWNDhwnd1" style, % "poe.db: " . cluster_type . " clusters"
				ControlGetPos,,, w7,,, % "ahk_id " hwnd
				ControlGetPos,,, w8,,, % "ahk_id " hwnd1
				vars.hwnd.omni_context.poedb := hwnd, vars.hwnd.omni_context.poedb1 := hwnd1
				If (cluster_type = "large")
				{
					Gui, omni_context: Add, Text, % "Section xs gOmni_ContextMenuPick HWNDhwnd" style, % "cluster calc"
					ControlGetPos,,, w12,,, % "ahk_id " hwnd
					vars.hwnd.omni_context.clustercalc := hwnd
				}
			}

			If !item.unid && (item.itembase = "Timeless Jewel") && InStr(vars.omnikey.clipboard, Lang_Trans("items_uniquemod"))
			{
				;Gui, omni_context: Add, Text, % "Section" (hwnd ? " xs " : " ") "gOmni_ContextMenuPick HWNDhwnd" style, % "seed-explorer"
				;ControlGetPos,,, w9,,, % "ahk_id " hwnd
				Gui, omni_context: Add, Text, % "Section xs gOmni_ContextMenuPick HWNDhwnd1" style, % "vilsol's calculator"
				ControlGetPos,,, w10,,, % "ahk_id " hwnd
				;vars.hwnd.omni_context.seed := hwnd
				vars.hwnd.omni_context.vilsol := hwnd1
			}

			If !item.unid && item.sockets && !vars.poe_version
			{
				Gui, omni_context: Add, Text, % "Section" (hwnd ? " xs " : " ") "gOmni_ContextMenuPick HWNDhwnd" style, % "chromatic calculator"
				ControlGetPos,,, w11,,, % "ahk_id " hwnd
				vars.hwnd.omni_context.chromatics := hwnd
			}
		}
		Loop 12
			w%A_Index% := !w%A_Index% ? 0 : w%A_Index%
		width := Max(w1, w2, w3, w4, w5, w6, w7, w8, w9, w10, w11)
	}

	MouseGetPos, mouseX, mouseY
	Gui, omni_context: Show, % "NA x10000 y10000"
	WinGetPos,,, w, h, % "ahk_id " vars.hwnd.omni_context.main
	If (settings.general.input_method = 2)
	{
		xTarget := vars.monitor.x + vars.client.xc + vars.client.h * 0.174 - w
		yTarget := vars.monitor.y + vars.client.yc + vars.client.h * 0.104 - h//2
	}
	Else
	{
		xTarget := (mouseX + w > vars.client.x + vars.client.w) ? vars.client.x + vars.client.w - w : mouseX
		yTarget := (mouseY + h > vars.client.y + vars.client.h) ? vars.client.y + vars.client.h - h : mouseY
	}
	If (w > 50)
		Gui, omni_context: Show, % "NA x" xTarget " y" yTarget
	Else Gui, omni_context: Destroy
}

Omni_ContextMenuPick(cHWND)
{
	local
	global vars, settings

	item := vars.omnikey.item, check := LLK_HasVal(vars.hwnd.omni_context, cHWND), control := SubStr(check, InStr(check, " ") + 1)
	KeyWait, LButton
	If InStr(check, "wiki_")
	{
		class := StrReplace(vars.omni_context[cHWND], " ", "_"), class := (class = "body_armours") ? "Body_armour" : (InStr(item.itembase, "Runic ") ? "Runic_base_type#" : "") . class
		class := StrReplace(class, "Jewels", "jewel"), class := InStr(item.class, "heist ") ? "Rogue's_equipment#" . StrReplace(item.class, "heist ") : class
		Loop, Parse, class, `|
			Run, % "https://www.poe" Trim(vars.poe_version, " ") "wiki.net/wiki/" . A_LoopField
	}
	Else If (check = "poelab")
	{
		Run, % "https://www.poelab.com/"
		If settings.qol.lab
		{
			WinWaitActive, ahk_group snipping_tools,, 2
			ToolTip_Mouse("lab", 1)
		}
		If settings.qol.lab
			Lab("import")
	}
	Else If (check = "oiltable")
		Run, https://blight.raelys.com/
	Else If InStr(check, "poedb")
	{
		If InStr(item.itembase, "Cluster Jewel")
			page := (InStr(A_GuiControl, "all clusters") ? "" : (InStr(item.itembase, "small") ? "Small_" : InStr(item.itembase, "medium") ? "Medium_" : "Large_")) "Cluster_Jewel"
		Else If InStr(item.itembase, "Runic ", 1)
			page := (item.class = "boots") ? "Runic_Sabatons" : (item.class = "helmets") ? "Runic_Crown" : "Runic_Gauntlets"
		Else If !Blank(LLK_HasVal(["unset ring", "iron flask", "bone ring", "convoking wand", "bone spirit shield", "silver flask", Lang_Trans("items_cannon")], item.itembase)) || InStr(item.class, "jewels") || InStr(item.class, "heist")
			page := StrReplace(item.itembase, " ", "_")
		Else page := StrReplace(item.class, " ", "_") . item.attributes
		Run, % "https://poe" Trim(vars.poe_version, " ") "db.tw/" . Lang_Trans("system_poedb_lang") . "/" . page . (item.rarity = Lang_Trans("items_unique") ? "#VaalOrbCorrupted" (vars.poe_version ? "Enchantment" : "Implicit") : (InStr(page, "cluster_jewel") ? "#EnchantmentModifiers" : "#ModifiersCalc"))
		Clipboard := item.ilvl
		If InStr(page, "cluster_jewel") && settings.features.browser
		{
			WinWaitActive, ahk_group snipping_tools,, 2
			ToolTip_Mouse("cluster", 1)
		}
	}
	Else If (check = "clustercalc")
		Run, % "https://clusters.poetools.dev/"
	Else If (check = "craftofexile")
		Run, % "https://www.craftofexile.com/?game=poe" (vars.poe_version ? "2" : "1")
	Else If (check = "seed")
		Legion_Parse(), Legion_GUI()
	Else If (check = "vilsol")
	{
		Legion_Parse()
		Run, % "https://vilsol.github.io/timeless-jewels/tree?jewel=" vars.legion.jewel_number "&conqueror=" LLK_StringCase(vars.legion.leader,, 1) "&seed=" vars.legion.seed "&mode=seed"
	}
	Else If (check = "chromatics")
	{
		Run, https://siveran.github.io/calc.html
		If settings.features.browser
		{
			WinWaitActive, ahk_group snipping_tools,, 1
			ToolTip_Mouse("chromatics", 1)
		}
	}
	Else If (check = "recombination")
		Recombination()
	Else If (check = "anoints")
		Anoints()
	Gui, omni_context: Destroy
}

Omni_ItemInfo()
{
	local
	global vars, settings, db

	Iteminfo(2)
	item := vars.omnikey.item, clip := vars.omnikey.clipboard ;short-cut variables
	If !IsObject(db.item_bases)
		DB_Load("item_bases")

	If !vars.poe_version && item.itembase
	{
		item.attributes := ""
		For class, val in db.item_bases
			If InStr(item.class, class)
				For subtype, val1 in val
					If val1.HasKey(item.itembase)
						item.attributes .= InStr(subtype, "armour") ? "_str" : "", item.attributes .= InStr(subtype, "evasion") ? "_dex" : "", item.attributes .= InStr(subtype, "energy") ? "_int" : ""
	}
	Else If vars.poe_version && item.class && (vars.omnikey.poedb[item.class] = 2)
	{
		item.attributes := ""
		For class, val in db.item_bases
			If InStr(item.class, class)
				If val.HasKey(item.itembase)
					item.attributes .= (val[item.itembase].ar ? "_str" : ""), item.attributes .= (val[item.itembase].ev ? "_dex" : ""), item.attributes .= (val[item.itembase].es ? "_int" : "")
	}

	Loop, Parse, clip, `n, % "`r " ;store the item's class, rarity, and miscellaneous info
	{
		loopfield := A_LoopField
		If InStr(A_LoopField, Lang_Trans("items_level"), 1) && !InStr(A_LoopField, Lang_Trans("items_ilevel"))
			item.lvl_req := StrReplace(SubStr(A_LoopField, InStr(A_LoopField, ":") + 2), " (unmet)"), item.lvl_req := (item.lvl_req < 10) ? 0 . item.lvl_req : item.lvl_req

		Loop, Parse, % "str,dex,int", `,
			If LLK_PatternMatch(loopfield, "", vars.lang["items_" A_LoopField])
				item[A_LoopField] := StrReplace(StrReplace(SubStr(loopfield, InStr(loopfield, ":") + 2), " (augmented)"), " (unmet)")

		If (item.itembase = Lang_Trans("items_merc_warrant"))
			If InStr(A_LoopField, Lang_Trans("items_merc_build"))
				item.name .= " (" SubStr(A_LoopField, InStr(A_LoopField, ":") + 2) ")"
			Else If InStr(A_LoopField, Lang_Trans("items_merc_level"))
				item.ilvl := SubStr(A_LoopField, InStr(A_LoopField, ":") + 2)

		If InStr(A_LoopField, Lang_Trans("items_ilevel"))
			item.ilvl := SubStr(A_LoopField, InStr(A_LoopField, ":") + 2)

		If InStr(A_LoopField, Lang_Trans("mods_cluster_passive"))
			item.cluster_enchant := StrReplace(StrReplace(SubStr(A_LoopField, StrLen(Lang_Trans("mods_cluster_passive")) + 2), "+"), " (enchant)")

		If !InStr("rings,belts,amulets", item.class) && LLK_PatternMatch(SubStr(A_LoopField, 0), "", ["R", "G", "B", "W", "A", "S"])
			item.sockets := StrLen(StrReplace(StrReplace(SubStr(A_LoopField, InStr(A_LoopField, ":") + 2), " "), "-"))

		If InStr(A_LoopField, Lang_Trans("items_maptier"))
			item.tier := SubStr(A_LoopField, InStr(A_LoopField, ":") + 2)

		If InStr(A_LoopField, Lang_Trans("items_stack"))
		{
			stack := SubStr(A_LoopField, InStr(A_LoopField, ":") + 2), stack := SubStr(stack, 1, InStr(stack, "/") - 1), item.stack := ""
			Loop, Parse, stack
				If IsNumber(A_LoopField)
					item.stack .= A_LoopField
		}
	}
}
