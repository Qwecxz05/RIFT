﻿#NoEnv
#SingleInstance Force
#Requires AutoHotkey >=1.1.36 <2 64-bit
#InstallKeybdHook
#InstallMouseHook
#Hotstring NoMouse
#UseHook
#MaxThreads 255
#MaxMem 1024
#Include %A_ScriptDir%
#Include data\Class_CustomFont.ahk
#Include data\External Functions.ahk
#Include data\JSON.ahk

ListLines, Off
SetWorkingDir %A_ScriptDir%
DllCall("SetThreadDpiAwarenessContext", "ptr", -3, "ptr")
OnMessage(0x0204, "RightClick")
OnMessage(0x004A, "StringReceive")
StringCaseSense, Locale
SetKeyDelay, 100
CoordMode, Mouse, Screen
CoordMode, Pixel, Screen
CoordMode, ToolTip, Screen
SendMode, Input
SetTitleMatchMode, 2
SetBatchLines, -1
OnExit("Exit")
Menu, Tray, Tip, RIFT
Menu, Tray, Icon, img\GUI\rift.ico

vars := {"general": {"runcheck": A_TickCount}, "logging": FileExist("data\log.txt"), "MainThread": 1, "news": {}, "update": [0]}, LLK_Log("waiting for valid game-clients...")
timeout := [LLK_IniRead("ini\config.ini", "settings", "kill script", 1), LLK_IniRead("ini\config.ini", "settings", "kill-timeout", 1)]
While !WinExist("ahk_class POEWindowClass") && !WinExist("ahk_exe GeForceNOW.exe") ;wait for game-client window
{
	If timeout.1 && (A_TickCount >= vars.general.runcheck + 60000 * timeout.2)
		ExitApp
	win_not_exist := 1
	Sleep, 500
}

;band-aid fix for situations in which the client was launched after the script, and the script detected an unsupported resolution because the PoE-client window was being resized during window-detection
If win_not_exist && (WinExist("ahk_class POEWindowClass") || WinExist("ahk_exe GeForceNOW.exe"))
	Sleep, 5000
LLK_Log("found game-client")
vars.poe_version := CheckClient(), LLK_Log("--- tool launched" (vars.poe_version ? " (PoE 2)" : "") " ---")

If FileExist("add-ons")
{
	other_version := (vars.poe_version ? "" : " 2")
	If FileExist("add-ons\loader" other_version)
		FileMove, % "add-ons\loader" other_version, % "add-ons\loader" other_version " (inactive)", % (moved := 1)
	If FileExist("add-ons\loader" vars.poe_version " (inactive)")
		FileMove, % "add-ons\loader" vars.poe_version " (inactive)", % "add-ons\loader" vars.poe_version, % (moved := 1)

	If moved
	{
		Sleep 500
		Reload
		ExitApp
	}
}

; RIFT disables upstream self-updates, which would overwrite this custom build.
If LLK_IniRead("ini\config.ini", "versions", "apply update")
    IniDelete, % "ini\config.ini", versions, apply update

Init_vars()
Startup()
Init_screenchecks(), LLK_Log("initialized screenchecks settings")
Init_general(), LLK_Log("initialized general settings")
ExileLite_LockFeatures()
Init_anoints(), LLK_Log("initialized anoints settings")
Init_betrayal(), LLK_Log("initialized betrayal settings")
Init_cheatsheets(), LLK_Log("initialized cheat-sheet settings")
Init_cloneframes(), LLK_Log("initialized clone-frames settings")
Init_exchange(), LLK_Log("initialized vaal street settings")
If WinExist("ahk_exe GeForceNOW.exe")
	Init_geforce(), LLK_Log("initialized geforce now settings")
; RIFT v13.2: Item Info removed from this edition
Init_legion(), LLK_Log("initialized seed-explorer settings")
; RIFT v13.2: FilterSpoon / Item Filter removed from this edition
Init_macros(), LLK_Log("initialized chat-macro settings")
Init_mapinfo(), LLK_Log("initialized map-info settings")
Init_TLDR(), LLK_Log("initialized TLDR-tooltip settings")
Init_searchstrings(), LLK_Log("initialized search-strings settings")
RIFT16_EnsureDefaultGuide()
Init_leveltracker(), LLK_Log("initialized act-tracker settings")
Init_actdecoder(), LLK_Log("initialized act-decoder settings")
Init_maptracker(), LLK_Log("initialized map-tracker settings")
Init_qol(), LLK_Log("initialized minor qol settings")
ExileLite_LockExtras()
Init_recombination(), LLK_Log("initialized recombination settings")
Init_sanctum(), LLK_Log("initialized sanctum planner settings")
Init_stash(), LLK_Log("initialized stash-ninja settings")
Init_statlas(), LLK_Log("initialized statlas settings")
Init_Runeshape(), LLK_Log("initialized rune-ninja settings")
Init_hotkeys(), LLK_Log("initialized hotkey settings")
Resolution_check()
RIFT_Init()
SetTimer, RIFT_SaveMyNotes, 15000
; Install only missing PoE1 layouts automatically, in the background.
; No PoB installation, login, or import is involved.
if (!RIFT_LayoutReady())
    RIFT_InstallLayouts(0)
Settings_menu("init")
Hotkey, ^!n, RIFT_ToggleOverlay, On
Hotkey, ^!r, RIFT_SettingsToggle, On
Menu, Tray, Add, RIFT Game Settings (Ctrl+Alt+R), RIFT_SettingsToggle
Menu, Tray, Add, Notes Overlay (Ctrl+Alt+N), RIFT_ToggleOverlay
if (LLK_IniRead("ini\rift.ini", "overlay", "restore", "0") = "1")
{
    IniWrite, 0, ini\rift.ini, overlay, restore
    SetTimer, RIFT_RestoreOverlay, -2000
}

SetTimer, Loop, 1000
SetTimer, Loop_main, 50

vars.system.timeout := 0
LLK_Log("waiting for focus on client-window...")
If !settings.general.dev
	WinWaitActive, ahk_group poe_window
Else
{
	WinWaitActive, ahk_group poe_ahk_window
	SoundBeep, 100
}
LLK_Log("client is focused")

SetTimer, Log_Loop, 1000

If (check := LLK_IniRead("ini" vars.poe_version "\config.ini", "versions", "reload settings"))
{
	Settings_menu(check,, 0)
	IniDelete, % "ini" vars.poe_version "\config.ini", Versions, reload settings
}
LLK_Log("+++ tool is running +++")


For key, val in vars.addons.list
	func := val.info.classname, vars.addons.list[key].func := new %func%(val.info.name)
Return

; Main settings are an on-top native game overlay; the separate dashboard is not the Esc menu.
RIFT_SettingsToggle()
{
    if IsFunc("RIFT12_Toggle")
        RIFT12_Toggle()
}

; --- RIFT PoE 1 Lite: supported feature policy (Act-Tracker + Act-Decoder + Notes) ---
ExileLite_LockFeatures()
{
    global vars, settings
    if (vars.poe_version)
    {
        MsgBox, 16, RIFT, This edition supports Path of Exile 1 only.
        ExitApp
    }
    for name, value in settings.features
    {
        if (name = "leveltracker" || name = "actdecoder")
        {
            key := (name = "leveltracker" ? "enable leveling guide" : "enable act-decoder")
            pref := LLK_IniRead("ini\config.ini", "features", key, "")
            settings.features[name] := (pref = "" ? 1 : pref + 0)
        }
        else settings.features[name] := 0
    }
    settings.features.iteminfo := 0
    settings.features.lootfilter := 0
    IniWrite, 0, ini\config.ini, features, enable item-info
    IniWrite, 0, ini\config.ini, features, enable filterspoon
    settings.general.ClientFiller := 0
    settings.general.ClientFillerTaskbar := 0
    settings.general.ClientFillerSplit := 0
    settings.updater.update_check := 0 ;prevent upstream auto-update from overwriting the modifications
}
ExileLite_LockExtras()
{
    global vars, settings
    for name, value in settings.qol
        if (name = "alarm" || name = "notepad" || name = "lab" || name = "mapevents" || name = "quickpob")
            settings.qol[name] := 0
    vars.searchstrings.enabled := 0
    vars.cloneframes.enabled := 0
    settings.general.ClientFiller := 0
}
; --- End of Lite policy ---
#Include modules\RIFT-Compat.ahk
#Include modules\RIFT-Settings-v12.inc
#Include modules\RIFT-Notes.inc
#Include modules\RIFT-MapArrows.inc
#Include modules\_functions.ahk
#Include modules\act-decoder.ahk
#Include modules\anoints.ahk
#Include modules\betrayal-info.ahk
#Include modules\cheat sheets.ahk
#Include modules\client log.ahk
#Include modules\clone-frames.ahk
#Include modules\exchange.ahk
#Include modules\GUI.ahk
#Include modules\hotkeys.ahk
#Include *i modules\hotkeys custom.ahk
#Include modules\item-checker.ahk
#Include modules\languages.ahk
#Include modules\leveling tracker.ahk
#Include modules\lootfilter.ahk
#Include modules\macros.ahk
#Include modules\map-info.ahk
#Include modules\map tracker.ahk
#Include modules\omni-key.ahk
#Include modules\qol tools.ahk
#Include modules\recombination.ahk
#Include modules\rune-ninja.ahk
#Include modules\sanctum.ahk
#Include modules\screen-checks.ahk
#Include modules\search-strings.ahk
#Include modules\seed-explorer.ahk
#Include modules\settings menu.ahk
#Include modules\stash-ninja.ahk
#Include modules\statlas.ahk
#Include modules\TLDR tooltips.ahk
#Include *i add-ons\loader

Exit()
{
	local
	global vars, settings, Json

	if !vars.rift.configImported
		RIFT_SaveMyNotes()
	Gdip_Shutdown(vars.general.Gdip)
	if IsObject(vars.log.file)
		vars.log.file.Close()

	If vars.general.MultiThreading
		PostMessage, 0x8000, 0, 0,, % vars.general.bThread

	If (vars.rift.configImported || vars.system.timeout != 0) ;script exited before completing startup routines: return here to prevent storing corrupt/incomplete data in ini-files
		Return
	If !vars.poe_version && IsObject(vars.betrayal.board) && (vars.betrayal.board0 != Json.Dump(vars.betrayal.board))
		IniWrite, % """" Json.Dump(vars.betrayal.board) """", ini\betrayal info.ini, settings, board
	timer := vars.leveltracker.timer
	If IsNumber(timer.current_split) && (timer.current_split != timer.current_split0)
		IniWrite, % vars.leveltracker.timer.current_split, % "ini" vars.poe_version "\leveling tracker.ini", % "current run" settings.leveltracker.profile, time

	If vars.maptracker.map.date_time
		Maptracker_Save()

	If vars.quickpob.style && WinExist("ahk_id " vars.quickpob.hwnd_pob)
		WinSet, ExStyle, -0x80, % "ahk_id " vars.quickpob.hwnd_pob
}

Economy_Update(type := "currency", minutes := 60)
{
	local
	global vars, settings

	timestamp := vars.economy[type].timestamp, league := settings.general.league.Clone(), league := (vars.poe_version ? vars.leagues[league.1].trade[league.3] : vars.leagues[league.1].trade.normal[league.4])
	If (timestamp.2 != "failed" && (!IsNumber(timestamp) || LLK_TimeElapsed(timestamp) > minutes)) || (timestamp.2 = "failed" && LLK_TimeElapsed(timestamp.1) > 10)
	{
		If !IsNumber(vars.stash[type].timestamp) || (vars.stash[type].league != league) || (LLK_TimeElapsed(vars.stash[type].timestamp) > minutes)
		{
			LLK_ToolTip(Lang_Trans("stash_update"), 0,,, "stashprices", "lime")
			success := Stash_PriceFetch(type)
			LLK_Overlay(vars.hwnd.tooltip_stashprices, "destroy")
		}
		If success || IsNumber(vars.stash[type].timestamp) && (LLK_TimeElapsed(vars.stash[type].timestamp) <= minutes)
		{
			vars.economy[type] := {"timestamp": A_NowUTC}, ini := IniBatchRead("data\global\[stash-ninja] prices" vars.poe_version ".ini", type)
			For key, val in ini[type]
				If !InStr(key, "_trend")
					vars.economy[type][key] := StrSplit(val, ",", " ")[(vars.poe_version ? 2 : 1)]
			If (type = "currency")
			{
				If vars.poe_version
					vars.economy.currency.exalted := 1
				Else vars.economy.currency.chaos := 1

				IniWrite, % (settings.exchange.chaos_div := Round(StrSplit(ini.currency.divine, ",", " ").1)), % "ini" vars.poe_version "\vaal street.ini", settings, chaos-div ratio
				IniWrite, % (settings.exchange.exalt_div := Round(StrSplit(ini.currency.divine, ",", " ").2)), % "ini" vars.poe_version "\vaal street.ini", settings, exalt-div ratio
			}
			If !IsObject(vars.economy.names)
				vars.economy.names := {}
			ini := IniBatchRead("data\global\[stash-ninja] prices" vars.poe_version ".ini", type " names")
			For key, val in ini[type " names"]
				vars.economy.names[key] := val
		}
		Else If !success
			vars.economy[type] := {"timestamp": [A_NowUTC, "failed"]}
	}
}

Init_client()
{
	local
	global vars, settings

	If !FileExist("ini\config.ini") ;ini\config.ini is required regardless of which PoE-version is being played
		IniWrite, % "", % "ini\config.ini", settings

	If !FileExist("ini" vars.poe_version "\config.ini")
		IniWrite, % "", % "ini" vars.poe_version "\config.ini", settings

	If !WinExist("ahk_exe GeForceNOW.exe") ;if client is not a streaming client
	{
		LLK_Log("game-client is local client")
		;load client-config location and double-check
		ini := IniBatchRead("ini" vars.poe_version "\config.ini")

		If vars.system.config_prelim && FileExist(vars.system.config_prelim . (vars.poe_version ? "poe2_" : "") "production_Config.ini")
			poe_config_file := vars.system.config_prelim . (vars.poe_version ? "poe2_" : "") "production_Config.ini"
		Else poe_config_file := !Blank(check := ini.settings["poe config-file"]) ? check : A_MyDocuments "\My Games\Path of Exile" (vars.poe_version ? " 2\poe2_" : "\") "production_Config.ini"

		If !FileExist(poe_config_file)
		{
			FileSelectFile, poe_config_file, 3, %A_MyDocuments%\My Games\\production_Config.ini, % "Please locate the '" (vars.poe_version ? "poe2_" : "") "production_Config.ini' file which is stored in the same folder as loot-filters", config files (*.ini)
			If (ErrorLevel = 1) || !InStr(poe_config_file, "production_Config")
			{
				Reload
				ExitApp
			}
			FileRead, poe_config_check, % poe_config_file
			If !InStr(poe_config_check, "[Display]")
			{
				Reload
				ExitApp
			}
		}
		IniWrite, % """" poe_config_file """", % "ini" vars.poe_version "\config.ini", Settings, PoE config-file
		vars.system.config := poe_config_file, vars.system.config_folder := SubStr(poe_config_file, 1, InStr(poe_config_file, "\",, 0) - 1), vars.client.stream := 0
		LLK_Log("found game's config-file")

		;check the contents of the client-config
		game_config := IniBatchRead(poe_config_file,, "blank")
		If !game_config.Count()
			LLK_Error("Cannot read the PoE config-file. Please restart the game-client and then the script. If you get this error repeatedly, please report the issue.`n`nError-message (for reporting): PoE-config returns empty")

		;check if the client is currently running in exclusive-fullscreen mode
		If !game_config.display.fullscreen
		{
			IniDelete, % "ini" vars.poe_version "\config.ini", Settings, PoE config-file
			LLK_Error("Cannot read the PoE config-file.`n`nThe script will restart and reset the first-time setup. If you still get this error repeatedly, please report the issue.`n`nError-message (for reporting): Cannot read state of exclusive fullscreen", 1)
		}
		Else If (game_config.display.fullscreen = "true")
			LLK_Error("The game-client is set to exclusive fullscreen.`nPlease set it to windowed fullscreen.")

		;check if the client is currently running in fullscreen or windowed mode
		vars.client.fullscreen := game_config.display.borderless_windowed_fullscreen
		If (vars.client.fullscreen = "")
		{
			IniDelete, % "ini" vars.poe_version "\config.ini", Settings, PoE config-file
			LLK_Error("Cannot read the PoE config-file.`n`nThe script will restart and reset the first-time setup. If you still get this error repeatedly, please report the issue.`n`nError-message (for reporting): Cannot read state of borderless fullscreen", 1)
		}
		LLK_Log("recognized current window settings")

		;check if client's window settings have changed since the previous session
		If ini.settings.fullscreen && (ini.settings.fullscreen != vars.client.fullscreen)
		{
			IniWrite, % vars.client.fullscreen, % "ini" vars.poe_version "\config.ini", Settings, fullscreen
			IniWrite, 0, % "ini" vars.poe_version "\config.ini", Settings, remove window-borders
			IniDelete, % "ini" vars.poe_version "\config.ini", Settings, custom-resolution
			IniDelete, % "ini" vars.poe_version "\config.ini", Settings, custom-width
			ini.settings["custom-width"] := ini.settings["custom-resolution"] := "", ini.settings["remove window-borders"] := 0
		}
		Else IniWrite, % vars.client.fullscreen, % "ini" vars.poe_version "\config.ini", Settings, fullscreen

		If !game_config.language.language || (game_config.language.language = "en")
			settings.general.lang_client0 := (!game_config.language.language && InStr(vars.log.file_location, "kakao") ? "ko-kr" : "english")
		Else settings.general.lang_client0 := game_config.language.language
	}
	Else vars.client.stream := 1, vars.client.fullscreen := "true"

	monitor_override := StrSplit(LLK_IniRead("ini\config.ini", "settings", "monitor override"), ",", " ")
	If (monitor_override.Count() != 2)
		monitor_override := ""
	Else
		For index, val in monitor_override
			If !IsNumber(val)
				monitor_override := ""

	If !monitor_override
	{
		;restore game-client to locate the active monitor
		WinGet, minmax, MinMax, ahk_group poe_window
		If (minmax = -1)
		{
			WinRestore, ahk_group poe_window
			Sleep, 2000
		}
		WinGetPos, x, y, w, h, ahk_group poe_window
	}
	Else x := monitor_override.1, y := monitor_override.2, w := 1280, h := 720

	Gui, Screen_Test: New, -DPIScale +LastFound +AlwaysOnTop +ToolWindow -Caption
	WinSet, Trans, 0
	Gui, Screen_Test: Show, % "NA x" x + w//2 " y" y + h//2 " Maximize"
	WinGetPos, xScreenOffset_monitor, yScreenOffSet_monitor, width_native, height_native
	Gui, Screen_Test: Destroy
	vars.monitor := {"x": xScreenOffset_monitor, "y": yScreenOffSet_monitor, "w": width_native, "h": height_native, "xc": xScreenOffset_monitor + width_native / 2, "yc": yScreenOffSet_monitor + height_native / 2}
	LLK_Log("measured monitor resolution and position: " width_native "x" height_native ", " xScreenOffset_monitor ", " yScreenOffSet_monitor)

	If monitor_override
		While (x_client "," y_client != vars.monitor.x "," vars.monitor.y)
		{
			WinGetPos, x_client, y_client,,, ahk_group poe_window
			Sleep 500
		}

	If !vars.client.stream
	{
		vars.client.docked := !Blank(check := ini.settings["window-position"]) ? check : 2, vars.client.docked2 := !Blank(check := ini.settings["window-position vertical"]) ? check : 1
		For index, val in ["", "2"]
			If !IsNumber(vars.client["docked" val])
				For index2, val2 in (!val ? ["left", "center", "right"] : ["top", "center", "bottom", "taskbar"])
					If (vars.client["docked" val] = val2)
						vars.client["docked" val] := index2
		If !IsNumber(vars.client.docked)
			vars.client.docked := 2
		If !IsNumber(vars.client.docked2)
			vars.client.docked2 := 1
		vars.client.borderless := (vars.client.fullscreen = "true") ? 1 : !Blank(check := ini.settings["remove window-borders"]) ? check : 0
		vars.client.customres := [ini.settings["custom-width"], ini.settings["custom-resolution"]]
	}
	If IsNumber(vars.client.customres.1) && IsNumber(vars.client.customres.2)
	{
		If (vars.client.customres.1 > vars.monitor.w) || (vars.client.customres.2 > vars.monitor.h) ;check resolution in case of manual .ini edit
		{
			MsgBox,, RIFT, Incorrect settings for forced resolution detected.`nThe script will reset the settings and restart.
			IniWrite, % vars.monitor.h, % "ini" vars.poe_version "\config.ini", Settings, custom-resolution
			IniWrite, % vars.monitor.w, % "ini" vars.poe_version "\config.ini", Settings, custom-width
			Reload
			ExitApp
		}

		If (vars.client.fullscreen = "true")
			WinMove, ahk_group poe_window,, % vars.monitor.x, % vars.monitor.y, % vars.client.customres.1, % vars.client.customres.2
		Else
		{
			WinSet, Style, % (vars.client.borderless ? "-" : "+") "0x40000", ahk_group poe_window ;add resize-borders
			WinSet, Style, % (vars.client.borderless ? "-" : "+") "0xC00000", ahk_group poe_window ;add caption
			If !vars.client.borderless
				WinMove, ahk_group poe_window,,,, % vars.client.customres.1 + 2* vars.system.xborder, % vars.client.customres.2 + vars.system.caption + 2* vars.system.yborder
			Else WinMove, ahk_group poe_window,,,, % vars.client.customres.1, % vars.client.customres.2
		}
		LLK_Log("applied custom resolution")
	}

	WinGetPos, x, y, w, h, ahk_group poe_window
	If (vars.client.docked2 = 4)
	{
		WinGetPos,,,, hTaskbar, ahk_class Shell_TrayWnd
		If !IsNumber(hTaskbar) || (h + hTaskbar > vars.monitor.h)
			vars.client.docked2 := 1
	}
	vars.client.x_offset := (vars.client.fullscreen = "false" && !vars.client.borderless) ? vars.system.xborder : 0
	xTarget := (vars.client.docked = 1) ? vars.monitor.x - vars.client.x_offset : (vars.client.docked = 2) ? vars.monitor.x + (vars.monitor.w - w) / 2 : vars.monitor.x + vars.monitor.w - (w - vars.client.x_offset)
	yTarget := (vars.client.docked2 = 1) ? vars.monitor.y : (vars.client.docked2 = 2) ? vars.monitor.y + (vars.monitor.h - h)/2 : vars.monitor.y + vars.monitor.h - (h - (vars.client.borderless ? 0 : vars.system.yBorder))

	If !vars.client.stream && ((vars.client.fullscreen = "false") || (vars.client.w < vars.monitor.w) || (vars.client.h < vars.monitor.h))
	{
		WinMove, ahk_group poe_window,, % xTarget, % yTarget - (vars.client.docked2 = 4 ? hTaskbar : 0)
		WinGetPos, x, y, w, h, ahk_group poe_window
		LLK_Log("repositioned game-client")
	}
	vars.client.x := vars.client.x0 := x, vars.client.y := vars.client.y0 := y
	vars.client.w := vars.client.w0 := w, vars.client.h := vars.client.h0 := h

	;apply overlay offsets if client is running in bordered windowed mode
	If (vars.client.fullscreen = "false") && !vars.client.borderless
	{
		vars.client.w0 := vars.client.w -= 2* vars.system.xborder
		vars.client.h0 := vars.client.h := vars.client.h - vars.system.caption - 2* vars.system.yborder
		vars.client.x0 := vars.client.x += vars.system.xborder
		vars.client.y0 := vars.client.y += vars.system.caption + vars.system.yborder
		LLK_Log("applied offsets for windowed mode")
	}
	vars.client.xc := vars.client.x - vars.monitor.x + vars.client.w/2, vars.client.yc := vars.client.y - vars.monitor.y + vars.client.h/2 ;client's horizontal and vertical centers (RELATIVE TO monitor.x and monitor.y)
	settings.general.FillerAvailable := (vars.client.fullscreen = "false" && vars.client.borderless || vars.client.fullscreen = "true" && vars.client.h < vars.monitor.h) ? 1 : 0

	IniRead, iniread, data\Resolutions.ini
	Loop, Parse, iniread, `n
	{
		If (A_Index = 1)
			vars.general.supported_resolutions := {}, vars.general.available_resolutions := ""
		vars.general.supported_resolutions[StrReplace(A_LoopField, "p")] := 1
		If (StrReplace(A_Loopfield, "p") <= vars.monitor.h && (vars.client.fullscreen = "true" || vars.client.borderless)) || (StrReplace(A_LoopField, "p") < vars.monitor.h && (vars.client.fullscreen = "false") && !vars.client.borderless)
			vars.general.available_resolutions := !vars.general.available_resolutions ? StrReplace(A_Loopfield, "p") : StrReplace(A_Loopfield, "p") "|" vars.general.available_resolutions
	}
	vars.general.available_resolutions .= "|"

	If (!IsNumber(vars.client.customres.1) || !IsNumber(vars.client.customres.2)) && vars.general.supported_resolutions.HasKey(vars.client.h)
	{
		IniWrite, % vars.client.w, % "ini" vars.poe_version "\config.ini", settings, custom-width
		IniWrite, % vars.client.h, % "ini" vars.poe_version "\config.ini", settings, custom-resolution
	}

	If vars.general.supported_resolutions.HasKey(vars.client.h)
	{
		Loop, Parse, % "GUI, Betrayal, Mapping Tracker", `,, %A_Space%
			If !FileExist("img\Recognition (" vars.client.h "p)\" A_LoopField "\")
				FileCreateDir, % "img\Recognition (" vars.client.h "p)\" A_LoopField "\"
		If !FileExist("img\Recognition (" vars.client.h "p)\")
			LLK_FilePermissionError("create", A_ScriptDir "\img\Recognition ("vars.client.h "p)")
	}
}

Init_geforce()
{
	local
	global vars, settings

	If !FileExist("ini" vars.poe_version "\geforce now.ini")
		IniWrite, % "", % "ini" vars.poe_version "\geforce now.ini", settings
	vars.pixelsearch.variation := LLK_IniRead("ini" vars.poe_version "\geforce now.ini", "Settings", "pixel-check variation", 10)
	vars.imagesearch.variation := LLK_IniRead("ini" vars.poe_version "\geforce now.ini", "Settings", "image-check variation", 25)
}

Init_general()
{
	local
	global vars, settings, json

	ini := IniBatchRead("ini" vars.poe_version "\config.ini"), legacy_version := ini.versions["ini-version"]
	If IsNumber(legacy_version) && (legacy_version < 15000) || FileExist("modules\alarm-timer.ahk") ;|| FileExist("modules\delve-helper.ahk")
	{
		MsgBox,, Script updated incorrectly, Updating from legacy to v1.50+ requires a clean installation.`nThe script will now exit.
		ExitApp
	}
	ini_version := LLK_IniRead("ini\config.ini", "versions", "ini", 0) ;ini-version is stored here regardless of which PoE-version is being played

	If (ini_version < 15303)
	{
		FileDelete, % "img\Recognition (" vars.client.h "p)\GUI\betrayal.bmp"
		If ini.features["enable betrayal-info"]
			MsgBox,, RIFT, % "The betrayal image-check was changed in v1.53.3 and needs to be recalibrated."
	}
	If (ini_version < 15304)
		FileDelete, data\global\[stash-ninja] prices.ini

	If (ini_version < 15703)
	{
		For index, poe_version in ["", " 2"]
		{
			If FileExist("ini" poe_version "\leveling tracker.ini")
			{
				IniRead, backup, % "ini" poe_version "\leveling tracker.ini", Settings
				FileDelete, % "ini" poe_version "\leveling tracker.ini"
				IniWrite, % backup, % "ini" poe_version "\leveling tracker.ini", Settings
				IniWrite, % "", % "ini" poe_version "\leveling tracker.ini", Settings, profile
			}

			For index, val in ["", 2, 3]
				FileDelete, % "ini" poe_version "\leveling guide" val ".ini"
		}
	}

	If (ini_version < 15707)
	{
		For index, poe_version in ["", " 2"]
		{
			ini_check := IniBatchRead("ini" poe_version "\item-checker.ini")
			If ini_check.settings.Count() || ini_check.UI.Count()
			{
				If (poe_version = vars.poe_version)
					ini.features["enable item-info"] := 1
				IniWrite, 1, % "ini" poe_version "\config.ini", Features, enable item-info
			}
		}

		If FileExist("data\global\[leveltracker] tree 2 0_2.json")
			FileDelete, % "data\global\[leveltracker] tree 2 0_2.json"
	}

	If (ini_version < 15708)
	{
		For index, poe_version in ["", " 2"]
			If FileExist("ini" poe_version "\leveling tracker.ini")
				IniWrite, 1, % "ini" poe_version "\leveling tracker.ini", settings, zone-layouts size
	}

	If (ini_version < 15805)
	{
		Loop, Files, % "img\GUI\act-decoder\zones\*.png"
			If !RegExMatch(A_LoopFileName, "i)(_y|y_)")
				FileDelete, % A_LoopFileLongPath
	}

	If (ini_version < 16402)
	{
		If FileExist("ini\lootfilter.ini")
			IniDelete, ini\lootfilter.ini, settings, active filter
		If FileExist("ini 2\lootfilter.ini")
			IniDelete, ini 2\lootfilter.ini, settings, active filter
	}

	IniWrite, 16402, ini\config.ini, versions, ini
	If !Blank(ini.features["enable ocr"])
	{
		IniWrite, % ini.features["enable ocr"], % "ini" vars.poe_version "\config.ini", features, enable tldr-tooltips
		IniDelete, % "ini" vars.poe_version "\config.ini", features, enable ocr
	}
	settings.general.character := ini.settings["active character"]
	settings.general.build := !Blank(settings.general.character) ? ini.settings["active build"] : ""
	settings.general.dev := !Blank(check := ini.settings["dev"]) ? check : 0
	settings.general.dev_env := settings.general.dev * (!Blank(check := ini.settings["dev env"]) ? check : 0)
	settings.general.warning_ultrawide := !Blank(check := ini.versions["ultrawide warning"]) ? check : 0
	settings.general.ClientFiller := (!settings.general.FillerAvailable ? 0 : (!Blank(check := ini.settings["client background filler"]) ? check : 0))
	settings.general.ClientFillerTaskbar := (!Blank(check := ini.settings["cover taskbar"]) ? check : 0)
	settings.general.ClientFillerSplit := (!settings.general.ClientFillerTaskbar ? 0 : (!Blank(check := ini.settings["split-screen mode"]) ? check : 0))
	settings.general.input_method := !Blank(check := ini.settings["input method"]) ? check : 1

	settings.general.fSize := !Blank(check := ini.settings["font-size"]) ? check : LLK_FontDefault()
	If (settings.general.fSize < 6)
		settings.general.fSize := 6
	LLK_FontDimensions(settings.general.fSize, font_height, font_width), settings.general.fHeight := font_height, settings.general.fWidth := font_width
	LLK_FontDimensions((settings.general.fSize2 := settings.general.fSize - 4), font_height, font_width), settings.general.fHeight2 := font_height, settings.general.fWidth2 := font_width

	settings.general.sMenu := !Blank(check := ini.settings["menu-widget size"]) ? check : Max(settings.general.fSize, 10)
	LLK_FontDimensions(settings.general.sMenu, height, width), settings.general.wMenu := width
	settings.general.animations := !Blank(check := ini.settings.animations) ? check : 1
	settings.features.browser := !Blank(check := ini.settings["enable browser features"]) ? check : 1
	settings.features.runeshaping := !Blank(check := ini.features["enable rune-ninja"]) ? check : 0
	settings.features.sanctum := !Blank(check := ini.features["enable sanctum planner"]) ? check : 0
	settings.features.anoints := !Blank(check := ini.features["enable enchant finder"]) ? check : 0
	settings.features.addons := !Blank(check := ini.features["enable add-ons"]) ? check : 0
	settings.features.lootfilter := !Blank(check := ini.features["enable filterspoon"]) ? check : 0
	settings.features.betrayal := !vars.poe_version && !Blank(check := ini.features["enable betrayal-info"]) ? check : 0
	settings.features.cheatsheets := !Blank(check := ini.features["enable cheat-sheets"]) ? check : 0
	settings.features.iteminfo := !Blank(check := ini.features["enable item-info"]) ? check : 0
	settings.features.leveltracker := !Blank(check := ini.features["enable leveling guide"]) ? check : 0
	settings.features.actdecoder := !Blank(check := ini.features["enable act-decoder"]) ? check : 0
	settings.features.maptracker := !Blank(check := ini.features["enable map tracker"]) ? check : 0
	settings.features.mapinfo := (settings.general.lang_client != "unknown") && !Blank(check := ini.features["enable map-info panel"]) ? check : 0
	settings.features.TLDR := !vars.poe_version && !Blank(check := ini.features["enable tldr-tooltips"]) ? check : 0
	settings.features.stash := !Blank(check := ini.features["enable stash-ninja"]) ? check : 0
	settings.features.statlas := vars.poe_version && !Blank(check := ini.features["enable statlas"]) ? check : 0
	settings.features.exchange := !Blank(check := ini.features["enable vaal street"]) ? check : 0
	settings.features.async := !Blank(check := ini.features["enable async trade"]) ? check : 0
	settings.updater := {"update_check": LLK_IniRead("ini\config.ini", "settings", "update auto-check", 0)}

	vars.pics := {"global": {"close": LLK_ImageCache("img\GUI\close.png"), "help": LLK_ImageCache("img\GUI\help.png"), "home": LLK_ImageCache("img\GUI\home.png"), "reload": LLK_ImageCache("img\GUI\restart.png"), "revert": LLK_ImageCache("img\GUI\revert.png"), "revert_all": LLK_ImageCache("img\GUI\revert_all.png"), "black_trans": LLK_ImageCache("img\GUI\square_black_trans.png"), "collapse": LLK_ImageCache("img\GUI\toggle_collapse.png"), "expand": LLK_ImageCache("img\GUI\toggle_expand.png")}
	, "anoints": {}, "betrayal_checks": {}, "cheatsheets_checks": {}, "iteminfo": {}, "legion": {}, "leveltracker": {}, "mapinfo": {}, "maptracker": {}, "maptracker_checks": {}, "radial": {"macros": {}, "menu": {}}, "runeshaping": {}, "screen_checks": {}, "search_strings": {}, "settings_lootfilter": {}, "settings": {}, "stashninja": {}, "statlas": {}, "zone_layouts": {}}

	If FileExist("data\global\leagues" vars.poe_version ".json")
		vars.leagues := json.Load(LLK_FileRead("data\global\leagues" vars.poe_version ".json", 1))
	Else If !vars.poe_version
		vars.leagues := {"sc":{"ssf":{"normal":{"standard":"Solo Self-Found"},"ruthless":{"standard":"SSF Ruthless"}},"trade":{"normal":{"standard":"Standard"},"ruthless":{"standard":"Ruthless"}}},"hc":{"ssf":{"normal":{"standard":"Hardcore SSF"},"ruthless":{"standard":"Hardcore SSF Ruthless"}},"trade":{"normal":{"standard":"Hardcore"},"ruthless":{"standard":"Hardcore Ruthless"}}}}
	Else vars.leagues := {"sc":{"ssf":{"standard":"Solo Self-Found"},"trade":{"standard":"Standard"}},"hc":{"ssf":{"standard":"Hardcore SSF"},"trade":{"standard":"Hardcore"}}}

	settings.general.league0 := StrSplit("sc|trade" (vars.poe_version ? "" : "|normal") "|standard", "|")
	settings.general.league := league := !Blank(check := ini.settings.league) ? StrSplit(check, "|", " ", 4) : settings.general.league0.Clone()
	If !vars.poe_version && !vars.leagues[league.1][league.2][league.3][league.4] || vars.poe_version && !vars.leagues[league.1][league.2][league.3]
		settings.general.league := settings.general.league0.Clone()

	Gui_ClientFiller()
}

Init_vars()
{
	local
	global vars, settings, CustomFont, db, Json

	db := {}

	settings := {}
	settings.features := {}
	settings.geforce := {}

	If FileExist("add-ons\loader" vars.poe_version)
	{
		settings.addons := {}, vars.addons := {"list": {}}, loaded := LLK_FileRead("add-ons\loader" vars.poe_version), version := (vars.poe_version ? 2 : 1)
		Loop, Files, % "add-ons\*", D
			If FileExist(A_LoopFilePath "\*.ahk") && InStr((file := LLK_FileRead(A_LoopFilePath "\info.json", 1)), "poe" version)
			{
				Try info := json.Load(file)
				Catch
					Continue
				vars.addons.list[A_LoopFileName] := {"info": info.Clone(), "enabled": InStr(loaded, "\" A_LoopFileName "\")}
			}
	}
	vars.betrayal := {}
	vars.cheatsheets := {}
	vars.client := {}
	vars.ddl := {}
	vars.economy := {}
	vars.GUI := []
	vars.omnikey := {}
	vars.omnikey.poedb := {"Claws": 1, "Daggers": 1, "Wands": 1, "One Hand Swords": 1, "One Hand Axes": 1, "One Hand Maces": 1, "Sceptres": 1, "Spears": 1, "Flails": 1
	, "Bows": 1, "Staves": 1, "Two Hand Swords": 1, "Two Hand Axes": 1, "Two Hand Maces": 1, "Quarterstaves": 1, "Crossbows": 1, "Traps": 1, "Talismans": 1
	, "Amulets": 1, "Rings": 1, "Belts": 1, "Gloves": 2, "Boots": 2, "Body Armours": 2, "Helmets": 2
	, "Quivers": 1, "Foci": 1, "Shields": 2, "Bucklers": 1, "Jewels": 1, "Life Flasks": 1, "Mana Flasks": 1, "Charms": 1}

	vars.lang := {}, vars.lang2 := {}
	vars.log := {} ;store data related to the game's log here
	vars.mapinfo := {}
	vars.hwnd := {"help_tooltips": {}}, vars.radial := {"last": 0, "order": [4, 6, 2, 8, 1, 3, 7, 9]}
	vars.help := Json.Load(LLK_FileRead("data\english\help tooltips.json",, "65001"))
	vars.pixels := {}
	vars.recombination := {"classes": ["shield", "sword", "quiver", "bow", "claw", "dagger", "mace", "ring", "amulet", "helmet", "glove", "boot", "belt", "wand", "staves", "axe", "sceptre", "body"]}
	vars.snip := {}
	Loop, Files, data\alt_font*
		alt_font := A_LoopFileName
	vars.system := {"timeout": 1, "font1": "", "font": "Segoe UI", "click": 1}
	vars.tooltip := {}
	vars.general := {"buggy_resolutions": {768: 1, 1024: 1, 1050: 1}, "inactive": 0, "startup": A_TickCount, "updatetick": 0}
	If !IsObject(vars.updater)
	{
		version := Json.Load(LLK_FileRead("data\versions.json")), version := version._release.1 . (version.hotfix ? "." (version.hotfix < 10 ? "0" : "") version.hotfix : "")
		vars.updater := {"version": [version, UpdateParseVersion(version)]}
	}

	LLK_Log("initialized global objects")
}

LLK_FileCheck() ;delete old files (or ones that have been moved elsewhere)
{
	For index, val in ["Atlas.ini", "Betrayal.json", "essences.json", "help tooltips.json", "lang_english.txt", "Map mods.ini", "Betrayal.ini", "timeless jewels\", "item info\", "leveling tracker\"
		, "english\eldritch altars.json", "english\[leveltracker] default guide 2.txt", "english\[leveltracker] quests.json", "english\[leveltracker] gem regex 2.json", "global\[leveltracker] gem regex.json"]
		If FileExist("data\" val)
		{
			FileDelete, data\%val%
			FileRemoveDir, data\%val%, 1
		}

	If FileExist("lailloken ui.ahk")
		FileDelete, lailloken ui.ahk

	If FileExist("img\GUI\leveling tracker\zones\") || FileExist("img\GUI\leveling tracker\zones 2\")
	{
		FileRemoveDir, % "img\GUI\leveling tracker\zones\", 1
		FileRemoveDir, % "img\GUI\leveling tracker\zones 2\", 1
	}

	For index, val in ["6) wall", "encampment_entrance", "petrified_soldiers", "access_with_nearby_switch", "follow_the_single_wagon", "road_opposite_the", "touching_the_road", "pillars_near_the", "same_direction_as_the", "for_the_broken", "between_2_pillars_nearby", "side_of_road_opposite_the", "single_wagon_at_the_fork", "up_to_the_broken", "single_flower-pot_at_the_fork", "corridor_with_hanged_karui", "dead_guards", "torch_on_the_road", "circle_of_pillars", "bend_on_the_right"]
		If FileExist("img\GUI\leveling tracker\hints\" val ".jpg")
			FileDelete, % "img\GUI\leveling tracker\hints\" val ".jpg"

	For index, val in ["the_wall_with_notes", "a_large_spiral", "form_a_triangle", "but_you_have_to_loop_around", "altar-locked_room_with_stairs", "the_plaza_and_the", "follow_the_road_straight", "diamond-shaped", "follow_road_straight", "the_wall_with_paper_talismans", "locked_room_with_stairs", "the_plaza_and", "check_the_surroundings", "follow_this_edge", "check_surroundings", "crescent-shaped", "diamond-shape", "paper_talismans", "pillar_structures", "the_wall_with_paper_talismans - Copy", "tower_structures", "swirls_that_point_to_missing_ones", "road_leads_straight"]
		If FileExist("img\GUI\leveling tracker\hints 2\" val ".jpg")
			FileDelete, % "img\GUI\leveling tracker\hints 2\" val ".jpg"

	For index, val in ["megalith bosses", "morwyn"]
		If FileExist("img\GUI\statlas\" val ".jpg")
			FileDelete, % "img\GUI\statlas\" val ".jpg"

	For index, val in ["necropolis.ahk", "ocr.ahk"]
		If FileExist("modules\" val)
			FileDelete, modules\%val%

	If FileExist("data\global\default guide 2.txt")
		FileDelete, data\global\default guide 2.txt
	If FileExist("img\GUI\screen-checks\necro_lantern.jpg")
		FileDelete, img\GUI\screen-checks\necro_lantern.jpg
	If FileExist("data\english\necropolis.json")
		FileDelete, data\english\necropolis.json
	If FileExist("ini\altars.ini")
		FileMove, ini\altars.ini, ini\ocr - altars.ini, 1
	Loop, Files, % "ini" vars.poe_version "\ocr*.ini"
		FileMove, % "ini" vars.poe_version "\" A_LoopFileName, % "ini" vars.poe_version "\" StrReplace(A_LoopFileName, "ocr", "TLDR"), 1

	If !FileExist("data\") || !FileExist("data\global\") || !FileExist("data\english\") || !FileExist("data\english\UI.txt") || !FileExist("data\english\client.txt")
		Return 0
	Else Return 1
}

Loop()
{
	local
	global vars, settings
	static news_tick := 0, tick := 0, timer_flash, client_tick := 0

	If !WinExist("ahk_group poe_window")
	{
		vars.client.closed := 1, vars.hwnd.poe_client := ""
		If !vars.log.file_wait && vars.log.latest_location
			vars.log.file_wait := 1, vars.log.file.Close()
		If settings.general.kill.1 && (A_TickCount >= vars.general.runcheck + settings.general.kill.2 * 60000)
			ExitApp
	}
	Else
	{
		vars.general.runcheck := A_TickCount, tick := !tick
		If !vars.hwnd.poe_client
			If (client_tick = 5)
			{
				If Gui_MsgBox("switch client", "RIFT: " Lang_Trans("msg_clientswitch"), [Lang_Trans("msg_clientswitch", 2), Lang_Trans("msg_clientswitch", 3)],, ["yes", "no"])
					LLK_Restart()
				Else
				{
					client_tick := 0
					Return
				}
			}
			Else If (vars.poe_version != CheckClient())
			{
				client_tick += 1
				Return
			}
			Else vars.hwnd.poe_client := WinExist("ahk_class POEWindowClass"), client_tick := 0

		If vars.client.closed
		{
			WinWaitActive, ahk_group poe_window
			Sleep, 5000
			Init_client(), Init_Lang(), Init_screenchecks()
			If vars.log.latest_location
				vars.log.file := FileOpen(vars.log.latest_location, "a", "UTF-8"), vars.log.file_wait := 0
		}
		vars.client.closed := 0

		If settings.updater.update_check && !vars.general.updatewait && !vars.update.1 && (A_TickCount >= vars.general.updatetick + 1800000)
		{
			vars.general.updatetick := vars.general.updatewait := A_TickCount
			SetTimer, UpdateCheck, -100
		}

		If vars.general.MultiThreading && !WinExist(vars.general.bThread)
			LLK_Error("Secondary thread has crashed, the tool needs to be restarted`n`nIf this is a recurring issue, disable multi-threading in the <general> settings", 1)

		If (vars.news.unread || vars.update.1 || vars.actdecoder.updater.available)
		&& (WinExist("ahk_id " vars.hwnd.radial.main) || WinExist("ahk_id " vars.hwnd.settings.main) || vars.actdecoder.tab && WinExist("ahk_id " vars.hwnd.actdecoder.main))
		{
			news_tick += 1
			If (Blank(vars.radial.click_select) || vars.radial.click_select = "settings") && WinExist("ahk_id " vars.hwnd.radial.main)
				GuiControl, % "+c" (Mod(news_tick, 2) ? "Black" : (vars.update.1 < 0 ? "Red" : "Lime")), % vars.hwnd.radial.settings
			If WinExist("ahk_id " vars.hwnd.settings.main)
			{
				If vars.news.unread
					GuiControl, % "+Background" (Mod(news_tick, 2) ? "6060FF" : "Lime"), % vars.hwnd.settings.background_news
				If vars.update.1
					GuiControl, % "+Background" (Mod(news_tick, 2) ? "6060FF" : (vars.update.1 < 0 ? "Red" : "Lime")), % vars.hwnd.settings.background_updater
				If vars.actdecoder.updater.available
				{
					GuiControl, % "+c" (Mod(news_tick, 2) ? "White" : "Lime"), % vars.hwnd.settings.actdecoder
					GuiControl, % "movedraw", % vars.hwnd.settings.actdecoder
				}
			}
			If vars.actdecoder.updater.available && vars.actdecoder.tab && WinExist("ahk_id " vars.hwnd.actdecoder.main)
				GuiControl, % "+Background" (Mod(news_tick, 2) ? "Black" : "Lime"), % vars.hwnd.actdecoder.helppanel_bar
		}

		If settings.features.leveltracker && settings.leveltracker.timer && (settings.leveltracker.timer_flash || timer_flash) && vars.hwnd.leveltracker.main && WinExist("ahk_id " vars.hwnd.leveltracker.main)
			If ((vars.leveltracker.timer.total_time + vars.leveltracker.timer.current_split) && (vars.leveltracker.timer.current_act != 11) || RegexMatch(vars.log.areaID, "i)^(1_1_1|g1_1)$"))
			&& (vars.leveltracker.timer.pause != 0) && settings.leveltracker.timer_flash && (vars.log.areaID != "login")
			{
				GuiControl, % "+c" (tick ? "Yellow" : "Gray"), % vars.hwnd.leveltracker.timer_total
				GuiControl, % "movedraw", % vars.hwnd.leveltracker.timer_total
				GuiControl, % "+c" (tick ? "Yellow" : "Gray"), % vars.hwnd.leveltracker.timer_act
				GuiControl, % "movedraw", % vars.hwnd.leveltracker.timer_act
				timer_flash := 1
			}
			Else If timer_flash
			{
				GuiControl, % "+c" (vars.leveltracker.timer.pause = 0 ? "White" : "Gray"), % vars.hwnd.leveltracker.timer_total
				GuiControl, % "movedraw", % vars.hwnd.leveltracker.timer_total
				GuiControl, % "+c" (vars.leveltracker.timer.pause = 0 ? "White" : "Gray"), % vars.hwnd.leveltracker.timer_act
				GuiControl, % "movedraw", % vars.hwnd.leveltracker.timer_act
				timer_flash := 0
			}
	}

	If settings.qol.quickpob && vars.quickpob.style && !vars.quickpob.in_progress && WinActive("ahk_id " vars.quickpob.hwnd_pob)
	{
		vars.quickpob.style := ""
		WinSet, ExStyle, -0x80, % "ahk_id " vars.quickpob.hwnd_pob
	}
}

Loop_main()
{
	local
	global vars, settings, json
	static tick_helptooltips := 0, ClientFiller_count := 0, priceindex_count := 0, tick_recombination := 0, stashhover := {}, tick := 0

	Critical
	tick += 1

	MouseHover()
	If Mod(tick, 2)
		Return

	If !Mod(tick, 10) && !vars.radial.wait && vars.hwnd.radial.main && !vars.radial.click_select && WinExist("ahk_id " vars.hwnd.radial.main)
	&& !(LLK_IsBetween(vars.general.xMouse, vars.radial.window.x1, vars.radial.window.x2) && LLK_IsBetween(vars.general.yMouse, vars.radial.window.y1, vars.radial.window.y2))
		LLK_Overlay(vars.hwnd.radial.main, "destroy"), vars.hwnd.radial.main := ""

	If vars.general.MultiThreading
	{
		WinGetText, comms_text, % vars.general.bThread
		If !(Blank(comms_text) || ErrorLevel)
		{
			comms_object := json.Load(comms_text), vars.pixels := comms_object.pixels.Clone()
			If !Mod(tick, 10) && (vars.settings.active = "clone-frames") && vars.hwnd.settings.fps && (vars.cloneframes.list.Count() > 1)
			{
				GuiControl, Text, % vars.hwnd.settings.fps, % " " (fps := Round(comms_object["clone-speed"]))
				GuiControl, % "+c" (fps <= settings.cloneframes.fps * 0.75 ? "Red" : fps < settings.cloneframes.fps ? "Yellow" : "lime"), % vars.hwnd.settings.fps
				GuiControl, % "movedraw", % vars.hwnd.settings.fps
			}
		}
	}
	Else If !Mod(tick, 4)
	{
		If vars.cloneframes.enabled && vars.cloneframes.gamescreen
			vars.pixels.gamescreen := Screenchecks_PixelSearch("gamescreen")
		Else vars.pixels.gamescreen := 0

		If settings.cloneframes.closebutton_toggle && vars.cloneframes.enabled
			vars.pixels.close_button := Screenchecks_PixelSearch("close_button")
		Else vars.pixels.close_button := 0

		If vars.cloneframes.enabled && vars.cloneframes.inventory || settings.features.iteminfo * settings.iteminfo.compare || vars.hwnd.exchange.main || vars.hwnd.sanctum_relics.main
			vars.pixels.inventory := Screenchecks_PixelSearch("inventory")
		Else vars.pixels.inventory := 0
	}

	If vars.cloneframes.editing && (vars.settings.active != "clone-frames") ;in case the user closes the settings menu without saving changes, reset clone-frames settings to previous state
	{
		vars.cloneframes.editing := ""
		Cloneframes_Thread(), Init_cloneframes()
	}

	If vars.hwnd.exchange.main && (vars.pixels.inventory != vars.exchange.inventory) && WinActive("ahk_id " vars.hwnd.poe_client)
		Exchange()

	If vars.hwnd.sanctum_relics.main && (vars.pixels.inventory != vars.sanctum.relics.inventory) && WinActive("ahk_id " vars.hwnd.poe_client)
		Sanctum_Relics()

	If vars.hwnd.recombination.main && WinActive("ahk_id " vars.hwnd.recombination.main) && (vars.general.wMouse = vars.hwnd.poe_client)
	{
		tick_recombination += 1
		If (tick_recombination >= 3)
		{
			WinActivate, % "ahk_id " vars.hwnd.poe_client
			tick_recombination := 0
		}
	}

	If vars.hwnd.stash_index.main && WinExist("ahk_id " vars.hwnd.stash_index.main) && !WinActive("ahk_id " vars.hwnd.stash_index.main) && !WinActive("ahk_id " vars.hwnd.stash_picker.main)
	{
		priceindex_count += 1
		If (priceindex_count >= 3)
			Stash_PriceIndex("destroy"), priceindex_count := 0
	}
	Else priceindex_count := 0

	If !vars.quickpob.in_progress && settings.general.ClientFiller
	{
		If vars.hwnd.ClientFiller && !WinExist("ahk_id " vars.hwnd.ClientFiller) && !WinActive("ahk_exe code.exe") && WinActive("ahk_group poe_window") && !WinActive("ahk_id " vars.hwnd.leveltracker_editor.main)
		&& !WinActive("ahk_id " vars.hwnd.leveltracker_gempickups.main)
			Gui_ClientFiller("show"), ClientFiller_count := 0
		Else If (ClientFiller_count = 3)
			Gui, ClientFiller: Hide
		Else If vars.hwnd.ClientFiller && WinExist("ahk_id " vars.hwnd.ClientFiller) && (!WinActive("ahk_group poe_ahk_window") || !WinExist("ahk_group poe_window")) && !WinActive("ahk_group snipping_tools")
			ClientFiller_count += 1
		Else ClientFiller_count := 0

		If vars.hwnd.poe_client && WinExist("ahk_id " vars.hwnd.poe_client) && WinActive("ahk_id " vars.hwnd.ClientFiller)
			WinActivate, % "ahk_id " vars.hwnd.poe_client
	}

	If vars.hwnd.anoints.main && WinActive("ahk_id " vars.hwnd.anoints.main) && (vars.general.wMouse = vars.hwnd.poe_client)
		WinActivate, % "ahk_id " vars.hwnd.poe_client

	If vars.hwnd.maptracker_logs.sum_tooltip && WinExist("ahk_id " vars.hwnd.maptracker_logs.sum_tooltip) && !WinActive("ahk_id " vars.hwnd.maptracker_logs.sum_tooltip)
	{
		Gui, maptracker_tooltip: Destroy
		vars.hwnd.maptracker_logs.sum_tooltip := ""
	}

	If vars.hwnd.maptrackernotes_edit.main && WinExist("ahk_id " vars.hwnd.maptrackernotes_edit.main) && (WinActive("ahk_id " vars.hwnd.maptracker_logs.main) || WinActive("ahk_id " vars.hwnd.maptracker_dates.main))
		LLK_Overlay(vars.hwnd.maptrackernotes_edit.main, "destroy"), vars.hwnd.maptrackernotes_edit.main := ""

	If vars.hwnd.searchstrings_context && WinExist("ahk_id " vars.hwnd.searchstrings_context) && !WinActive("ahk_group poe_window") && !WinActive("ahk_id "vars.hwnd.searchstrings_context)
	{
		Gui, searchstrings_context: Destroy
		vars.hwnd.Delete("searchstrings_context")
	}
	If vars.hwnd.omni_context.main && WinExist("ahk_id "vars.hwnd.omni_context.main) && !WinActive("ahk_group poe_window") && !WinActive("ahk_id "vars.hwnd.omni_context.main)
	{
		Gui, omni_context: destroy
		vars.hwnd.Delete("omni_context")
	}

	If vars.hwnd.leveltracker_gempickups.main && WinExist("ahk_id " vars.hwnd.leveltracker_gempickups.main)
	{
		hover := LLK_HasVal(vars.hwnd.leveltracker_gempickups, vars.general.cMouse)
		If vars.leveltracker_gempickups.hover && !RegExMatch(hover, "i)_panel|_bar")
		{
			For index, val in vars.leveltracker.skillsets
				GuiControl, % "+Background" vars.settings.cButtons2, % vars.hwnd.leveltracker_gempickups["skillset_" index "_bar"]
			vars.leveltracker_gempickups.hover := ""
		}
		Else If vars.general.cMouse && RegExMatch(hover, "i)_panel|_bar") && (hover != vars.leveltracker_gempickups.hover)
		{
			For index, val in vars.leveltracker.skillsets
				GuiControl, % "+Background" (val[StrReplace(StrReplace(hover, "_bar"), "_panel")] ? "Yellow" : vars.settings.cButtons2), % vars.hwnd.leveltracker_gempickups["skillset_" index "_bar"]
			vars.leveltracker_gempickups.hover := hover
		}
	}
	Else If vars.leveltracker_gempickups.hover
		vars.leveltracker_gempickups.hover := ""

	If !vars.quickpob.in_progress && !WinActive("ahk_group poe_ahk_window") && !(settings.general.dev && WinActive("ahk_exe code.exe"))
	{
		vars.general.inactive += 1
		If (vars.general.inactive = 3)
		{
			Gui, omni_context: Destroy
			vars.hwnd.Delete("omni_context"), LLK_Overlay("hide"), LLK_Overlay(vars.hwnd.maptracker.main, "destroy")
			If !vars.general.MultiThreading
				Cloneframes_Hide()
			Else StringSend("wait=1") ;Cloneframes_Thread(0, 1)
		}
	}

	If (settings.features.iteminfo * settings.iteminfo.compare)
		Iteminfo_Overlays()

	If vars.client.stream && !vars.radial.wait && !vars.general.drag && !WinExist("LLK-UI: notepad reminder") && !WinExist("LLK-UI: alarm set") && !WinExist("ahk_id " vars.hwnd.betrayal_setup.main) && WinActive("ahk_group poe_ahk_window") && vars.general.wMouse && LLK_HasVal(vars.hwnd, vars.general.wMouse,,,, 1) && !WinActive("ahk_id " vars.general.wMouse)
		WinActivate, % "ahk_id " vars.general.wMouse

	offsets := settings.stash.offsets[settings.general.input_method]
	If !vars.general.drag && (vars.general.wMouse != vars.hwnd.settings.main) && vars.hwnd.stash.main && !vars.stash.wait && !vars.stash.enter && (vars.stash.GUI || WinExist("ahk_id " vars.hwnd.stash.main)) && WinActive("ahk_group poe_ahk_window") && LLK_IsBetween(vars.general.xMouse, vars.client.x + offsets.1, vars.client.x + vars.stash.width + offsets.1) && LLK_IsBetween(vars.general.yMouse, vars.client.y + offsets.2, vars.client.y + vars.client.h + offsets.2)
	{
		tab := vars.stash.active
		If !stashhover.exact || (vars.general.xMouse "," vars.general.yMouse != stashhover.exact)
		&& !(LLK_IsBetween(vars.general.xMouse, stashhover.x1, stashhover.x2) && LLK_IsBetween(vars.general.yMouse, stashhover.y1, stashhover.y2))
		{
			stashhover := {}
			For item, val in vars.stash[tab]
			{
				If !IsObject(val)
					Continue
				box := InStr(item, "tab_") ? vars.stash.buttons : vars.stash[tab].box
				If !vars.poe_version
					exception1 := LLK_PatternMatch(item, "", ["potent", "powerful", "prime"]) ? 1 : 0, exception2 := LLK_PatternMatch(item, "", ["powerful", "prime"]) ? 1 : 0
				x1 := vars.client.x + val.coords.1 + offsets.1, x2 := vars.client.x + val.coords.1 + offsets.1 + (exception2 ? vars.client.h * (1/12) : box * (!vars.poe_version && InStr(item, "tab_") ? 4.5 : 1))
				y1 := vars.client.y + val.coords.2 + offsets.2, y2 := vars.client.y + val.coords.2 + offsets.2 + (exception1 ? vars.client.h * (1/12) : box)
				If LLK_IsBetween(vars.general.xMouse, x1, x2) && LLK_IsBetween(vars.general.yMouse, y1, y2)
				{
					stashhover := {"x1": x1, "x2": x2, "y1": y1, "y2": y2}
					vars.stash.hover := item, Stash("refresh")
					Break
				}
			}
			If Blank(stashhover.x1) && vars.stash.hover
				vars.stash.hover := "", Stash("refresh")
			stashhover.exact := vars.general.xMouse "," vars.general.yMouse
		}
	}
	Else If IsObject(stashhover) && !vars.hwnd.stash.main
		stashhover := ""
	Else If WinActive("ahk_group poe_ahk_window") && vars.stash.hover && !vars.stash.enter && !LLK_IsBetween(vars.general.xMouse, vars.client.x, vars.client.x + vars.stash.width)
		vars.stash.hover := "", Stash("refresh")

	If vars.general.cMouse
		check_help := LLK_HasVal(vars.hwnd.help_tooltips, vars.general.cMouse), check := (SubStr(check_help, 1, InStr(check_help, "_") - 1)), control := StrReplace(SubStr(check_help, InStr(check_help, "_") + 1), "|"), database := IsObject(vars.help[check][control]) ? vars.help : vars.help2

	tick_helptooltips += 1
	If !vars.radial.wait && (!Mod(tick_helptooltips, 3) || check_help)
	{
		If check_help && (vars.general.active_tooltip != vars.general.cMouse) && (database[check][control].Count() || (check = "lootfilter") && (InStr(control, "dummy") || InStr(control, "tier")) || InStr(control, "updater changelog") || check = "lab" && !(vars.lab.mismatch || vars.lab.outdated) && InStr(control, "square") || check = "donation" && vars.settings.donations[control].2.Count() || check = "lootfilter" && InStr(control, "tooltip") || check = "leveltrackergems" && InStr(control, "gem ")) && !WinExist("ahk_id "vars.hwnd.screencheck_info.main)
			Gui_HelpToolTip(check_help)
		Else If (vars.general.drag || !check_help || WinExist("ahk_id "vars.hwnd.screencheck_info.main)) && WinExist("ahk_id " vars.hwnd.help_tooltips.main)
			LLK_Overlay(vars.hwnd.help_tooltips.main, "destroy"), vars.general.active_tooltip := "", vars.hwnd.help_tooltips.main := ""
		tick_helptooltips := 0
	}

	If WinExist("ahk_id "vars.hwnd.legion.main)
		Legion_Hover()
	Else If !WinExist("ahk_id "vars.hwnd.legion.main) && WinExist("ahk_id "vars.hwnd.legion.tooltip)
		LLK_Overlay(vars.hwnd.legion.tooltip, "destroy"), vars.legion.tooltip := ""

	If !vars.tooltip.wait
	{
		For key, val in vars.tooltip ;timed tooltips are stored in this object and destroyed via this loop
			If val && (val <= A_TickCount)
				LLK_Overlay(key, "destroy"), remove_tooltips .= !remove_tooltips ? key : ";" key

		Loop, Parse, remove_tooltips, `; ;separate loop to delete entries from the vars.tooltip object without interfering with the for-loop above
			vars.tooltip.Delete(A_LoopField)
		remove_tooltips := ""
	}

	If !vars.general.gui_hide && (WinActive("ahk_group poe_ahk_window") || (settings.general.dev && WinActive("ahk_exe code.exe"))) && !vars.client.closed && !WinActive("ahk_id "vars.hwnd.leveltracker_screencap.main) && !WinActive("ahk_id "vars.hwnd.snip.main) && !WinActive("ahk_id "vars.hwnd.cheatsheet_menu.main) && !WinActive("ahk_id "vars.hwnd.searchstrings_menu.main) && !WinActive("ahk_id "vars.hwnd.notepad.main) && !WinActive("ahk_id " vars.hwnd.alarm.main) && !(vars.general.inactive && WinActive("ahk_id "vars.hwnd.settings.main)) && !WinActive("ahk_id " vars.hwnd.leveltracker_editor.main) && !WinActive("ahk_id " vars.hwnd.leveltracker_gempickups.main)
	{
		If vars.general.inactive
		{
			vars.general.inactive := 0
			LLK_Overlay("show")
			If vars.general.MultiThreading
				StringSend("wait=0") ;Cloneframes_Thread(0, 2)
		}
		Leveltracker_Fade()

		If !vars.general.MultiThreading
			Cloneframes_Check()
	}

	If (tick = 10)
		tick := 0
}

MouseHover()
{
	local
	global vars, settings

	MouseGetPos, xPos, yPos, win_hover, control_hover, 2
	vars.general.xMouse := xPos, vars.general.yMouse := yPos
	vars.general.wMouse := Blank(win_hover) ? 0 : win_hover, vars.general.cMouse := Blank(control_hover) ? 0 : control_hover
}

News(mode := "")
{
	local
	global vars, settings, json

	If !IsObject(vars.news.file)
		vars.news.file := json.Load(LLK_FileRead("data\announcements.json")), vars.news.last_read := LLK_IniRead("ini\config.ini", "versions", "announcement", 0)
	vars.news.wait := 1
	If !settings.general.dev
	{
		Try string := HTTPtoVar("https://raw.githubusercontent.com/Lailloken/Exile-UI/refs/heads/" (settings.general.dev_env ? "dev" : "main") "/data/announcements.json")
		Try object := json.Load(string)

		If !Blank(object.timestamp) && (object.timestamp != vars.news.file.timestamp)
		{
			vars.news.file := json.Load(LLK_StringCase(string))
			file_new := FileOpen("data\announcements.json", "w", "UTF-8-RAW")
			file_new.Write(string), file_new.Close()
		}
	}
	now := A_NowUTC, timestamp := StrReplace(StrReplace(StrReplace(vars.news.file.timestamp, " "), ":"), "-")
	EnvSub, now, timestamp, Days

	If !vars.news.unread && (IsNumber(now) && now < 7) && vars.news.file.timestamp && (vars.news.file.timestamp != vars.news.last_read)
		vars.news.unread := 1
	vars.news.wait := 0
}

Resolution_check()
{
	local
	global vars, settings
	poe_height := vars.client.h

	If vars.general.buggy_resolutions.HasKey(vars.client.h) || !vars.general.supported_resolutions.HasKey(vars.client.h)
	{
		If vars.general.buggy_resolutions.HasKey(poe_height)
		{
			text =
			(LTrim
			Unsupported resolution detected!

			The script has detected a vertical screen-resolution of %poe_height% pixels which has caused issues with the game-client and the script in the past.

			I have decided to end support for this resolution.
			You have to run the client with a custom resolution, which you can set up in the following window.
			)
		}
		Else If !vars.general.supported_resolutions.HasKey(vars.client.h)
		{
			text =
			(LTrim
			Unsupported resolution detected!

			The script has detected a vertical screen-resolution of %poe_height% pixels which is not supported.

			You have to run the client with a custom resolution, which you can set up in the following window.
			)
		}
		MsgBox,, RIFT, % text
		vars.general.safe_mode := 1
		settings_menu("client")
		sleep, 2000
		Loop
		{
			If !WinExist("ahk_id " vars.hwnd.settings.main)
			{
				MsgBox,, RIFT, The tool will now close.
				ExitApp
			}
			Sleep, 100
		}
	}
}

RightClick()
{
	local
	global vars, settings

	If GetKeyState("LButton", "P")
		Return
	vars.system.click := 2
	SendInput, {LButton}
	KeyWait, RButton
	vars.system.click := 1
}

Startup()
{
	local
	global vars, settings, json

	ini := IniBatchRead("ini" vars.poe_version "\config.ini", "settings")
	settings.general := {"kill": [LLK_IniRead("ini\config.ini", "settings", "kill script", 1), LLK_IniRead("ini\config.ini", "settings", "kill-timeout", 1)]}
	If !settings.general.kill.1
		settings.general.kill.2 := 0
	settings.general.dev := !Blank(check := ini.settings["dev"]) ? check : 0, settings.general.capslock := !Blank(check := ini.settings["enable capslock-toggling"]) ? check : 1
	SetStoreCapsLockMode, % settings.general.capslock ;for people who have something bound to CapsLock
	If !(vars.general.Gdip := Gdip_Startup(1))
	{
		MsgBox, 48, gdiplus error!, Gdiplus failed to start. Please ensure you have gdiplus on your system
		ExitApp
	}
	LLK_Log("initialized GDI+")

	;get widths/heights of window-borders to correctly offset overlays in windowed mode
	SysGet, xborder, 32
	SysGet, yborder, 33
	SysGet, caption, 4
	vars.system.xborder := xborder, vars.system.yborder := yborder, vars.system.caption := caption

	;create window-groups for easier window detection
	GroupAdd, snipping_tools, ahk_exe ScreenClippingHost.exe
	GroupAdd, snipping_tools, ahk_exe ShellExperienceHost.exe
	GroupAdd, snipping_tools, ahk_exe SnippingTool.exe

	GroupAdd, poe_window, ahk_class POEWindowClass
	GroupAdd, poe_window, ahk_exe GeForceNOW.exe

	GroupAdd, poe_ahk_window, ahk_class POEWindowClass
	GroupAdd, poe_ahk_window, ahk_class AutoHotkeyGUI
	GroupAdd, poe_ahk_window, ahk_exe GeForceNOW.exe

	If settings.general.dev
		GroupAdd, poe_ahk_window, ahk_exe code.exe ;treat VS Code's window as a client

	LLK_Log("set up window-groups, measured window-borders: " xborder ", " yborder ", " caption)

	If !LLK_FileCheck() ;check if important files are missing
		LLK_Error("Critical files are missing. Make sure you have installed the script correctly.")

	If !FileExist("ini\") ;ini-folder is required regardless of which PoE-version is being played
		FileCreateDir, ini\

	Loop, Parse, % "ini" vars.poe_version ", exports, img\GUI\skill-tree, cheat-sheets" vars.poe_version, `,, %A_Space%
	{
		If !FileExist(A_LoopField "\") ;create folder
			FileCreateDir, % A_LoopField "\"
		If !FileExist(A_LoopField "\") && !file_error ;check if the folder was created successfully
			file_error := 1, LLK_FilePermissionError("create", A_ScriptDir "\" A_LoopField)
	}

	;get the location of the client.txt file
	WinGet, poe_log_file, ProcessPath, ahk_group poe_window
	logs_folder := SubStr(poe_log_file, 1, InStr(poe_log_file, "\",, 0))
	If FileExist(logs_folder "logs\Client.txt")
		poe_log_file := logs_folder "logs\Client.txt"
	Else poe_log_file := logs_folder "logs\Kakaoclient.txt"
	LLK_Log("game's log-file: " poe_log_file)

	If FileExist(poe_log_file)
	{
		vars.log.file_location := poe_log_file, LLK_Log("found game's log-file")
		If FileExist(logs_folder "logs\LatestClient.txt")
		{
			vars.log.latest_location := logs_folder "logs\LatestClient.txt", LLK_Log("found game's alternative log-file")
			Loop, Parse, % LLK_FileRead(vars.log.latest_location), `n, % " `r"
				If (check := InStr(A_LoopField, "settings directory:"))
					parse := SubStr(A_LoopField, check + 19), vars.system.config_prelim := Trim(parse, " `t`n`r.")
		}
	}
	Else
	{
		; RIFT fallback for Steam/portable installations where Client.txt isn't next to EXE.
		manual_log := LLK_IniRead("ini\rift.ini", "client", "log path", "")
		vars.log.file_location := FileExist(manual_log) ? manual_log : 0
		LLK_Log(vars.log.file_location ? "using manually configured Client.txt" : "couldn't find game's log-file")
	}

	Init_client(), Init_Lang()

	;start secondary thread for multi-threading
	If (settings.general.multithread_off := LLK_IniRead("ini\config.ini", "settings", "disable multi-threading", 0))
		vars.general.MultiThreading := 0
	Else
	{
		Run, % """" A_AhkPath """ """ A_ScriptDir "\modules\_secondary thread.ahk""", % A_ScriptDir, UseErrorLevel, PID
		If PID
			WinWait, ahk_pid %PID%,, 1.5
		vars.general.MultiThreading := ErrorLevel ? 0 : 1, vars.general.bThread := "LLK-UI: B-Thread"
		string := json.dump({"PID": DllCall("GetCurrentProcessId"), "monitor": vars.monitor.Clone(), "client": vars.client.Clone()})
		If vars.general.MultiThreading && !StringSend(string)
		{
			vars.general.MultiThreading := 0
			If PID
				PostMessage, 0x8000, 0, 0,, % vars.general.bThread
		}
		LLK_Log("launch of secondary thread: " (vars.general.MultiThreading ? "successful" : "failed"))
	}

	vars.hwnd.poe_client := WinExist("ahk_group poe_window") ;save the client's handle
	vars.general.runcheck := A_TickCount ;save when the client was last running (for purposes of killing the script after X minutes)

	If vars.log.file_location
		Init_log(), LLK_Log("accessed required information from log-file")
}

StringReceive(wParam, string) ;based on example #4 on https://www.autohotkey.com/docs/v1/lib/OnMessage.htm
{
	local
	global vars, settings

	StringAddress := NumGet(string + 2*A_PtrSize), string := StrGet(StringAddress)
	If RegexMatch(string, "i)(OCR|JSON)\s")
		vars.ocr_comms.text := LLK_StringCase(string)
	Return true
}
