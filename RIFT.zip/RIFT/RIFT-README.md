RIFT v11 PoE 1 Companion. See README-RU.md.
