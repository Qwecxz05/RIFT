﻿# RIFT PoE1 Act-Decoder layout package installer.
# Downloads only official layout data; does NOT download or overwrite RIFT code.
param(
 [Parameter(Mandatory=$true)][string]$Root,
 [Parameter(Mandatory=$true)][string]$StatusFile
)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$target = Join-Path $Root 'img\GUI\act-decoder'
$temporary = Join-Path $env:TEMP ('RIFT-Layouts-' + [Guid]::NewGuid().ToString('N'))
try {
 New-Item -ItemType Directory -Force -Path $target | Out-Null
 New-Item -ItemType Directory -Force -Path $temporary | Out-Null
 $archive = Join-Path $temporary 'layouts.zip'
 # Official PoE 1 layouts branch (not the entire Exile-UI project).
 Invoke-WebRequest -UseBasicParsing -Uri 'https://github.com/Lailloken/Exile-UI/archive/refs/heads/layouts.zip' -OutFile $archive -TimeoutSec 120 -MaximumRedirection 5
 if ((Get-Item $archive).Length -lt 512) { throw 'Downloaded archive is empty.' }
 Add-Type -AssemblyName System.IO.Compression.FileSystem
 $extract = Join-Path $temporary 'unpacked'
 [IO.Compression.ZipFile]::ExtractToDirectory($archive, $extract)
 $list = Get-ChildItem -Path $extract -Recurse -File -Filter 'file-list.json' | Select-Object -First 1
 if (-not $list) { throw 'No file-list.json found in layout archive.' }
 $source = $list.DirectoryName
 $zoneDir = Join-Path $source 'zones'
 if (-not (Test-Path -LiteralPath $zoneDir -PathType Container)) { throw 'No zones directory in layout archive.' }
 $zoneCount = @(Get-ChildItem -LiteralPath $zoneDir -File -Recurse -Filter '*.png').Count
 if ($zoneCount -lt 1) { throw 'The layout archive has no zone images.' }
 # Stage complete validated package BEFORE replacing existing downloaded data.
 foreach ($filename in @('file-list.json','version.json')) {
    $src = Join-Path $source $filename
    if (Test-Path -LiteralPath $src) { Copy-Item -LiteralPath $src -Destination (Join-Path $target $filename) -Force }
 }
 $destZones = Join-Path $target 'zones'
 New-Item -ItemType Directory -Path $destZones -Force | Out-Null
 Copy-Item -Path (Join-Path $zoneDir '*') -Destination $destZones -Recurse -Force
 [IO.File]::WriteAllText($StatusFile,'ok' + [Environment]::NewLine + $zoneCount,[Text.Encoding]::UTF8)
} catch {
 [IO.File]::WriteAllText($StatusFile,('error: '+$_.Exception.Message),[Text.Encoding]::UTF8)
 exit 1
} finally {
 if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Recurse -Force -ErrorAction SilentlyContinue }
}
